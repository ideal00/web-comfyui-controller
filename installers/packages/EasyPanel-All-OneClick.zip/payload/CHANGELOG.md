# Easy Panel 更新记录

## v2.3.0 / mobile-v1.4.7（2026-10-02）

- 同步此前尚未提交的创作游乐场、分区预设搜索、预设例图、可视化词条编辑 / 上传、分区随机与词条锁定功能。组合预设按当前分区提取，锁定内容保留。
- 桌面与 Android 作品库增加上一页、下一页及页码跳转；缩略图按可见区域加载并使用有界缓存。高级面板复用 Token 会话，移除作品库重复登录。
- 服务端版本统一为 `2.3.0`；Android 包版本为 `1.4.7`，versionCode `1004007`。
- 修复 Windows 作品索引 ID 迁移未关闭 SQLite 读取 / 校验连接导致文件无法原子替换的问题。
- 一键包构建不再依赖维护者的个人 LoRA 导入记录；同步完整教程与更新记录，校验前端资源和安装器副本一致。
- 补充快速开始、提示词工具教程、双端功能对照和发布步骤。增加服务端检查 / 打包工作流及 Android 标签发布，发布包附 SHA256。

## 双端快捷工作流与任务状态对齐（2026-09-28）

- **工作台快捷操作**：桌面端新增生成面板历史记录的撤销/重做、随机 seed 设置/恢复/复制、提示词格式清理，以及标签的最近使用和收藏快捷入口。
- **任务状态**：任务队列保存实际解析后的 `resolved_seed`，生成完成后同步记录实际 seed，避免界面显示的随机值与任务结果不一致。
- **手机端桥接**：Android 客户端补充受信任 WebView 的剪贴板读取接口，手机端快捷操作与桌面端保持一致。
- **参数与资源**：尺寸选择器支持横竖互换；视觉标签库默认使用项目内 `visual_tag_library` 目录，不再依赖固定的 `G:\QK download` 路径。
- **发布版本**：Easy Panel 服务端 `v2.2.3`；Android 客户端 `mobile-v1.4.6`（versionCode `1004006`）。

## 离线翻译（Argos）+ 🇨🇳 解析词条 Prompt Explainer（2026-09-24）

### 离线翻译（`easy_panel_app/integrations/argos.py`、`web/assets/js/offline-translate.js`）
- 调用用户已装好的 Argos venv（`ctranslate2` + 语言包），**不联网、不需要 API Key**；面板不重复安装依赖，也不把模型拷到 C 盘（XDG_* 全部指向工具目录）。
- 目录探测：`EASY_PANEL_ARGOS_HOME` → `G:\edge download\webp_to_png_converter_v2\argos-translate` → `G:\ComfyUI\argos-translate` → `G:\argos-translate`；探测不到时端点会直接告诉用户放哪里。
- `POST /api/argos-translate`：`{status:true}` 能力探测 / `{text}` 单段（返回与 Google 直译同形状的 `positive` + `naturalLanguage` 分区）/ `{texts:[...]}` 批量（**一次请求**，最多 32 段）；服务端带 LRU 缓存，重复 tag 不再起子进程。
- 前端入口：「🧩 离线翻译（Argos）」整段中→英（**保留**）；「🧩 分区中文→英文（离线）」按钮**已移除**——逐框「翻译」已完全覆盖它，同一张卡上不再摆两个入口。
- **每个提示词框自带「翻译」按钮**（与「清空 / 粘贴」同排，12 个框全有）：点一下只处理这个框里的中文片段并实时回写，**再点一次撤销**；纯英文框不会再只回一句“没有中文片段”；翻译中按钮变「翻译中」禁点。
- **方向按内容自动选**：框里有中文 → 中文→英文（回写英文，方便直接出图）；框里是纯英文 → **英文→中文对照**（不把中文写进框，英文仍是最终提示词），直接在该分区打开「解析词条」列表：一行一个 `english = 中文`，**点整行就能删掉这个词**，也可以点 ↻ 重译。逐框「翻译」按钮的 title 也按这个方向写清楚了。
- 解析面板写回的是同一个分区，它会同步作废逐框翻译快照，避免“删完词条再点翻译又被撤销回来”。
- 状态提示就在**这个框自己标题行的按钮后面**（`<span class="prompt-section-translate-status" data-translate-status="<字段>">`），不再写全局 `#tokenHint`：哪个框翻了、翻了几段、词表命中几段、怎么撤销，都在该框处可见。
- 撤销文案明确：按钮 `title` 写「中文框 → 翻成英文；纯英文框 → 展开中文对照（点词条行可删除）；再点可撤销上一次翻译」，状态行会说明翻了几段 / 词表命中几段 / 撤销回到了几段原文。
- **过期快照失效**：清空 / 粘贴 / 手动改框 / 换预设 / 恢复面板后，该框（或全部）的上一次翻译快照立即作废，再点「翻译」是翻新内容而不是撤销；自己写回去的那次不算手改（`writingField` 守卫）。可编程调用 `window.easyPanelInvalidateFieldUndo(fieldId?)`。
- **长提示词自动分批**：`requestTranslations()` 按 `BATCH_LIMIT = 32` 顺序请求再按原序合并（进度写状态行「翻译中… 第 i/n 批」），逐框翻译、分区翻译、解析词条共用同一实现（`window.easyPanelArgosBatch`）；40 段实测 2 次请求（32 + 8），不再撞后端 32 段上限、也不再静默截断。样式 `.prompt-section-translate-status`（panel.css v53、offline-translate.js v4、prompt-explain.js v3）。
- 浏览器实测：`white shirt, 轻薄尼龙丝袜, 蓝色长发` → `white shirt, semi-sheer nylon pantyhose, …, blue hair, long hair`（词表 2 段直接命中）；英文框不动；再点一次回到原文。
- 本轮浏览器实测：12 个框都有独立状态位；`1girl, 蓝色长发, 红色蝴蝶结` → 状态行写在该框旁、`#tokenHint` 不变；再点一次回来；手动改成 `紫色短发` 后点翻译得到 `purple short hair`（不会回退）；40 段自动分 2 批（32+8）且顺序不变；清空后重填再翻也不回退。

### 🇨🇳 解析词条（`web/assets/js/prompt-explain.js`）
- 把英文提示词拆成词条并给中文解释，**英文永远是最终提示词**：切分（逗号/分号/换行，短语整体翻）→ 保护结构 token（LoRA / `score_*` / 人数标签 / `artist:name` / 纯数字 / kaomoji 标 🔒 不翻译）→ EN→ZH 批量离线翻译 → 紧凑列表点整行 = 保留/删除 → `serializeTokens()` 实时写回分区。
- 中文解释质量：先查浏览器词条表（`localStorage easyPanelPromptGlossaryV1`）与**词表反查**（`looking at viewer → 看向观众`、`standing → 站立`），剩下的才交 Argos；每行有 ↻ 重新翻译（清掉该条缓存后重取）。
- 长区段的批量翻译改走 `easyPanelArgosBatch`（自动分批），不再把词条列表 `.slice(0, 32)` 截断。
- 工具栏按钮改名成「🇨🇳 英文→中文对照（点行删除词条）」，对话框顶部也写明方向：英文→中文对照，英文仍然是最终提示词。
- 其它能力：全保留 / 全删除（🔒 保留）/ 仅看已删除 / 重新解析 / 恢复原文；切换分区下拉即可解析另一个分区；与 prompt_dialect 隔离，不改写 tag 写法。
- 测试：`tests/test_argos_translate.py`(16) + `tests/offline_translate.node-test.cjs`(20) + `tests/prompt_explain.node-test.cjs`(11)；全量 675 项仅剩 4 项既存失败。
- 页末浏览器实测：`sitting on bed, holding pillow, looking at viewer, barefoot` → `sitting on bed = 坐在床上 / holding pillow = 拿着枕头 / looking at viewer = 看向观众 / barefoot = 赤脚`，点「holding pillow」那一行即从分区里删掉该英文词。
- 浏览器实测：`score_9, 1girl, <lora:pose_x:0.7>, standing, …` → 🔒 三条不翻、其余批量翻；点行删除/恢复实时同步；🔒 行点击无效并提示；全删除后只剩结构词条；恢复原文回到最初文本。

### 顺带修掉一个启动竞态（`web/assets/js/panel.js`，v80）
- 复现：刚打开面板（模型目录还在加载）就往提示词框里粘贴/输入内容，约 8 秒后目录加载完成，`modelChanged()` 里的 `restorePromptFamilyState()` 会把刚写的内容整体顶掉（实测输入 `MARKER-ENGLISH-TAG` 秒变空，被删的 tag 也会“复活”）。
- 改法：新增 `promptTouchedSinceLoad` —— 只有**真人输入**（分区框/负面词的 `input` 事件）与用户主动动作（粘贴 / 清空 / 翻译 / 换预设，转发到 `markPromptTouched()`）才置位；首次加载那次（`currentPromptFamily` 为空）如果用户已经动过提示词，就**跳过**族状态恢复（仍然切族，后续保存/恢复照旧）；用户没动过时行为与以前完全一致。
- 实测：不动提示词 → 族状态照旧恢复；先输入再等目录加载完 → 内容全程保留，`restorePromptFamilyState` 不再被调用。

## FLUX 智能修图（FLUX.2 Klein 4B Distilled，2026-09-24）

- 新增 `easy_panel_app/flux_klein_edit.py`：**照 ComfyUI 官方 `image_flux2_klein_image_edit_4b_distilled` 模板逐节点复刻**的 Klein 编辑图（`UNETLoader` + `CLIPLoader(type=flux2)` + `VAELoader` → `ImageScaleToTotalPixels(1MP)` → `GetImageSize`/`EmptyFlux2LatentImage`/`Flux2Scheduler(4 步)` → `CLIPTextEncode` → `ConditioningZeroOut` → `VAEEncode` → `ReferenceLatent`(正/负) → `CFGGuider(cfg=1)` + `KSamplerSelect(euler)` + `RandomNoise` → `SamplerCustomAdvanced` → `VAEDecode` → `SaveImage`）。刻意**不**做 denoise / CFG 滑杆：Klein 是 4 步蒸馏 + 参考潜空间编辑，与 SD 式图生图不是一回事。
  - ⚠️ 官方 UI 模板里 `ImageScaleToTotalPixels.resolution_steps` 是折叠的高级输入，转成 API 格式**必须显式给值**，否则 ComfyUI 报 `required_input_missing`（本次由真实 `/prompt` 校验抓出）。
- 两种模式：**整图细化** 与 **局部修复**。局部修复在 Python 侧算蒙版 bbox（外扩 grow + pad + 对齐 8 + 限制 256–1536 边长）→ 裁 ROI → 羽化蒙版 → 写进 ComfyUI input（文件名带内容哈希，重复提交不堆文件）→ Klein 编辑 ROI → `ImageScale` 缩回 ROI 尺寸 → `ImageCompositeMasked` 贴回原图；`resolution_steps=8`、最多 2 张参考图（官方多参考子图 = 正/负 conditioning 各叠一层 `ReferenceLatent`）。
- 三档语义策略（保守 / 标准 / 重构）+ 六项「保留内容」复选项会拼成最终指令（`Conservative refinement… Preserve … Do not redesign the character`），明确标注为面板的语义预设而非模型参数。
- 后端接线：`build_workflow` 第一行判定 `fluxEdit` 直接走 Klein 图（不读主模型/提示词编译）；新端点 `POST /api/upload-flux-mask`（只上传蒙版，归一化成灰度 PNG）；`operation=flux_edit` 进 `SUPPORTED_OPERATIONS`；**父版本自动认领**——`CreativeIndex.generation_for_output()` 按被修图片名反查作品编号，前端/手机端都不用自己猜 id。
- 前端：结果卡新增「✨ FLUX 智能修图」（`result-workbench.js`，`flux-edit.js?v=1`）→ 对话框（原图缩略图 / 模式 / 蒙版行 / 修改描述 / 策略 / 保留内容 / 参考图）；手部工作台新增「✨ 发送到 FLUX 修图」与 `handExportMask()`（导出黑底白区蒙版）；作品库操作筛选项与标签加「FLUX 修图」。
- 测试：`tests/test_flux_klein_edit.py`（20 项：节点链、无 denoise、ROI 计算/对齐/上限、贴回缩放、参考图、operation、payload 一致性、接线）+ `tests/flux_edit.node-test.cjs`（10 项：表单→fluxEdit、校验、payload、蒙版导出与页面接线）；全量 658 项仅剩 4 项既存失败。

## 任务批处理控制移入左侧抽屉折叠（2026-09-23）

- 「任务批处理控制」（运行 / 暂停 / 取消当前 / 取消后续 / 清理失败 / 清理已结束 + 失败自动跳过 + 只运行入选实验 + 任务清单）从生成列搬到左侧抽屉，和「透明背景角色 PNG」一样是可折叠块（`#taskQueueFold`，默认折叠，状态同样记在 `easyPanelRailFoldV1`）；生成列不再重复占位。
- 折叠摘要右侧常驻短标签：只显示非零项（`执行中 1 · 排队 2 · 失败 3`），队列空闲显示「空闲」——摘要里的旧计数行改为纯文本，由 `rail-fold.js::summarizeTaskCounts()` 从 `#taskQueueServerCounts` 派生（监听其变化自动刷新），`task-control.js` 不用改。
- 测试：`tests/test_rail_fold.py` 新增「任务工具栏在抽屉里、生成列不再有」断言并校验全部按钮/开关/清单 id；`tests/rail_fold.node-test.cjs` 新增 `summarizeTaskCounts` 用例（含空值、全零、只有排队）。

## 预览栏首屏留给图片 + 顶部「⋯ 更多」+ 字号收进界面小菜单（2026-09-23）

- **预览栏（P1）**：宽高滑块、当前队列、采样/调度标签全部收进标题栏右侧的「⚙ 预览设置」弹层；图片区域紧跟标题栏（进度条只在生成时出现），并在预览栏可见高度里居中（`.preview-card` 改 flex 纵向 + `.result{flex:1 1 auto;min-height:var(--preview-height)}`）。清晰度检测面板也从图片上方改排到图片下方，首屏不再被工具栏挤占。
- **顶部「⋯ 更多」（P1）**：≤1340px 时以前 `.studio-header-actions{display:none}`，框宽 / 功能编辑 / 打开 ComfyUI 直接消失；现在统一挂在 `#studioMoreMenu` 里——宽屏（≥1341px）由 `header-menu.js` 设 open 平铺、隐藏 summary，窄屏默认收起成下拉（点外部/Esc 收起）。≤820px 的手机排版也保留入口（品牌行右侧）。
- **字号设置（P2）**：输入框字号不再占抽屉第一块卡片，收进抽屉标题栏的「⚙ 界面」小菜单（`#railAppearanceMenu`），拖动即时生效、仍只存在本机。
- 新增 `tests/test_header_menu.py`（7 项，含预览栏收纳 / 更多菜单 / 界面菜单 / payload 逐字节）与 `tests/header_menu.node-test.cjs`（4 项）；`test_ui_progress.py` 改为断言「进度在图片区之前、宽高/队列/标签在 ⚙ 预览设置 里」；版本：panel.css?v=50、clarity-analysis.js?v=5、新增 header-menu.js?v=1。

## 左侧快捷工具抽屉全部可折叠 + 透明背景角色 PNG 归位（2026-09-23）

- **透明背景角色 PNG 移进左侧抽屉**：原来固定在生成设置页顶部，现在挂在左侧「快捷工具」的 `#railTransparentMount`（生成设置页不再重复出现），切换「编辑提示词 / 生成设置」标签页也能随时调；面板本身改成可折叠，摘要右侧常驻当前档位（关闭 / 自动抠图 / 精细边缘）。
- **左侧抽屉原本不能折叠的四块全部改成可折叠**：输入框字号、我的功能、中文描述转换（摘要显示当前模型族）、读取 AI 图片参数（摘要显示已读取状态）；默认全部折叠，开合状态记在 `localStorage easyPanelRailFoldV1`。
- **结果类操作会自动展开对应面板**：读取 DeepSeek 回答 / 本地常用词转换 / 读图还原 / 手动修正最近的透明图（`window.easyPanelRevealRail(id)` 也可手动展开）。
- 折叠标题给左侧悬浮快捷跳转条（固定贴窗口左边、约 46px）留出内边距，避免标题被压住；新增 `tests/test_rail_fold.py`（5 项）与 `tests/rail_fold.node-test.cjs`（6 项）。

## 尺寸选择器：比例 + 长边滑块 + 推荐档位 + 尺寸信息（2026-09-23）

- **尺寸选择从一大串下拉选项改成四层结构**：① 图片比例按钮（1:1 / 2:3 / 3:4 / 9:16 / 1:2 / 9:21 / 3:2 / 4:3 / 16:9 / 2:1 / 21:9）；② 长边滑块（或直接输入长边 / 宽高）自由调尺寸；③ 现有档位当「推荐档位」快捷按钮；④ 当前尺寸 + MP + 预计显存负载（Anima / Krea 2 口径更紧，开启二采时附带二采后的预计分辨率）。
- **比例为严格数学比例，短边向下对齐 8 的倍数**（3:2 长边 1664 → 1664×1104、1408 → 1408×936），最小长边按比例推导，保证短边不会被后端 512 下限静默钳制。
- **现有档位全部保留**（含 4:7 / 7:4 这类近似比例）：标签写了比例的按标签归组，没写的按像素找最近比例；近似档位在按钮上标 `≈` 并在悬停里说明，不会被硬改成数学精确值。
- **自定义尺寸记忆**：每个比例记住上次用的尺寸，再点该比例直接回到上次档位（`localStorage easyPanelSizeByRatioV1`）。
- **点比例优先落在严格档位**：先恢复该比例的记忆尺寸，其次取该比例**第一个严格比例档位**（3:2 → 1536×1024、16:9 → 1280×720、9:16 → 720×1280），没有严格档位才退回近似档位，完全没有档位才用滑块中间值——不会出现“比例写着 3:2、首次尺寸却是 1216×832（实际 1.46:1）”的错位。
- **宽 × 高 定位为「自定义精确尺寸」**：明确提示「修改宽高会暂时允许非标准比例，再次拖动「长边」后恢复当前选定比例」，说明文字也会标出当前实际比例（例如 `1400 × 904（非标准比例，≈ 3:2）`）。
- 隐藏的原生 `<select id="size">` 仍是尺寸唯一真相源：`payload()`、预检、任务队列、快照恢复、手机端与模型上限判断全部继续读它；自定义尺寸会作为一个「自定义」档位写回下拉框，脚本未加载时原生下拉照常可用。
- 新增 `tests/size_selector.node-test.cjs`（算法与档位分组 9 项）与 `tests/test_size_selector.py`（接线 / payload 同步 12 项）。

## Anima 高清重建文案澄清 + Android 客户端 mobile-v1.4.6（2026-09-14）

- **澄清 Anime6B 归属**（用户反馈“启用高清重建后怎么再做 Anime6B 超分”）：Anima 高清重建**内部就是 Anime6B 超分 + 二采**，所以它不需要也不能再开「输出增强」的 Anime6B（那会放大两次）；只有“只放大、不重绘”时才改用输出增强。高清重建面板、输出增强选项、后端错误/预检文案都写明了这一点。
- **Android 客户端 mobile-v1.4.6**：执行链显示后端实际计划（阶段 / 主采样 / 局部重绘 / 计划输出），作品库显示产物来源与「⏳ 文件保存中」，失败时在「技术详情」里展开内部分类，任务中心显示队列任务的执行计划。
- Android versionCode 升级为 `1004006`，配套 Easy Panel 服务端 `2.2.2`。

## Android 客户端 mobile-v1.4.5（2026-08-31）

- 快速生图新增与桌面高级面板共用的中文描述转换；服务端会把当前模型族规则写入 DeepSeek 指令。
- 手机可复制并打开 DeepSeek、读取或粘贴回答后分别加入正向/负面提示词，不会因转换操作自动提交任务。
- 历史快照默认收起，标题可展开；刷新和恢复操作保持不变。
- 本地构建 Debug APK，未推送仓库或发布 GitHub Release。

## Android 客户端 mobile-v1.4.4（2026-08-31）

- 作品库缩略图改为可视区域优先、限并发队列，并使用服务端 360px 预览图，避免首屏一次性下载整页原图。
- 原图预览支持双指缩放、单指拖动、双击放大/还原。
- 本地生成 Debug APK，未推送仓库或发布 GitHub Release。

## Android 客户端 mobile-v1.4.3（2026-08-31）

- 作品库详情支持点击缩略图查看带鉴权读取的原图，并可在原图预览层下载。
- 作品库新增加载更多分页，可继续浏览最近 30 条之外的历史作品；服务端仍兼容 `2.2.2`。
- 本地生成 Debug APK，未推送仓库或发布 GitHub Release。

## Easy Panel 服务端 2.2.2 + Android 客户端 mobile-v1.4.2（2026-08-31）

- Creative Library Foundation 使用可重建的稳定 generation / artifact ID；保留安全但缺失的输出引用并阻止图片接口提供缺失文件。
- 提供历史随机 ID 的迁移 dry-run、备份、原子应用和回滚工具；本次部署前会先对正式数据库做只读预检。
- Web / Android 作品恢复只记录一次性父作品关系；多图提交共享本次关系，恢复不会自动选择具体输出作为图生图 / 重绘输入。
- Android versionCode 升级为 `1004002`；当前仅生成本地 Debug 验收包，未发布 GitHub Release。

## Easy Panel 服务端 2.2.1 + Android 客户端 mobile-v1.4.1（2026-08-31）

- 修复旧 `generation_snapshots.json` / `rpg_jobs.json` 迁移：已有 `outputs`、`images` 或 `artifacts` 的记录现在显示为 `completed`，不会再因缺少显式 status 被误标为 `queued`。
- 明确错误记录优先保留 `error`；已完成、失败或取消的终态不会在重复导入时被降级或互相覆盖；旧 SQLite 索引可通过幂等重建纠正此前错误的排队状态。
- 迁移仍为单向读取，源 JSON 不会被写回；缺失输出文件只记录警告，不删除作品库记录。
- Android versionCode 升级为 `1004001`；Debug APK 构建产物和 SHA256 清单见发布页附件。

## Easy Panel 服务端 2.2.0 + Android 客户端 mobile-v1.4.0（2026-08-31）

- 新增桌面 Web「作品库」：分页、操作 / 状态 / 模型筛选、排序、缩略图、详情、LoRA、输出下载和父子谱系。
- Android 快速页面与桌面 Web 共享只读 SQLite 创作索引；复现、换 Seed、继续编辑只回填当前表单，必须手动点击“生成图片”。
- 输出图片继续使用带 RPG 鉴权的安全路径；旧服务端、空索引、断网、缺 Token 和缺失输出均显示可读回退。
- Android versionCode 升级为 `1004000`；Debug APK 构建产物和 SHA256 清单见发布页附件。

## Easy Panel 服务端 2.1.0 + Android 客户端 mobile-v1.3.0（2026-08-31）

- 生成快照升级为可审计的完整源数据、最终提示词、采样原因、LoRA trigger、自动注入、去重和冲突诊断记录。
- 远程访问保护完整网页、旧版 API、快照详情/对比和输出图片；浏览器使用 Basic 引导签名 HttpOnly 会话，Android 原生 WebView 只在首个根请求发送 Token 请求头。
- Android 历史快照支持完整恢复、只换 Seed、继续编辑并聚焦提示词；解除附加高级配置后恢复普通生图提交语义。
- DeepSeek 网页转换复制失败时显示完整只读指令，原生剪贴板桥仅接受受信 Easy Panel 页面，复制成功后才打开外部 DeepSeek。
- 保持 Token 不进入 URL、网页 JavaScript、localStorage、剪贴板指令文本或公共仓库。

## Android 客户端 mobile-v1.2.5（2026-08-31）

- 新增跨设备共享状态：把 Easy Panel 浏览器已有的提示词预设和角色/LoRA 收藏安全合并到独立的 `easy_panel_shared_state.json`。
- 桌面浏览器首次升级后自动迁移；Android 高级面板进入同一 Easy Panel 地址时自动读取，页面也提供“立即同步”和冲突/离线状态提示。
- 共享文件使用 schema/version 校验、4 MB 上限、原子写入、`.bak` 备份、损坏恢复和 revision 冲突保护；空手机数据不会清空电脑数据。
- 共享状态不写入日志，不包含 Token；`lora_notes.json`、模型、API Key 和个人数据仍不进入仓库。

## Android 客户端 mobile-v1.2.4（2026-08-30）

- 新增 `android-client/`，包含快速生图与电脑端完整高级面板入口。
- 快速页支持 LAN / Tailscale / MagicDNS 地址、实际模型列表选择、异步任务恢复和显式生成。
- Android 下载保存到系统 `Downloads`，兼容 MediaStore、旧版存储权限和重复文件名。
- 高级面板当前图、历史/画廊原图、HTTP、Blob、data URL 与脚本下载统一接入同源校验、大小限制和安全文件名处理。
- Android 客户端补充 Easy Panel 品牌图标、圆形/自适应密度资源与启动图；前景保持在安全区内。
- 高级面板支持移动响应式布局、文件选择器、返回键、刷新、加载错误提示和页面下载。
- 提供 Android Debug 构建 CI；Debug APK 仅用于测试，不代表商店签名版本。
- 未提交 Token、API Key、模型权重、个人局域网地址、构建缓存或签名文件。

详细安装和验收步骤见 [android-client/README.md](android-client/README.md)。

## 工作树发布版（2026-08-30）

本次发布把本机已完成并经过本地测试的功能、前端资源和一键安装包统一同步到仓库：

- 增加提示词冲突诊断、提示词来源追踪和可关闭的自动提示词片段开关。
- 增加生成快照与模型/LoRA 文件指纹，支持恢复参数、复现任务和检查环境差异。
- 完善 LoRA 同名 TXT 读取、分项备忘、别名迁移和安全的 LoRA 导入工具。
- 增加 RPGBox 手机视觉接口、质量档、轮询状态、图片回传和移动端启动入口。
- 增加手部修复工作台、内置 miniPaint、透明背景、功能编辑器、提示词预设和图片查看辅助功能。
- 保留 Illustrious、Anima、Krea 2、姿势、多人区域、局部修复、调色和模型检查功能。
- 更新 Core / LoRA Tools / Pose / Color / Tags / Models / All 七个安装包及 SHA-256 清单。

## 发布边界

- 安装包不包含模型权重、API Key、RPG Token、运行日志、生成历史和任务队列。
- `lora_notes.json`、备份目录及本机导入审计属于本地数据，不应提交到公共仓库。
- RPG Token 由用户在本机运行目录配置，接口文档只描述变量和请求格式，不记录令牌值。

## 安装

解压 `installers/packages/EasyPanel-All-OneClick.zip`，双击其中的安装命令文件；只安装核心时使用 `EasyPanel-Core-OneClick.zip`。安装器会在覆盖前备份已有面板文件。
