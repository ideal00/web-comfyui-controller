# Easy Panel Mobile Android 客户端

这个目录是 Easy Panel 的 Android 客户端源码。它只控制电脑上的 Easy Panel / ComfyUI，不在手机上运行模型。

![Easy Panel Mobile 品牌图标](android/app/src/main/res/drawable-nodpi/easy_panel_brand_source.png)

图标源图保存在 `android/app/src/main/res/drawable-nodpi/easy_panel_brand_source.png`；Android 自适应图标、圆形/传统密度图标和启动图均由同一品牌标记生成，前景内容留在安全区内，未修改包名。

当前配套：Easy Panel **2.3.0** / Android **1.4.7**（versionCode `1004007`）。完整能力与共享范围见 [电脑 / 手机功能对照](../docs/FEATURE_MATRIX.md)。

## 功能入口

- **快速生图**：手机编辑正向提示词、负向提示词、Checkpoint、质量档位、宽高和轮询间隔；内置复用高级面板规则的“中文描述转换”，会按当前模型族生成 DeepSeek 指令，支持复制/打开、读取或粘贴 AI 回答并分别加入正向/负面词；只有点击“生成图片”才提交任务。模型列表来自 Easy Panel 的 `/api/rpg/models`，任务通过 API v2 异步执行。
- **历史快照**：默认收起以减少快速页滚动长度，点击标题即可展开；刷新、完整恢复、只换 Seed 和继续编辑功能保持不变。
- **作品库**：读取 Easy Panel 2.2.x Creative Library Foundation 的历史作品、缩略图、Seed、操作和父子谱系；首屏读取最近 30 条，可用“加载更多”继续查看更早作品。列表缩略图按可视区域优先、限并发加载，服务端支持 360px 小图预览；详情缩略图可点击打开带鉴权的原图预览，支持双指缩放、单指拖动和双击放大/还原；“复现 / 换 Seed / 继续编辑”只回填当前表单，必须再次点击“生成图片”，不会自动提交，也不会自动选择某个输出作为编辑输入。
- **高级面板**：打开电脑端正在运行的完整 Easy Panel 页面，继续使用角色、LoRA、ControlNet、OpenPose、多人区域、修复、透明背景、调色、历史和快照等原有功能。客户端没有复制这些工作流逻辑；同一地址下的提示词预设和角色/LoRA 收藏会由网页自动读取共享状态。

Android 高级面板通过原生 WebView 承载电脑页面，支持返回键、刷新、加载/错误提示、系统文件选择器和页面下载。手机快速页的图片保存到系统 `Downloads`。

作品库需要电脑端 Easy Panel 2.3.0 的 `/api/rpg/library/*` 接口；连接到旧版服务端时会显示兼容回退，不会因打开作品库而提交生成。恢复后会显示一次性派生提示，可取消关联；用户明确点击生成后才提交父作品关系，且不会自动选择某个输出作为编辑输入。索引由电脑端从 `generation_snapshots.json` / `rpg_jobs.json` 旁路建立，源 JSON 仍保留。

## 连接电脑

1. 先在电脑启动 Easy Panel 和 ComfyUI。推荐双击 `G:\ComfyUI\EasyPanel_一键启动.bat`。
2. ComfyUI 继续只监听电脑本机 `127.0.0.1:8188`；手机只访问 Easy Panel `8190`。
3. 手机与电脑同一局域网时，在 App 填写 `http://<电脑当前局域网IP>:8190`。
4. 跨网络时，确保两端登录同一个 Tailscale 网络，填写 `http://<电脑的100.x.x.x地址>:8190` 或 `http://<电脑MagicDNS主机名>:8190`。
5. Token 文件位于 Easy Panel 运行目录：`rpg_mobile_token.txt`。将文件内容粘贴到 App 的 RPG Token 输入框；首尾空白会清理，Token 不会写入高级面板 URL。
6. 点击“测试连接”。成功后点击“读取模型”，或重新测试连接让客户端自动读取模型。

不要把 `8188` 或 `8190` 端口直接映射到公网。优先使用 Tailscale；如果必须跨网络暴露，应使用受控的 HTTPS 反向代理和额外访问控制。

### 跨设备预设与收藏

桌面浏览器首次打开新版 Easy Panel 会自动把已有的 `easyPanelPromptPresetsV1` 和 `easyPanelLoraFavoritesV1` 合并到服务器的 `easy_panel_shared_state.json`；高级面板在 Android 上打开同一个 Easy Panel 地址后会自动读取，也可以点击页面里的“立即同步”。同步不会把 Token 放进 URL。服务器文件位于 Easy Panel 项目目录，上一版成功内容在 `easy_panel_shared_state.json.bak`；主文件读取失败时优先用备份恢复，只有主文件与备份都不可用时才会把损坏主文件改名为 `.corrupt.*.json`。离线时本机数据不清除，revision 冲突时服务器较新的记录不被手机覆盖，空手机集合也不会清空服务器收藏。

升级代码后请手动重启电脑端 Easy Panel 进程，再在 Android 高级面板刷新页面；不需要为这项同步重启 ComfyUI 8188。

## 安装与下载

当前版本 `mobile-v1.4.7` 已发布到 GitHub Release：

https://github.com/ideal00/web-comfyui-controller/releases/tag/mobile-v1.4.7

在 Release 页面下载 `app-debug.apk`（附 `app-debug.apk.sha256` 校验文件）即可安装。它是 Debug / 测试签名 APK，不是 Google Play 发布签名；可直接安装，或使用 `adb install -r` 覆盖安装旧测试版。

安装后验收：

1. 连接电脑并测试 Token。
2. 确认 Checkpoint 下拉框出现电脑端实际模型。
3. 修改质量、模型、尺寸和提示词，确认不会自动生成；点击“生成图片”后才提交一次。
4. 出图后点击“下载图片”，在系统 `Downloads` 中检查文件。重复下载会自动使用不覆盖的文件名。
5. 点击“高级面板”，测试完整页面的上传、生成、当前图/历史图下载、Blob/Data URL 下载、刷新和返回。

## 权限与下载

- Android 10 及以上使用 MediaStore 写入公共 `Downloads`，不要求旧式外部存储权限。
- Android 9 及以下在首次保存时请求 `WRITE_EXTERNAL_STORAGE`；拒绝后会显示明确失败信息，不会静默丢文件。
- 高级面板的同源 HTTP/HTTPS 下载由原生流式下载写入公共 `Downloads`；Blob / data URL 和脚本触发的下载由 WebView 桥接到同一目录。文件名、MIME、大小、重定向和来源会在原生侧复核。
- 浏览器运行时仍使用普通 Blob 下载，不依赖 Android 原生插件。

## 本地构建

需要 Node.js、pnpm、Java 21 和 Android SDK 35。进入本目录后执行：

```powershell
corepack enable
pnpm install --frozen-lockfile
pnpm test
pnpm build
pnpm android:apk
```

如需单独运行 Android 原生单测：

```powershell
Set-Location android
.\gradlew.bat testDebugUnitTest --no-daemon
```

APK 输出到：

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

GitHub Actions 在分支 / PR 上构建 Debug artifact；推送匹配 `package.json` 的 `mobile-v*` 标签时，测试与构建通过后自动发布 Debug APK 和 SHA256。工作流使用 GitHub 自带的仓库权限，不上传用户 Token、签名密钥或本地配置。完整 RPG / CG 源码仍保留在客户端目录，因为类型检查和构建入口会编译这些模块；模型权重、个人数据与 Electron 构建文件不包含在 Android 发布包中。

## 安全与已知限制

- 手机端保存的 Token 使用本机存储，仅作为 `X-RPG-Token` 请求头发送到用户填写的 Easy Panel 地址。
- 高级面板 URL 只允许 HTTP/HTTPS 根地址，并最多附带 `mobile=1`；Android 原生容器仅在首次根页面请求以 `X-RPG-Token` 请求头引导短时 HttpOnly 会话，Token 不会写入 URL、网页 JavaScript 或 localStorage。
- 高级面板下载桥只接受已验证的 Easy Panel 同源地址；Token、Authorization、API key 和 secret 不允许出现在下载 URL，也不会写入日志。
- ComfyUI `8188` 不应从手机直接访问；高级页面中电脑专用入口会隐藏，原生容器也会拦截到 `8188` 的导航。
- 发布检查范围以对应 Release 说明为准；自动构建不验证局域网 / Tailscale 或真实 Android 设备。
- 因此 Android 文件选择器、返回键、MediaStore 实际落盘、不同系统版本权限弹窗、Tailscale 从手机的实际可达性和真实 GPU 出图仍需在目标设备上验收。

## APK 校验

下载 APK 后，在 PowerShell 执行：

```powershell
Get-FileHash -Algorithm SHA256 .\app-debug.apk
```

发布 APK 的 SHA256 以发布页附件旁的 `app-debug.apk.sha256` 为准。

部署产物目录会同时提供 `app-debug.apk.sha256` 和说明文件；APK 不含本机模型与个人 RPG 资源。
