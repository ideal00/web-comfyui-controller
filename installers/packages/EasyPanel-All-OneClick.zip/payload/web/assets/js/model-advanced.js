(function () {
  "use strict";

  const byId = (id) => document.getElementById(id);
  const FALLBACK_FREEU = {
    key: "sdxl_official",
    label: "官方 SDXL / ComfyUI V2",
    b1: 1.3,
    b2: 1.4,
    s1: 0.9,
    s2: 0.2,
    source: "FreeU 作者 SDXL 推荐 + ComfyUI FreeU_V2 默认值",
    presets: [
      { key: "sdxl_official", label: "官方 SDXL / ComfyUI V2（推荐）", b1: 1.3, b2: 1.4, s1: 0.9, s2: 0.2, note: "适用于 SDXL 与 Illustrious。" },
      { key: "sdxl_gentle", label: "SDXL 柔和参考（Diffusers）", b1: 1.1, b2: 1.2, s1: 0.6, s2: 0.4, note: "增强更柔和，适合官方值效果过重时。" },
    ],
  };

  function profile() {
    return typeof window.currentSamplingProfile === "function"
      ? window.currentSamplingProfile()
      : {};
  }

  function workflowFeatures() {
    return typeof window.currentWorkflowFeatures === "function"
      ? window.currentWorkflowFeatures()
      : {};
  }

  function help(text) {
    return `<span class="small" title="${String(text).replace(/&/g, "&amp;").replace(/"/g, "&quot;")}">?</span>`;
  }

  const OUTPUT_DEFAULTS = {
    off: { scale: 1.5, note: "关闭：保持模型原始输出，不增加耗时或改变细节。" },
    anime6b: { scale: 1.5, note: "推荐：1.5×。适合动漫线稿和发丝边缘，速度快；倍率过高可能产生锐化感。" },
    seedvr2: { scale: 1.25, note: "推荐：1.25× + LAB。更偏向保留原构图与颜色，适合保守修复。" },
    ultimate: { scale: 1.5, note: "推荐：1.5×、20 步、重绘 0.20、Tile 512。细节最完整，但耗时和显存占用最高。" },
  };

  const HIRES_PROMPT_TEMPLATES = {
    detail: "fine details, detailed hair strands, detailed fabric texture",
    hair: "detailed hair strands, individual hair strands, glossy hair",
    clothing: "clothing details, fabric folds, damaged clothing details",
    expression: "subtle facial expression, detailed eyes, natural expression",
    lighting: "soft rim light, volumetric light, cinematic lighting",
  };

  const HIRES_COMPOSITION_TERMS = [
    "close-up", "close up", "extreme close-up", "medium shot", "full body",
    "upper body", "lower body", "cowboy shot", "wide shot", "portrait",
    "zoomed in", "headshot", "from above", "from below", "from side",
    "front view", "back view", "side view", "perspective", "panorama", "vertical", "horizontal",
  ];

  function hiresPromptMode() {
    return byId("hiresPromptMode")?.value || "append";
  }

  window.hiresPromptModeChanged = function (silent) {
    const mode = hiresPromptMode();
    const editing = mode !== "inherit";
    for (const id of ["hiresPositive", "hiresNegative"]) {
      const field = byId(id);
      if (field) field.disabled = !editing;
    }
    window.hiresPromptInputChanged();
    if (!silent && byId("status")) {
      byId("status").textContent = mode === "inherit"
        ? "二采提示词：继承首采（二采不改变提示词）。"
        : mode === "append"
          ? "二采提示词：追加补充（首采构图 + 下方补充词）。"
          : "二采提示词：完全独立（仅使用下方两框；留空的一项沿用首采）。";
    }
  };

  window.hiresPromptInputChanged = function () {
    const hint = byId("hiresPromptHint");
    if (!hint) return;
    const mode = hiresPromptMode();
    if (mode === "inherit") {
      hint.textContent = "继承首采：二采沿用首采正向与负面提示词，仅做放大与轻量重绘。";
      return;
    }
    const text = String(byId("hiresPositive")?.value || "").toLowerCase();
    const locked = byId("hiresCompositionLock")?.checked === true;
    const notes = [mode === "append"
      ? "追加补充 = 首采提示词 + 补充词；建议写局部细节、材质、表情、服装破损、发丝、皮肤细节，不建议重复构图、镜头、人物位置。"
      : "完全独立 = 只用下方两框；某一框留空时该项沿用首采内容。"];
    const hits = HIRES_COMPOSITION_TERMS.filter((term) => text.includes(term));
    if (hits.length) {
      notes.push(`⚠ 检测到 ${hits.slice(0, 4).join("、")}：${locked ? "锁定构图时这些镜头/构图词可能让二采重新构图，建议删除。" : "这些镜头/构图词可能改变二采构图。"}`);
    }
    notes.push(locked
      ? "锁定首采构图 ≠ 禁止重绘：它只限制大幅度构图变化，0.24 以上仍可能改变角色细节；上限由二采目的决定。"
      : "重绘幅度参考：0.15–0.23 高清保真（只补细节）；0.24–0.35 结构 / 细节重绘；超过 0.35 更接近重新生成。");
    hint.textContent = notes.join(" ");
  };

  window.hiresCompositionLockChanged = function (silent) {
    const locked = byId("hiresCompositionLock")?.checked === true;
    window.updateHiresDenoiseConstraints();
    window.hiresPromptInputChanged();
    if (typeof window.updateSizeInfo === "function") window.updateSizeInfo();
    if (!silent && byId("status")) {
      byId("status").textContent = locked
        ? "已锁定首采构图：允许局部结构重绘，但限制大幅度构图变化；上限仍由二采目的决定（保留首采 0.23 / 增强细节 0.26 / 局部重绘 0.35）。"
        : "已解除构图锁定：上限仍由二采目的决定，请自行确认重绘幅度是否符合预期。";
    }
  };

  window.clearHiresPromptField = function (id) {
    const field = byId(id);
    if (!field) return;
    const label = id === "hiresNegative" ? "二采负面" : "二采补充";
    field.value = "";
    window.hiresPromptInputChanged();
    if (byId("status")) byId("status").textContent = `已清空${label} Prompt。`;
  };

  window.pasteHiresPromptField = async function (id) {
    const field = byId(id);
    if (!field) return;
    const label = id === "hiresNegative" ? "二采负面" : "二采补充";
    try {
      const text = String(await window.EasyPanelQuickActions.readFirstClipboardText()).trim();
      if (!text) {
        if (byId("status")) byId("status").textContent = "剪贴板中没有可粘贴的文字。";
        return;
      }
      field.value = text;
      window.hiresPromptInputChanged();
      window.EasyPanelQuickActions?.finishClearFocus(field);
      if (byId("status")) byId("status").textContent = `已从剪贴板填入${label} Prompt（可在框内继续编辑）。`;
    } catch (error) {
      if (byId("status")) {
        byId("status").textContent = "无法读取剪贴板：请允许此页面访问剪贴板，或在输入框中按 Ctrl+V。";
      }
    }
  };

  window.cleanHiresPromptField = function (id) {
    const field = byId(id);
    if (!field) return;
    field.value = window.EasyPanelQuickActions?.cleanPromptText(field.value, id) || "";
    window.hiresPromptInputChanged();
    if (byId("status")) byId("status").textContent = "已按当前模型方言清洗二采 Prompt。";
  };

  window.insertHiresPromptTemplate = function (kind) {
    const field = byId("hiresPositive");
    const template = HIRES_PROMPT_TEMPLATES[kind];
    if (!field || !template) return;
    if (hiresPromptMode() === "inherit") {
      if (byId("hiresPromptMode")) byId("hiresPromptMode").value = "append";
      window.hiresPromptModeChanged(true);
    }
    field.value = [String(field.value || "").trim(), template].filter(Boolean).join(", ");
    window.hiresPromptInputChanged();
    if (byId("status")) byId("status").textContent = `已插入二采补充模板：${template}`;
  };

  function advancedPanelHtml() {
    return `
      <summary>模型增强与低显存 VAE</summary>
      <div class="color-panel">
        <div class="small" id="modelCapabilitySummary">读取当前模型能力…</div>
        <div class="two" style="margin-top:8px">
          <div>
            <div class="field-title"><span>模型增强</span>${help("对采样模型施加画质补丁。默认关闭最适合建立基线；FreeU V2 可增强 SDXL/Illustrious 结构细节，CFG Rescale 仅用于 v-pred 防过曝。")}</div>
            <select id="modelEnhancementMode" onchange="modelAdvancedChanged()">
              <option value="off">关闭（推荐基线）</option>
              <option value="freeu_v2">FreeU V2（SDXL/Illustrious 细节）</option>
              <option value="cfg_rescale">CFG Rescale（仅 v-pred 防过曝）</option>
            </select>
          </div>
          <div>
            <div class="field-title"><span>VAE 编解码</span>${help("标准模式速度更快，默认推荐；大图、高清二采或显存紧张时改用 Tiled。Tiled 推荐 Tile 512、重叠 64。")}</div>
            <select id="vaeMode" onchange="vaeModeChanged()">
              <option value="standard">标准（保持现有速度）</option>
              <option value="tiled">Tiled（低显存，较慢）</option>
            </select>
          </div>
        </div>
        <div id="freeuControls" style="display:none">
          <div class="field-title"><span>FreeU V2 推荐组合</span>${help("不增加采样步数，通过增强主干并抑制跳连改善结构和细节。默认使用官方 SDXL/ComfyUI V2：b1 1.3、b2 1.4、s1 0.9、s2 0.2。")}</div>
          <select id="freeuPreset" onchange="freeuPresetChanged(this.value)"><option value="sdxl_official">官方 SDXL / ComfyUI V2（推荐）</option><option value="sdxl_gentle">SDXL 柔和参考（Diffusers）</option><option value="custom">自定义</option></select>
          <div id="freeuPresetInfo" class="small" style="margin-top:6px"></div>
          <div class="two" style="margin-top:8px"><div><div class="field-title"><span>b1 · 主干阶段 1</span>${help("增强第一阶段主干特征；官方推荐 1.3。过高可能让对比和纹理过重。")}</div><input id="freeuB1" type="number" min="0" max="10" step="0.01" value="1.3" oninput="freeuValueChanged()"></div><div><div class="field-title"><span>b2 · 主干阶段 2</span>${help("增强第二阶段主干特征；官方推荐 1.4。")}</div><input id="freeuB2" type="number" min="0" max="10" step="0.01" value="1.4" oninput="freeuValueChanged()"></div></div>
          <div class="two"><div><div class="field-title"><span>s1 · 跳连阶段 1</span>${help("缩放第一阶段跳连特征；官方推荐 0.9，低于 1 可减少过度平滑。")}</div><input id="freeuS1" type="number" min="0" max="10" step="0.01" value="0.9" oninput="freeuValueChanged()"></div><div><div class="field-title"><span>s2 · 跳连阶段 2</span>${help("缩放第二阶段跳连特征；官方推荐 0.2。数值过低可能改变模型原有风格。")}</div><input id="freeuS2" type="number" min="0" max="10" step="0.01" value="0.2" oninput="freeuValueChanged()"></div></div>
          <div class="small" style="margin-top:6px">b1/b2 增强主干语义；s1/s2 抑制跳连造成的过度平滑或异常细节。建议固定种子，与关闭状态 A/B 对比。</div>
        </div>
        <div id="cfgRescaleControls" style="display:none">
          <div class="field-title"><span>CFG Rescale 强度</span>${help("仅对 v-pred 模型开放，用于降低高 CFG 造成的过曝和色彩烧灼。推荐默认 0.70；越高修正越强。")}</div>
          <input id="cfgRescaleMultiplier" type="number" min="0" max="1" step="0.01" value="0.7">
        </div>
        <div id="vaeTiledControls" style="display:none">
          <div class="two" style="margin-top:8px">
            <div><div class="field-title"><span>Tile 大小</span>${help("每块独立编解码的尺寸。推荐 512；显存不足用 384，显存充足可用 768 提速。")}</div><select id="vaeTileSize"><option value="384">384（更省显存）</option><option value="512" selected>512（推荐）</option><option value="768">768（更快）</option><option value="1024">1024</option></select></div>
            <div><div class="field-title"><span>重叠像素</span>${help("相邻 VAE 分块的重叠区域，用于减轻接缝。推荐 64；仍见接缝可升至 96，代价是更慢。")}</div><select id="vaeOverlap"><option value="32">32</option><option value="64" selected>64（推荐）</option><option value="96">96</option><option value="128">128</option></select></div>
          </div>
          <div class="small" style="margin-top:6px">Tiled 会同时用于普通 img2img 的 VAE Encode 和最终 Decode；局部修复仍使用专用 Inpaint 编码节点。</div>
        </div>
        <hr style="border:0;border-top:1px solid var(--line);margin:12px 0">
        <div class="field-title"><span>输出增强工作流</span>${help("生成完成后只选择一种整图增强；与高清二次采样、局部修复互斥。注意：Anima 高清重建内部已含 Anime6B 超分，所以开了高清重建时这里要留空（二者重复放大）；默认关闭用于基线对比。")}</div>
        <div class="two">
          <div><div class="field-title"><span>整图增强</span>${help("Anime6B 是纯放大（不重绘，适合动漫锐线）；SeedVR2 更保守地修复细节；Ultimate 会分块扩散重绘，质量高但最慢。想动画 + 超分一起要用人话：开「Anima 高清重建」即可，它内含 Anime6B。")}</div><select id="outputEnhancementMode" onchange="outputEnhancementChanged()"><option value="off">关闭（推荐基线）</option><option value="anime6b">Anime6B 后处理超分（纯放大，不重绘）</option><option value="seedvr2">SeedVR2 生成式超分</option><option value="ultimate">Ultimate SD Upscale（SDXL）</option></select></div>
          <div><div class="field-title"><span>输出倍率</span>${help("输出边长倍率。Anime6B/Ultimate 推荐 1.5×；SeedVR2 推荐 1.25×。倍率越高越吃显存，也越容易改变原图细节。")}</div><input id="outputEnhancementScale" type="number" min="1.1" max="4" step="0.05" value="1.5"></div>
        </div>
        <div id="outputEnhancementRecommendation" class="small" style="margin-top:6px">${OUTPUT_DEFAULTS.off.note}</div>
        <div id="ultimateControls" style="display:none" class="two"><div><div class="field-title"><span>Ultimate 步数 / 重绘</span>${help("左侧为扩散步数，右侧为重绘幅度。推荐 20 步 / 0.20；提高重绘会增加细节，也更容易改变脸和构图。")}</div><div class="two"><input id="ultimateSteps" type="number" min="8" max="40" value="20" aria-label="Ultimate 步数"><input id="ultimateDenoise" type="number" min="0.05" max="0.6" step="0.05" value="0.2" aria-label="Ultimate 重绘幅度"></div></div><div><div class="field-title"><span>Tile</span>${help("Ultimate 分块扩散尺寸。推荐 512；显存不足用 384，768/1024 更快但更吃显存。")}</div><select id="ultimateTileSize"><option value="384">384</option><option value="512" selected>512（推荐）</option><option value="768">768</option><option value="1024">1024</option></select></div></div>
        <div id="seedvrControls" style="display:none"><div class="field-title"><span>SeedVR2 色彩修正</span>${help("生成式超分后把颜色拉回原图。LAB 是默认推荐；Wavelet 更柔和，AdaIN 风格影响更明显，关闭可能出现色偏。")}</div><select id="seedvrColor"><option value="lab" selected>LAB（推荐）</option><option value="wavelet">Wavelet</option><option value="adain">AdaIN</option><option value="none">关闭</option></select></div>
        <div class="two" style="margin-top:8px"><label><input id="faceDetailerEnabled" type="checkbox" onchange="outputEnhancementChanged(true)"> 输出后自动修脸（FaceDetailer） ${help("检测并局部重绘脸部。单人大图可选；默认关闭，因为它可能改变身份和五官。推荐：引导 512、12 步、重绘 0.35。")}</label><label><input id="autoColorMatchEnabled" type="checkbox" onchange="outputEnhancementChanged(true)"> 自动匹配原图色彩 ${help("将增强结果的颜色匹配回增强前原图。出现色偏时开启；默认关闭，开启时推荐 Reinhard LAB、强度 0.70。")}</label></div>
        <div id="faceDetailerControls" style="display:none" class="three"><div><div class="field-title"><span>引导尺寸</span>${help("脸部局部处理分辨率。推荐 512；远景小脸可用 640，过高会更慢且可能改变五官。")}</div><input id="faceDetailerGuideSize" type="number" min="256" max="1024" step="64" value="512"></div><div><div class="field-title"><span>步数</span>${help("脸部局部重绘步数。推荐 12；通常 10–16 已足够。")}</div><input id="faceDetailerSteps" type="number" min="6" max="30" value="12"></div><div><div class="field-title"><span>重绘幅度</span>${help("脸部改动强度。推荐 0.35；降低可保身份，提高会修更多缺陷但可能换脸。")}</div><input id="faceDetailerDenoise" type="number" min="0.15" max="0.65" step="0.05" value="0.35"></div></div>
        <div class="field-title"><span>手脚局部修复</span>${help("专用 YOLO 检测后局部重绘。默认关闭：复杂背景中的绳结、灯笼和小装饰可能被误认成手脚；只在主体手脚确实需要修复时按需开启。")}</div>
        <div class="two"><label><input id="handDetailerEnabled" type="checkbox" onchange="outputEnhancementChanged(true)"> 自动修复手指（按需） ${help("使用较高置信度检测真实手部后局部重绘。复杂背景或手部严重遮挡时建议关闭，改用手绘蒙版局部修复。")}</label><label><input id="footDetailerEnabled" type="checkbox" onchange="outputEnhancementChanged(true)"> 自动修复脚趾/鞋形（按需） ${help("裸足时强调五趾，穿鞋时强调鞋形。复杂背景中的小物件仍可能误检，因此默认关闭。")}</label></div>
        <div id="limbDetailerControls" style="display:none"><div class="three"><div><div class="field-title"><span>引导尺寸</span>${help("手脚局部重绘分辨率。推荐 512；远景小手脚可试 640，但误检风险也会增加。")}</div><input id="limbDetailerGuideSize" type="number" min="256" max="1024" step="64" value="512"></div><div><div class="field-title"><span>步数</span>${help("默认 12 步，足够修补局部结构并减少重绘漂移。")}</div><input id="limbDetailerSteps" type="number" min="8" max="30" value="12"></div><div><div class="field-title"><span>重绘幅度</span>${help("默认 0.35，优先保留原手势和鞋形；超过 0.50 更容易产生新指趾或改写周围结构。")}</div><input id="limbDetailerDenoise" type="number" min="0.15" max="0.6" step="0.05" value="0.35"></div></div><div class="two" style="margin-top:8px"><div><div class="field-title"><span>手部修复正向词</span><span class="small">可完整改写或清空</span></div><textarea id="handDetailerPositive" style="min-height:72px">anatomically correct hands, five fingers on each hand, separated fingers, natural hand pose, sharp hand details, clean lineart</textarea><div class="field-title"><span>手部修复负向词</span></div><textarea id="handDetailerNegative" style="min-height:72px">bad hands, malformed hands, extra fingers, missing fingers, fused fingers, blurry hands</textarea></div><div><div class="field-title"><span>脚部修复正向词</span><span class="small">裸足时可改为 five toes</span></div><textarea id="footDetailerPositive" style="min-height:72px">anatomically correct feet, detailed footwear, correct shoe shape, sharp foot details, clean lineart</textarea><div class="field-title"><span>脚部修复负向词</span></div><textarea id="footDetailerNegative" style="min-height:72px">bad feet, malformed feet, extra toes, missing toes, fused toes, blurry feet</textarea></div></div></div>
        <div id="autoColorControls" style="display:none" class="two"><div><div class="field-title"><span>匹配算法</span>${help("Reinhard LAB 是稳妥默认；MKL LAB 匹配更强，Histogram 适合明显色阶差异但可能压缩层次。")}</div><select id="autoColorMethod"><option value="reinhard_lab">Reinhard LAB（推荐）</option><option value="mkl_lab">MKL LAB</option><option value="histogram">Histogram</option></select></div><div><div class="field-title"><span>强度</span>${help("颜色回匹配强度。推荐 0.70；色偏仍明显可提高，颜色变平则降低。")}</div><input id="autoColorStrength" type="number" min="0" max="1" step="0.05" value="0.7"></div></div>
        <details id="transparentOutputPanel" class="transparent-output-panel rail-fold" data-rail-fold>
        <summary><span class="rail-fold-title"><span class="studio-kicker">角色素材输出</span><b>透明背景角色 PNG</b></span><span class="rail-fold-state" id="transparentOutputState">关闭</span></summary>
        <div class="rail-fold-body">
        <div class="small">普通角色自动 · 复杂角色可调边缘</div>
        <div class="field-title"><span>处理方式</span>${help("普通角色使用自动模式；长发、薄纱、飘带、翅膀或复杂配饰使用复杂角色模式并调边缘。透明通道由抠图节点生成，不依赖提示词假装透明。")}</div>
        <div class="two transparent-output-row"><div><select id="transparentBackgroundMode" onchange="transparentBackgroundChanged()"><option value="off">关闭</option><option value="auto">普通角色 · 自动抠图</option><option value="complex">复杂角色 · 精细边缘</option></select></div><label class="transparent-keep-original"><input id="transparentKeepOriginal" type="checkbox" checked> 同时保留原背景图</label></div>
        <div id="transparentBackgroundInfo" class="small" style="margin-top:6px">自动模式会输出透明 PNG；复杂角色可调头发、薄纱和小配饰边缘。</div>
        <div id="transparentComplexControls" class="transparent-complex-controls" style="display:none">
          <div class="three"><div><div class="field-title"><span>边缘算法</span>${help("GuidedFilter 快且稳；PyMatting 对发丝和半透明材质更细，但更慢；VITMatte 质量高，首次可能下载模型。")}</div><select id="transparentDetailMethod"><option value="GuidedFilter">GuidedFilter（推荐）</option><option value="PyMatting">PyMatting（发丝/薄纱）</option><option value="VITMatte">VITMatte（首次可能下载）</option><option value="VITMatte(local)">VITMatte 本地模型</option></select></div><div><div class="field-title"><span>向内收边</span>${help("去除背景残边；过大会吃掉发丝和小配饰。推荐 4–8。")}</div><input id="transparentDetailErode" type="number" min="1" max="64" step="1" value="6"></div><div><div class="field-title"><span>向外扩边</span>${help("找回发丝、飘带等细边；过大会留下背景光晕。推荐 4–10。")}</div><input id="transparentDetailDilate" type="number" min="1" max="64" step="1" value="6"></div></div>
          <div class="three"><div><div class="field-title"><span>黑场</span>${help("低于该透明度的区域变为完全透明。提高可去杂边，推荐 0.01–0.08。")}</div><input id="transparentBlackPoint" type="number" min="0.01" max="0.98" step="0.01" value="0.01"></div><div><div class="field-title"><span>白场</span>${help("高于该透明度的区域变为完全不透明。降低可让主体更实，推荐 0.90–0.99。")}</div><input id="transparentWhitePoint" type="number" min="0.02" max="0.99" step="0.01" value="0.99"></div><div><div class="field-title"><span>精修像素上限</span>${help("越高边缘越精细但更吃显存；8GB 显存推荐 2MP。")}</div><input id="transparentMaxMegapixels" type="number" min="1" max="16" step="0.5" value="2"></div></div>
        </div>
        <div class="actions transparent-manual-actions"><button id="transparentManualButton" class="secondary" type="button" onclick="openTransparentMaskEditor()" disabled>手动修正最近的透明图</button><span class="small">自动抠图后可用画笔补留或擦除，再导出 PNG。</span></div>
        </div>
        </details>
        <div id="outputEnhancementAvailability" class="small" style="margin-top:8px"></div>
      </div>`;
  }

  function installPanel() {
    if (byId("modelAdvancedExtras")) return;
    const regions = byId("regionsEnabled")?.closest("details");
    if (!regions) return;
    const details = document.createElement("details");
    details.id = "modelAdvancedExtras";
    details.innerHTML = advancedPanelHtml();
    regions.parentNode.insertBefore(details, regions);

    // “透明背景”是常用输出选项：放进左侧快捷工具抽屉（不随创作标签页切换），并保持可折叠。
    const transparentPanel = byId("transparentOutputPanel");
    const railMount = byId("railTransparentMount");
    if (transparentPanel && railMount) {
      railMount.appendChild(transparentPanel);
    } else if (transparentPanel && byId("studioSettingsView")) {
      // 兼容旧版 index.html（没有左侧挂载点时退回生成设置页顶部）。
      byId("studioSettingsView").prepend(transparentPanel);
    }

    const workflowHeading = byId("illustriousPanel")?.querySelector("h3");
    if (workflowHeading) workflowHeading.textContent = "SDXL / Illustrious 精准生成";
    const hiresControls = byId("hiresControls");
    const hiresAdvancedBody = byId("hiresAdvancedBody") || hiresControls;
    if (hiresControls && !byId("hiresStrengthPanel")) {
      const block = document.createElement("div");
      block.id = "hiresStrengthPanel";
      block.className = "hires-strength-panel";
      block.innerHTML = `
        <div class="field-title"><span>二采目的</span>${help("先想清楚“我要它干什么”，再微调数值。二采会重新采样，它能改善结构与生成细节；只提高清晰度/尺寸请用左侧「同图清晰版」。")}</div>
        <input id="hiresPurpose" type="hidden" value="enhance">
        <div class="hires-purpose-row">
          <button type="button" data-purpose="preserve" onclick="applyHiresPurpose('preserve')"><b>保留首采</b><span>尽量不改脸、姿势、服装和构图</span><em>denoise 0.15–0.23</em></button>
          <button type="button" data-purpose="enhance" onclick="applyHiresPurpose('enhance')"><b>增强细节</b><span>补发丝、衣服褶皱、眼睛、饰品</span><em>denoise 0.20–0.26</em></button>
          <button type="button" data-purpose="redraw" onclick="applyHiresPurpose('redraw')"><b>局部重绘</b><span>允许重新塑造结构</span><em>denoise 0.24–0.35</em></button>
        </div>
        <div class="hires-strength">
          <div class="hires-strength-head"><b id="hiresStrengthValue">0.25</b><span id="hiresStrengthTier" class="small">增强细节</span></div>
          <div class="hires-strength-track"><div id="hiresStrengthFill" class="hires-strength-fill"></div><span class="hires-strength-zero" style="left:17%">0.15</span><span class="hires-strength-zero" style="left:43%">0.23</span><span class="hires-strength-zero" style="left:83%">0.35</span></div>
          <div class="hires-strength-scale"><span>高清保真 0.15–0.23</span><span>结构 / 细节重绘 0.24–0.35</span></div>
          <div id="hiresStrengthNote" class="small"></div>
        </div>`;
      hiresControls.insertBefore(block, hiresControls.firstChild);
      byId("hiresDenoise")?.addEventListener("input", () => window.renderHiresStrength());
      window.renderHiresStrength();
      if (!window.__hiresStrengthTimer) {
        // 换模型会按预设改写重绘幅度，这里跟着刷新目的与提示。
        window.__hiresStrengthTimer = setInterval(() => {
          const panel = byId("hiresStrengthPanel");
          if (!panel || panel.offsetParent === null) return;
          window.renderHiresStrength();
        }, 900);
      }
    }
    if (hiresControls && !byId("hiresSampler")) {
      const row = document.createElement("div");
      row.className = "two";
      row.style.marginTop = "8px";
      row.innerHTML = `<div><div class="field-title"><span>二次采样器</span>${help("高清重绘阶段使用的去噪算法。默认推荐自动，跟随当前模型专属配置；只有做固定参数 A/B 时才手动覆盖。")}</div><select id="hiresSampler" onchange="applyIllustriousMode()"><option value="auto">自动（按模型预设，推荐）</option></select></div><div><div class="field-title"><span>二次调度器</span>${help("高清重绘阶段的噪声曲线。默认推荐自动；错误调度器可能造成柔糊、噪点或模型风格偏移。")}</div><select id="hiresScheduler" onchange="applyIllustriousMode()"><option value="auto">自动（按模型预设，推荐）</option></select></div>`;
      hiresAdvancedBody?.appendChild(row);
      if (byId("sampler")) byId("hiresSampler").innerHTML = byId("sampler").innerHTML;
      if (byId("scheduler")) byId("hiresScheduler").innerHTML = byId("scheduler").innerHTML;
    }
    if (hiresControls && !byId("hiresPromptMode")) {
      const promptBlock = document.createElement("div");
      promptBlock.id = "hiresPromptPanel";
      promptBlock.style.marginTop = "8px";
      promptBlock.innerHTML = `
        <div class="field-title"><span>二采提示词模式</span>${help("首采决定构图，二采只补细节。继承首采＝二采沿用首采提示词；追加补充＝在首采基础上追加下方补充词；完全独立＝二采只用下方两框（留空的一项沿用首采）。")}</div>
        <select id="hiresPromptMode" onchange="hiresPromptModeChanged()">
          <option value="inherit">继承首采（只做放大）</option>
          <option value="append" selected>追加补充（推荐）</option>
          <option value="replace">完全独立（高级）</option>
        </select>
        <div class="field-title" style="margin-top:8px"><span>二采补充 Prompt</span><span class="small">只写高清阶段要强化的细节，不必重复首采构图</span></div>
        <textarea id="hiresPositive" rows="2" placeholder="例如：torn clothes, bloodstains, finer fabric texture, detailed hair strands" oninput="hiresPromptInputChanged()"></textarea>
        <div class="actions"><button class="secondary" type="button" onclick="pasteHiresPromptField('hiresPositive')">从剪贴板粘贴</button><button class="secondary" type="button" onclick="cleanHiresPromptField('hiresPositive')">清洗格式</button><button class="secondary" type="button" onclick="clearHiresPromptField('hiresPositive')">清空</button></div>
        <div class="field-title"><span>二采负面 Prompt</span><span class="small">留空时沿用首采负面词</span></div>
        <textarea id="hiresNegative" rows="2" placeholder="例如：blurry details, smeared fabric texture, plastic skin" oninput="hiresPromptInputChanged()"></textarea>
        <div class="actions"><button class="secondary" type="button" onclick="pasteHiresPromptField('hiresNegative')">从剪贴板粘贴</button><button class="secondary" type="button" onclick="cleanHiresPromptField('hiresNegative')">清洗格式</button><button class="secondary" type="button" onclick="clearHiresPromptField('hiresNegative')">清空</button></div>
        <div class="actions"><button class="secondary" type="button" onclick="insertHiresPromptTemplate('detail')">＋ 细节强化</button><button class="secondary" type="button" onclick="insertHiresPromptTemplate('hair')">＋ 发丝强化</button><button class="secondary" type="button" onclick="insertHiresPromptTemplate('clothing')">＋ 服装强化</button><button class="secondary" type="button" onclick="insertHiresPromptTemplate('expression')">＋ 表情强化</button><button class="secondary" type="button" onclick="insertHiresPromptTemplate('lighting')">＋ 光影强化</button></div>
        <div class="switch" style="margin-top:6px"><input id="hiresCompositionLock" type="checkbox" checked onchange="hiresCompositionLockChanged()"><div><b>优先保持首采构图</b><div class="small">勾选后把二采重绘幅度上限锁到 0.35（前端与后端都限制）。注意 0.35 已经是「局部重绘」上限：真正只补细节请把 denoise 保持在 0.15–0.26；不建议再写镜头、景别、构图类提示词。</div></div></div>
        <div id="hiresPromptHint" class="small" style="margin-top:6px"></div>`;
      hiresAdvancedBody?.appendChild(promptBlock);
      window.hiresPromptModeChanged(true);
      window.hiresCompositionLockChanged(true);
    }

    const size = byId("size");
    if (size && !Array.from(size.options).some((item) => item.value === "2048x2048")) {
      size.add(new Option("Krea 2 超清方图 2048 × 2048", "2048x2048"));
    }
  }

  window.hiresTierOf = function (value) {
    if (value < 0.15) {
      return { id: "below", label: "低于保真区",
               note: "低于 0.15 几乎不改变画面，细节也不会明显增加；要补细节建议 0.18–0.23。" };
    }
    if (value <= 0.20) {
      return { id: "keep", label: "保留首采",
               note: "✓ 构图稳定　✓ 角色一致性高　✓ 细节增强" };
    }
    if (value <= 0.26) {
      return { id: "detail", label: "增强细节",
               note: "✓ 构图基本保持　✓ 细节明显增强（发丝 / 衣物褶皱 / 眼睛 / 饰品）" };
    }
    if (value <= 0.35) {
      return { id: "redraw", label: "局部重绘",
               note: "⚠ 已进入重绘区：可能改变脸 / 发型 / 手 / 服装褶皱 / 背景；0.35 是重新塑造结构前的上限。" };
    }
    return { id: "over", label: "超出重绘上限",
             note: "⚠⚠ 超过 0.35 已不属于保真二采：构图与人物都可能变；建议回到 0.35 以内，或直接用精准模式重画。" };
  };

  window.renderHiresStrength = function () {
    const input = byId("hiresDenoise");
    if (!byId("hiresStrengthPanel")) return;
    const value = Math.max(0, Math.min(1, Number(input?.value || 0.25)));
    const purpose = window.hiresPurpose();
    const preset = HIRES_PURPOSE_PRESETS[purpose] || HIRES_PURPOSE_PRESETS.enhance;
    const tier = window.hiresTierOf(value);
    const percent = Math.max(0, Math.min(100, ((value - 0.10) / 0.30) * 100));
    if (byId("hiresStrengthValue")) byId("hiresStrengthValue").textContent = value.toFixed(2);
    if (byId("hiresStrengthTier")) byId("hiresStrengthTier").textContent = preset.label;
    const note = byId("hiresStrengthNote");
    if (note) {
      let text = preset.note;
      if (value > preset.cap) {
        text += `（当前 ${value.toFixed(2)} 超过该目的上限 ${preset.cap}，生成时会自动限制）`;
      } else if (tier.id !== HIRES_PURPOSE_TIER[purpose] && tier.id !== "below" && tier.id !== "over") {
        text += `　• 当前数值落在「${tier.label}」区间。`;
      }
      note.textContent = text;
    }
    const panel = byId("hiresStrengthPanel");
    if (panel) {
      panel.dataset.tier = tier.id;
      panel.querySelectorAll("button[data-purpose]").forEach((button) => {
        button.classList.toggle("active", button.dataset.purpose === purpose);
      });
    }
    const fill = byId("hiresStrengthFill");
    if (fill) fill.style.width = percent.toFixed(1) + "%";
  };

  const HIRES_PURPOSE_PRESETS = {
    preserve: { label: "保留首采", denoise: 0.20, cap: 0.23, lock: true,
                note: "保留首采：优先维持人物、姿势、构图与服装结构。建议 denoise 0.15–0.23。" },
    enhance: { label: "增强细节", denoise: 0.25, cap: 0.26, lock: true,
               note: "增强细节：优先补发丝、材质、眼睛、服装褶皱等细节。建议 denoise 0.20–0.26。" },
    redraw: { label: "局部重绘", denoise: 0.30, cap: 0.35, lock: false,
              note: "局部重绘：允许重新塑造局部结构，可能改变脸、手、服装或局部比例。建议 denoise 0.24–0.35。" },
  };
  const HIRES_PURPOSE_TIER = { preserve: "keep", enhance: "detail", redraw: "redraw" };

  window.hiresPurpose = function () {
    return byId("hiresPurpose")?.value || "enhance";
  };

  // 上限由二采目的决定，与后端 HIRES_PURPOSE_CAPS 完全一致：
  // 保留首采 0.23 / 增强细节 0.26 / 局部重绘 0.35。构图锁只是附加提示。
  window.updateHiresDenoiseConstraints = function () {
    const preset = HIRES_PURPOSE_PRESETS[window.hiresPurpose()] || HIRES_PURPOSE_PRESETS.enhance;
    const input = byId("hiresDenoise");
    if (!input) return;
    input.max = String(preset.cap);
    const value = Number(input.value);
    if (Number.isFinite(value) && value > preset.cap) input.value = String(preset.cap);
  };

  window.applyHiresPurpose = function (purpose) {
    const preset = HIRES_PURPOSE_PRESETS[purpose];
    const input = byId("hiresDenoise");
    if (!preset || !input) return;
    if (byId("hiresPurpose")) byId("hiresPurpose").value = purpose;
    input.value = String(preset.denoise);
    const lock = byId("hiresCompositionLock");
    if (lock) lock.checked = preset.lock;
    window.updateHiresDenoiseConstraints();
    window.renderHiresStrength();
    input.dispatchEvent(new Event("change", { bubbles: true }));
    window.hiresPromptInputChanged();
    if (byId("status")) {
      byId("status").textContent = `二采目的：${preset.label}（denoise 上限 ${preset.cap}）。${preset.note}`;
    }
  };

  // 旧名字保留为别名，避免其它脚本失效。
  window.applyHiresTier = function (tier) {
    const legacy = { faithful: "preserve", balanced: "enhance", redraw: "redraw",
                     keep: "preserve", detail: "enhance" };
    window.applyHiresPurpose(legacy[tier] || tier);
  };

  function syncSourceLink() {
    const target = byId("advancedSource");
    const current = profile();
    if (!target) return;
    target.textContent = "";
    if (current.source_url) {
      const link = document.createElement("a");
      link.href = current.source_url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = current.source || "来源";
      link.style.color = "#cfc4ff";
      target.appendChild(link);
    } else {
      target.textContent = current.source || "";
    }
  }

  function freeuConfig() {
    const configured = profile().freeu;
    return configured && Array.isArray(configured.presets) ? configured : FALLBACK_FREEU;
  }

  function updateFreeuInfo() {
    const select = byId("freeuPreset");
    const info = byId("freeuPresetInfo");
    if (!select || !info) return;
    const preset = freeuConfig().presets.find((item) => item.key === select.value);
    info.textContent = preset
      ? `${preset.note} 当前：b1 ${preset.b1} · b2 ${preset.b2} · s1 ${preset.s1} · s2 ${preset.s2}`
      : "自定义参数；数值 1 表示该通道不缩放。";
  }

  window.applyFreeuPreset = function (key, silent) {
    const config = freeuConfig();
    const preset = config.presets.find((item) => item.key === key) ||
      config.presets.find((item) => item.key === config.key) || config;
    [["freeuB1", "b1"], ["freeuB2", "b2"], ["freeuS1", "s1"], ["freeuS2", "s2"]]
      .forEach(([id, field]) => { if (byId(id)) byId(id).value = preset[field]; });
    if (byId("freeuPreset")) byId("freeuPreset").value = preset.key;
    updateFreeuInfo();
    if (!silent && byId("status")) {
      byId("status").textContent = `已应用 ${preset.label}：b1 ${preset.b1} / b2 ${preset.b2} / s1 ${preset.s1} / s2 ${preset.s2}。`;
    }
  };

  window.freeuPresetChanged = function (key) {
    if (key === "custom") updateFreeuInfo();
    else window.applyFreeuPreset(key, false);
  };

  window.freeuValueChanged = function () {
    if (byId("freeuPreset")) byId("freeuPreset").value = "custom";
    updateFreeuInfo();
  };

  function syncFreeuPresets() {
    const select = byId("freeuPreset");
    if (!select) return;
    const config = freeuConfig();
    const previous = select.value || config.key;
    select.innerHTML = config.presets.map((preset) =>
      `<option value="${preset.key}">${preset.label}</option>`
    ).join("") + '<option value="custom">自定义</option>';
    select.value = previous === "custom" || config.presets.some((preset) => preset.key === previous)
      ? previous
      : config.key;
    if (select.value !== "custom") window.applyFreeuPreset(select.value, true);
    else updateFreeuInfo();
  }

  function syncCapabilities() {
    const current = profile();
    const caps = current.capabilities || {};
    const mode = byId("modelEnhancementMode");
    if (!mode) return;
    const selectedModel = byId("model")?.selectedOptions[0];
    if (selectedModel && current.family === "krea2") {
      selectedModel.textContent = `${selectedModel.value}（${current.label}${current.locked ? "，参数锁定" : ""}）`;
    }
    const freeu = mode.querySelector('option[value="freeu_v2"]');
    const rescale = mode.querySelector('option[value="cfg_rescale"]');
    freeu.disabled = !caps.freeu_v2;
    rescale.disabled = !caps.cfg_rescale;
    if (mode.selectedOptions[0]?.disabled) mode.value = "off";

    const promptLabels = { tags: "标签提示词", hybrid: "标签 + 自然语言", natural_language: "自然语言" };
    const resolution = current.resolution || {};
    const summary = byId("modelCapabilitySummary");
    if (summary) {
      summary.textContent = `${promptLabels[caps.prompt_mode] || "模型自适应提示词"} · ` +
        `${resolution.min || 512}–${resolution.max || 1920}px · ` +
        `${caps.regional_prompting ? "支持多人分区" : "不支持多人分区"} · ` +
        `${caps.negative_prompt === false ? "Turbo 负面提示不生效" : "支持负面提示"}`;
    }

    const maxSize = Number(resolution.max || 1920);
    const size = byId("size");
    if (size) {
      Array.from(size.options).forEach((option) => {
        const [width, height] = option.value.split("x").map(Number);
        option.disabled = Math.max(width || 0, height || 0) > maxSize;
      });
      if (size.selectedOptions[0]?.disabled) {
        const recommended = (resolution.recommended || [])[0];
        const wanted = Array.isArray(recommended) ? recommended.join("x") : "";
        size.value = Array.from(size.options).some((item) => item.value === wanted && !item.disabled)
          ? wanted
          : Array.from(size.options).find((item) => !item.disabled)?.value || size.value;
      }
    }
    syncSourceLink();
    syncFreeuPresets();
    syncOutputCapabilities();
    window.modelAdvancedChanged(true);
    window.vaeModeChanged(true);
  }

  function syncOutputCapabilities() {
    const features = workflowFeatures();
    const mode = byId("outputEnhancementMode");
    if (!mode) return;
    const support = { anime6b: !!features.anime6b, seedvr2: !!features.seedvr2,
      ultimate: !!features.ultimate && profile().family !== "anima" && profile().family !== "krea2" };
    Object.entries(support).forEach(([key, enabled]) => {
      const option = mode.querySelector(`option[value="${key}"]`);
      if (option) option.disabled = !enabled;
    });
    if (mode.selectedOptions[0]?.disabled) mode.value = "off";
    const face = byId("faceDetailerEnabled");
    if (face) {
      face.disabled = !features.face_detailer || profile().family === "krea2";
      if (face.disabled) face.checked = false;
    }
    const color = byId("autoColorMatchEnabled");
    if (color) {
      color.disabled = !features.color_transfer;
      if (color.disabled) color.checked = false;
    }
    const transparent = byId("transparentBackgroundMode");
    if (transparent) {
      for (const value of ["auto", "complex"]) {
        const option = transparent.querySelector(`option[value="${value}"]`);
        if (option) option.disabled = features.transparent_background === false;
      }
      if (transparent.selectedOptions[0]?.disabled) transparent.value = "off";
    }
    const hand = byId("handDetailerEnabled");
    if (hand) {
      hand.disabled = features.hand_detailer !== true || profile().family === "krea2";
      // Before /api/models finishes, capability is undefined. Keep the checked
      // default so it becomes active as soon as the installed detector is known.
      if (features.hand_detailer === false || profile().family === "krea2") hand.checked = false;
    }
    const foot = byId("footDetailerEnabled");
    if (foot) {
      foot.disabled = features.foot_detailer !== true || profile().family === "krea2";
      if (features.foot_detailer === false || profile().family === "krea2") foot.checked = false;
    }
    const missing = [];
    if (!features.anime6b) missing.push("Anime6B 模型");
    if (!features.seedvr2) missing.push("SeedVR2 节点/权重");
    if (!features.ultimate) missing.push("Ultimate SD Upscale 节点");
    if (!features.face_detailer) missing.push("FaceDetailer 检测器");
    if (!features.hand_detailer) missing.push("手部检测模型");
    if (!features.foot_detailer) missing.push("足部检测模型");
    if (!features.color_transfer) missing.push("ColorTransfer 节点");
    if (!features.transparent_background) missing.push("透明背景抠图节点");
    const status = byId("outputEnhancementAvailability");
    if (status) status.textContent = missing.length
      ? `本机尚不可用：${missing.join("、")}；对应选项已禁用。`
      : "输出增强依赖均已就绪。建议固定种子逐项 A/B，避免同时叠加多个增强。";
    window.outputEnhancementChanged(true);
    window.transparentBackgroundChanged(true);
  }

  window.transparentBackgroundChanged = function (silent) {
    const mode = byId("transparentBackgroundMode")?.value || "off";
    if (byId("transparentComplexControls")) byId("transparentComplexControls").style.display = mode === "complex" ? "block" : "none";
    const info = byId("transparentBackgroundInfo");
    if (info) info.textContent = mode === "auto"
      ? "普通角色自动模式：快速分离主体并输出透明 PNG。"
      : mode === "complex"
        ? "复杂角色模式：启用边缘精修；建议先用默认值，不满意再逐项小幅调整。"
        : "透明输出已关闭，保存普通 RGB 图片。";
    // 左侧抽屉折叠时也能一眼看到当前档位。
    const badge = byId("transparentOutputState");
    if (badge) badge.textContent = mode === "auto" ? "自动抠图" : mode === "complex" ? "精细边缘" : "关闭";
    if (!silent && byId("status")) byId("status").textContent = info?.textContent || "透明背景设置已更新。";
  };

  window.outputEnhancementChanged = function (silent) {
    const mode = byId("outputEnhancementMode")?.value || "off";
    const defaults = OUTPUT_DEFAULTS[mode] || OUTPUT_DEFAULTS.off;
    if (!silent && byId("outputEnhancementScale")) {
      byId("outputEnhancementScale").value = defaults.scale;
      if (mode === "ultimate") {
        if (byId("ultimateSteps")) byId("ultimateSteps").value = 20;
        if (byId("ultimateDenoise")) byId("ultimateDenoise").value = 0.2;
        if (byId("ultimateTileSize")) byId("ultimateTileSize").value = 512;
      } else if (mode === "seedvr2" && byId("seedvrColor")) {
        byId("seedvrColor").value = "lab";
      }
    }
    if (mode !== "off" && byId("illustriousMode")?.value === "hires") {
      byId("illustriousMode").value = "precision";
      if (typeof window.applyIllustriousMode === "function") window.applyIllustriousMode();
    }
    if (byId("ultimateControls")) byId("ultimateControls").style.display = mode === "ultimate" ? "grid" : "none";
    if (byId("seedvrControls")) byId("seedvrControls").style.display = mode === "seedvr2" ? "block" : "none";
    if (byId("faceDetailerControls")) byId("faceDetailerControls").style.display = byId("faceDetailerEnabled")?.checked ? "grid" : "none";
    const limbBlocked = profile().family === "krea2" || !!byId("regionsEnabled")?.checked || byId("illustriousMode")?.value === "repair";
    for (const id of ["handDetailerEnabled", "footDetailerEnabled"]) {
      const control = byId(id);
      if (control) control.disabled = limbBlocked || (id === "handDetailerEnabled" ? !workflowFeatures().hand_detailer : !workflowFeatures().foot_detailer);
    }
    const activeLimbDetailer = ["handDetailerEnabled", "footDetailerEnabled"].some((id) => byId(id)?.checked && !byId(id)?.disabled);
    if (byId("limbDetailerControls")) byId("limbDetailerControls").style.display = activeLimbDetailer ? "grid" : "none";
    if (byId("autoColorControls")) byId("autoColorControls").style.display = byId("autoColorMatchEnabled")?.checked ? "grid" : "none";
    if (byId("outputEnhancementRecommendation")) byId("outputEnhancementRecommendation").textContent = defaults.note;
    if (!silent && byId("status")) {
      const labels = { off: "输出增强已关闭，保持模型原始输出。", anime6b: "Anime6B 已启用，并应用推荐 1.5×。", seedvr2: "SeedVR2 已启用，并应用推荐 1.25× + LAB。", ultimate: "Ultimate SD Upscale 已启用，并应用推荐 1.5×、20 步、0.20 重绘、Tile 512。" };
      byId("status").textContent = labels[mode] || labels.off;
    }
  };

  window.modelAdvancedChanged = function (silent) {
    const mode = byId("modelEnhancementMode")?.value || "off";
    if (byId("freeuControls")) byId("freeuControls").style.display = mode === "freeu_v2" ? "block" : "none";
    if (byId("cfgRescaleControls")) byId("cfgRescaleControls").style.display = mode === "cfg_rescale" ? "block" : "none";
    if (!silent && byId("status")) {
      byId("status").textContent = mode === "off"
        ? "模型增强已关闭，保持原始模型基线。"
        : mode === "freeu_v2"
          ? `FreeU V2 已启用：${byId("freeuPreset")?.selectedOptions[0]?.textContent || "当前推荐组合"}；建议固定种子与关闭状态对比。`
          : "CFG Rescale 已启用，仅用于当前 v-pred 模型。";
    }
  };

  window.vaeModeChanged = function (silent) {
    const tiled = byId("vaeMode")?.value === "tiled";
    if (byId("vaeTiledControls")) byId("vaeTiledControls").style.display = tiled ? "block" : "none";
    if (!silent && byId("status")) {
      byId("status").textContent = tiled
        ? "已启用 Tiled VAE：显存占用更低，但编解码会变慢。"
        : "已恢复标准 VAE 编解码。";
    }
  };

  function wrapPayload() {
    if (typeof window.payload !== "function" || window.payload.__advancedWrapped) return;
    const original = window.payload;
    const wrapped = function () {
      const data = original();
      data.modelEnhancement = {
        mode: byId("modelEnhancementMode")?.value || "off",
        b1: byId("freeuB1")?.value || 1.3,
        b2: byId("freeuB2")?.value || 1.4,
        s1: byId("freeuS1")?.value || 0.9,
        s2: byId("freeuS2")?.value || 0.2,
        multiplier: byId("cfgRescaleMultiplier")?.value || 0.7,
      };
      data.vae = {
        mode: byId("vaeMode")?.value || "standard",
        tileSize: byId("vaeTileSize")?.value || 512,
        overlap: byId("vaeOverlap")?.value || 64,
      };
      data.outputEnhancement = {
        mode: byId("outputEnhancementMode")?.value || "off",
        scale: byId("outputEnhancementScale")?.value || 1.5,
        steps: byId("ultimateSteps")?.value || 20,
        denoise: byId("ultimateDenoise")?.value || 0.2,
        tileSize: byId("ultimateTileSize")?.value || 512,
        seedvrColor: byId("seedvrColor")?.value || "lab",
        faceDetailer: {
          enabled: !!byId("faceDetailerEnabled")?.checked,
          guideSize: byId("faceDetailerGuideSize")?.value || 512,
          steps: byId("faceDetailerSteps")?.value || 12,
          denoise: byId("faceDetailerDenoise")?.value || 0.35,
        },
        limbDetailer: {
          hands: !!byId("handDetailerEnabled")?.checked && !byId("handDetailerEnabled")?.disabled,
          feet: !!byId("footDetailerEnabled")?.checked && !byId("footDetailerEnabled")?.disabled,
          guideSize: byId("limbDetailerGuideSize")?.value || 512,
          steps: byId("limbDetailerSteps")?.value || 12,
          denoise: byId("limbDetailerDenoise")?.value || 0.35,
          handPositive: byId("handDetailerPositive")?.value ?? "",
          handNegative: byId("handDetailerNegative")?.value ?? "",
          footPositive: byId("footDetailerPositive")?.value ?? "",
          footNegative: byId("footDetailerNegative")?.value ?? "",
        },
        colorMatch: {
          enabled: !!byId("autoColorMatchEnabled")?.checked,
          method: byId("autoColorMethod")?.value || "reinhard_lab",
          strength: byId("autoColorStrength")?.value || 0.7,
        },
      };
      data.transparentBackground = {
        mode: byId("transparentBackgroundMode")?.value || "off",
        keepOriginal: byId("transparentKeepOriginal")?.checked !== false,
        detailMethod: byId("transparentDetailMethod")?.value || "GuidedFilter",
        detailErode: byId("transparentDetailErode")?.value || 6,
        detailDilate: byId("transparentDetailDilate")?.value || 6,
        blackPoint: byId("transparentBlackPoint")?.value || 0.01,
        whitePoint: byId("transparentWhitePoint")?.value || 0.99,
        maxMegapixels: byId("transparentMaxMegapixels")?.value || 2,
      };
      return data;
    };
    wrapped.__advancedWrapped = true;
    window.payload = wrapped;
  }

  function wrapProfileRefresh(name) {
    const original = window[name];
    if (typeof original !== "function" || original.__capabilityWrapped) return;
    const wrapped = function (...args) {
      const result = original.apply(this, args);
      syncCapabilities();
      return result;
    };
    wrapped.__capabilityWrapped = true;
    window[name] = wrapped;
  }

  function wrapHiresConflict() {
    const original = window.applyIllustriousMode;
    if (typeof original !== "function" || original.__outputConflictWrapped) return;
    const wrapped = function (...args) {
      if (byId("illustriousMode")?.value === "hires" &&
          byId("outputEnhancementMode")?.value !== "off") {
        byId("outputEnhancementMode").value = "off";
        window.outputEnhancementChanged(true);
      }
      const result = original.apply(this, args);
      window.outputEnhancementChanged(true);
      return result;
    };
    wrapped.__outputConflictWrapped = true;
    window.applyIllustriousMode = wrapped;
  }

  function wrapHiresLockClamp() {
    const original = window.applyIllustriousMode;
    if (typeof original !== "function" || original.__hiresLockWrapped) return;
    const wrapped = function (...args) {
      const result = original.apply(this, args);
      // 换模型时预设会改写 denoise，这里重新按二采目的收紧上限。
      window.updateHiresDenoiseConstraints();
      window.renderHiresStrength();
      return result;
    };
    wrapped.__hiresLockWrapped = true;
    window.applyIllustriousMode = wrapped;
  }

  function wrapTransparentRestore() {
    const original = window.restorePayloadToPanel;
    if (typeof original !== "function" || original.__transparentWrapped) return;
    const wrapped = function (data) {
      const result = original.apply(this, arguments);
      const transparent = data?.transparentBackground || {};
      if (byId("transparentBackgroundMode")) byId("transparentBackgroundMode").value = transparent.mode || "off";
      if (byId("transparentKeepOriginal")) byId("transparentKeepOriginal").checked = transparent.keepOriginal !== false;
      if (byId("transparentDetailMethod")) byId("transparentDetailMethod").value = transparent.detailMethod || "GuidedFilter";
      for (const [id, key, fallback] of [["transparentDetailErode", "detailErode", 6], ["transparentDetailDilate", "detailDilate", 6], ["transparentBlackPoint", "blackPoint", 0.01], ["transparentWhitePoint", "whitePoint", 0.99], ["transparentMaxMegapixels", "maxMegapixels", 2]]) {
        if (byId(id)) byId(id).value = transparent[key] ?? fallback;
      }
      window.transparentBackgroundChanged(true);
      return result;
    };
    wrapped.__transparentWrapped = true;
    window.restorePayloadToPanel = wrapped;
  }

  installPanel();
  wrapPayload();
  wrapProfileRefresh("renderAdvancedRecommendation");
  wrapProfileRefresh("applySamplingProfileForModel");
  wrapProfileRefresh("modelChanged");
  wrapProfileRefresh("toggleRegions");
  wrapHiresConflict();
  wrapHiresLockClamp();
  wrapTransparentRestore();
  syncCapabilities();
})();
