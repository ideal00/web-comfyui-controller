"""Backward-compatible SQLite index for Easy Panel creative state.

The JSON snapshot and job files remain the source of truth for replay.  This
module adds a deliberately one-way, query-oriented index around them.  Every
write is best-effort at the caller boundary, while the individual SQLite
operations use transactions so a failed row cannot leave a half-written
generation behind.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import math
import re
import secrets
import sqlite3
import time
from pathlib import Path, PurePosixPath
from typing import Any, Iterator, Mapping, Sequence
from urllib.parse import urlencode


SCHEMA_VERSION = 1
MAX_PAGE_SIZE = 100
# 收藏组：名称长度、总数量与单个作品可加入的组数上限（防误操作导致的失控元数据）。
GROUP_NAME_LIMIT = 60
MAX_FAVORITE_GROUPS = 200
MAX_GROUPS_PER_GENERATION = 24
# 作品项目：一个项目 = 一次角色/场景创作，可包含多个分区与关联资源。
PROJECT_NAME_LIMIT = 60
PROJECT_SECTION_LIMIT = 24
MAX_PROJECTS = 100
MAX_PROJECT_ITEMS = 500
MAX_PROJECT_LINKS = 120
DEFAULT_PROJECT_SECTIONS = ("基准角色", "日常服装", "战斗服装", "废墟场景", "夜景", "最终精选")
PROJECT_LINK_KINDS = ("lora", "preset", "experiment", "favorite_group")
# 高清二采会把首采图另存为 <前缀>_base_*.png；它只是对照用途，不能当作品代表图。
HIRES_BASE_FILE_MARKER = "_base_"
# 辅助图（对照 / 机位快速预览）子目录：作品库扫描与导入一律跳过。
AUX_SUBFOLDER_PREFIX = "EasyPanel_aux"
MAX_OFFSET = 1_000_000
MAX_LINEAGE_NODES = 100
MAX_SNAPSHOT_TEXT = 2_000_000

SUPPORTED_OPERATIONS = frozenset({
    "txt2img",
    "seed_variant",
    "img2img",
    "inpaint",
    "face_fix",
    "hand_fix",
    "upscale",
    "outfit_change",
    "scene_change",
    "style_change",
    "section_change",
    "flux_edit",
})
KNOWN_STATUSES = frozenset({"queued", "running", "completed", "error", "cancelled", "unknown"})
_STATUS_ALIASES = {
    "complete": "completed",
    "done": "completed",
    "failed": "error",
    "failure": "error",
    "success": "completed",
    "succeeded": "completed",
    "canceled": "cancelled",
    "cancel": "cancelled",
    "pending": "queued",
    "processing": "running",
}
_TERMINAL_STATUSES = frozenset({"completed", "error", "cancelled"})
_LEGACY_ARTIFACT_KEYS = ("outputs", "images", "artifacts")
_LEGACY_IDENTIFIER_KEYS = ("promptId", "prompt_id", "requestId", "request_id")
SORT_FIELDS = {
    "created_at": "g.created_at",
    "updated_at": "g.updated_at",
    "status": "g.status",
    "operation": "g.operation",
    "model": "g.model",
}

_SECRET_KEY_MARKERS = (
    "token",
    "password",
    "passwd",
    "api_key",
    "apikey",
    "authorization",
    "cookie",
    "secret",
)


class CreativeIndexError(ValueError):
    """Raised for invalid index input or an incompatible database."""


def now_ms() -> int:
    return int(time.time() * 1000)


def normalize_operation(value: Any, default: str = "unknown") -> str:
    raw = str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")
    if raw in SUPPORTED_OPERATIONS:
        return raw
    return default if default in SUPPORTED_OPERATIONS or default == "unknown" else "unknown"


def normalize_status(value: Any, default: str = "unknown") -> str:
    if isinstance(value, Mapping):
        value = value.get("status") or value.get("status_str") or value.get("state")
    raw = str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")
    raw = _STATUS_ALIASES.get(raw, raw)
    if raw in KNOWN_STATUSES:
        return raw
    return default if default in KNOWN_STATUSES else "unknown"


def _status_priority(value: str) -> int:
    return {
        "unknown": 0,
        "queued": 1,
        "running": 2,
        "cancelled": 3,
        "error": 4,
        "completed": 5,
    }.get(value, 0)


def _merged_status(old: Any, new: Any) -> str:
    before = normalize_status(old)
    after = normalize_status(new)
    if before in _TERMINAL_STATUSES:
        return before
    if after in _TERMINAL_STATUSES:
        return after
    if _status_priority(after) >= _status_priority(before):
        return after
    return before


def _has_legacy_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (Mapping, Sequence)):
        return bool(value)
    return bool(value)


def _legacy_status_value(record: Mapping[str, Any]) -> str | None:
    if "status" not in record or not _has_legacy_value(record.get("status")):
        return None
    normalized = normalize_status(record.get("status"))
    return normalized if normalized != "unknown" else None


def _legacy_has_outputs(record: Mapping[str, Any]) -> bool:
    return any(_has_legacy_value(record.get(key)) for key in _LEGACY_ARTIFACT_KEYS)


def _legacy_has_error(record: Mapping[str, Any]) -> bool:
    return any(_has_legacy_value(record.get(key)) for key in ("error", "error_json"))


def _legacy_artifacts(record: Mapping[str, Any]) -> list[Any]:
    for key in _LEGACY_ARTIFACT_KEYS:
        value = record.get(key)
        if isinstance(value, list) and value:
            return value
    return []


def infer_legacy_status(record: Mapping[str, Any]) -> str:
    """Infer a status for old snapshot/job rows without an explicit status.

    Explicit terminal states remain authoritative.  Error markers win over
    output-shaped fields so a failed job with partial images is not presented
    as completed.  The remaining evidence is intentionally conservative:
    outputs imply completion, identifiers without outputs imply queued, and
    everything else remains unknown.
    """

    if not isinstance(record, Mapping):
        return "unknown"
    explicit = _legacy_status_value(record)
    if explicit in _TERMINAL_STATUSES:
        return explicit
    if _legacy_has_error(record):
        return "error"
    if _legacy_has_outputs(record):
        return "completed"
    if explicit in {"queued", "running"}:
        return explicit
    if any(_has_legacy_value(record.get(key)) for key in _LEGACY_IDENTIFIER_KEYS):
        return "queued"
    return "unknown"


def _safe_text(value: Any, limit: int = 4096) -> str:
    text = str(value or "").strip()
    return text[:limit]


def _safe_int(value: Any, fallback: int | None = None) -> int | None:
    if isinstance(value, bool):
        return int(value)
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return fallback


def sanitize_json_value(value: Any, depth: int = 0) -> Any:
    """Copy JSON-like data while removing credential-shaped keys.

    Snapshots are already allow-listed by the existing compiler.  The extra
    pass here protects the new database if an older caller supplies a raw
    request or a future field with a credential-looking key.
    """

    if depth > 8:
        return None
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, str):
        return value[:MAX_SNAPSHOT_TEXT]
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for raw_key, raw_value in list(value.items())[:512]:
            key = str(raw_key)[:256]
            lowered = key.casefold().replace("-", "_")
            if any(marker in lowered for marker in _SECRET_KEY_MARKERS):
                continue
            cleaned = sanitize_json_value(raw_value, depth + 1)
            if cleaned is not None:
                result[key] = cleaned
        return result
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
        result_list: list[Any] = []
        for item in list(value)[:512]:
            cleaned = sanitize_json_value(item, depth + 1)
            if cleaned is not None:
                result_list.append(cleaned)
        return result_list
    return None


def _json_text(value: Any) -> str:
    cleaned = sanitize_json_value(value)
    if cleaned is None:
        cleaned = {}
    text = json.dumps(cleaned, ensure_ascii=False, separators=(",", ":"))
    if len(text) > MAX_SNAPSHOT_TEXT:
        return json.dumps({"truncated": True}, ensure_ascii=False)
    return text


def _json_value(text: Any) -> Any:
    try:
        value = json.loads(str(text or "{}"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, (dict, list)) else {}


def _safe_generation_id(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if not re.fullmatch(r"[0-9a-f]{32}", text):
        raise CreativeIndexError("generation_id 无效。")
    return text


def _new_id() -> str:
    return secrets.token_hex(16)


def _flag_value(value: Any) -> bool:
    """Coerce the review flags accepted from web, mobile and JSON stores."""

    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().casefold() in {
        "1", "true", "yes", "on", "star", "favorite", "favourite", "入选", "最佳",
    }


def _note_text(value: Any, limit: int = 2000) -> str:
    return str(value or "").strip()[:limit]


def _normalized_group_name(value: Any) -> str:
    """Collapse whitespace so "  参考 图 " and "参考 图" are the same group."""

    name = " ".join(str(value or "").split())
    if not name:
        raise CreativeIndexError("收藏组名称不能为空。")
    return name[:GROUP_NAME_LIMIT]


def _safe_group_id(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if not re.fullmatch(r"[0-9a-f]{32}", text):
        raise CreativeIndexError("收藏组编号无效。")
    return text


def _groups_for_generation(connection: sqlite3.Connection, generation_id: str) -> list[dict[str, Any]]:
    """Return the 收藏组 of one work, newest name order first."""

    rows = connection.execute(
        "SELECT g.group_id, g.name FROM generation_favorite_groups l "
        "JOIN favorite_groups g ON g.group_id = l.group_id "
        "WHERE l.generation_id = ? ORDER BY g.name COLLATE NOCASE ASC",
        (generation_id,),
    ).fetchall()
    return [{"group_id": str(row["group_id"]), "name": str(row["name"])} for row in rows]


def _group_from_row(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "group_id": str(row["group_id"]),
        "name": str(row["name"]),
        "created_at": int(row["created_at"]),
        "updated_at": int(row["updated_at"]),
    }


def _snapshot_fingerprint(snapshot: Mapping[str, Any]) -> str:
    """读快照里的任务指纹（兼容 input / inference / 顶层三种写法）。"""

    for container in (snapshot, snapshot.get("input"), snapshot.get("inference")):
        if isinstance(container, Mapping):
            value = container.get("fingerprint") or container.get("fingerprints")
            if isinstance(value, Mapping):
                value = value.get("hash")
            text = _safe_text(value, 128).casefold()
            if text:
                return text
    return ""


def _normalized_project_name(value: Any) -> str:
    name = " ".join(str(value or "").split())
    if not name:
        raise CreativeIndexError("项目名称不能为空。")
    return name[:PROJECT_NAME_LIMIT]


def _safe_project_id(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if not re.fullmatch(r"[0-9a-f]{32}", text):
        raise CreativeIndexError("项目编号无效。")
    return text


def _safe_project_sections(value: Any) -> list[str]:
    """项目分区名：去重、限量，空值回退到默认分区。"""

    raw = value if isinstance(value, (list, tuple)) else []
    sections: list[str] = []
    for entry in raw:
        name = " ".join(str(entry or "").split())[:PROJECT_SECTION_LIMIT]
        if name and name not in sections:
            sections.append(name)
        if len(sections) >= 16:
            break
    return sections or list(DEFAULT_PROJECT_SECTIONS)


def _safe_link_kind(value: Any) -> str:
    kind = str(value or "").strip().casefold()
    if kind not in PROJECT_LINK_KINDS:
        raise CreativeIndexError("项目关联类型无效。")
    return kind


def is_hires_base_filename(value: Any) -> bool:
    """True for the first-pass hires image (``<prefix>_base_00001_.png``)."""

    return HIRES_BASE_FILE_MARKER in Path(str(value or "")).name


def is_aux_subfolder(value: Any) -> bool:
    """辅助图目录（``EasyPanel_aux``）下的文件不进作品库。"""

    parts = [part for part in str(value or "").replace("\\", "/").split("/") if part]
    return AUX_SUBFOLDER_PREFIX in parts


#: artifact 角色：作品库只把 'final' 当主图，'comparison' 是首采对照图，
#: 'intermediate' 是流程中间产物；文件名推断只作为 legacy 回退。
ARTIFACT_ROLE_FINAL = "final"
ARTIFACT_ROLE_COMPARISON = "comparison"
ARTIFACT_ROLE_INTERMEDIATE = "intermediate"
ARTIFACT_ROLE_VALUES = (ARTIFACT_ROLE_FINAL, ARTIFACT_ROLE_COMPARISON, ARTIFACT_ROLE_INTERMEDIATE)

#: 输出文件在 history 回来后可能还在写盘：这段宽限期内保持 file_state=pending，
#: 不标 missing、不删除记录；超时后才当作真的缺失。
PENDING_FILE_GRACE_MS = 10 * 60 * 1000


def _artifact_role_for(filename: str, image_type: str, kind: str) -> str:
    """Derive the artifact role; explicit values win in ``normalize_artifact_ref``."""

    if kind != "output" or image_type != "output":
        return ARTIFACT_ROLE_INTERMEDIATE if image_type == "output" else ""
    return ARTIFACT_ROLE_COMPARISON if is_hires_base_filename(filename) else ARTIFACT_ROLE_FINAL


#: artifact_stage：这一步产物来自流程的哪一段（与 role 是“是什么/从哪来”两个维度）。
ARTIFACT_STAGE_VALUES = ("base", "highres", "detail_refine", "face", "hand", "upscale")


def _artifact_stage_value(ref: Mapping[str, Any], stage: str) -> str:
    """显式 stage > 首采对照固定 base > 调用方声明的流程 stage。"""

    value = str(ref.get("artifact_stage") or "").strip().casefold()
    if value:
        return value[:32]
    if (str(ref.get("artifact_role") or "") == ARTIFACT_ROLE_COMPARISON
            or is_hires_base_filename(ref.get("filename"))):
        return "base"
    return str(stage or "").strip().casefold()[:32]


def _is_comparison_artifact(item: Any) -> bool:
    """首采对照图（不是成品）：角色优先，文件名只做旧数据回退。"""

    try:
        role = str(item["artifact_role"] or "")
    except (IndexError, KeyError, TypeError):
        role = ""
    if role:
        return role == ARTIFACT_ROLE_COMPARISON
    try:
        filename = item["filename"]
    except (IndexError, KeyError, TypeError):
        filename = ""
    return is_hires_base_filename(filename)


def _file_key(subfolder: Any, filename: Any) -> str:
    """作品的磁盘身份：``subfolder/filename``（输出目录内相对路径）。

    导入扫描、跨作品重复检测、删除墓碑都用同一个键，避免同一张图产生两条记录。
    """

    sub = str(subfolder or "").replace("\\", "/").strip("/")
    name = str(filename or "").replace("\\", "/").strip()
    if not name or name in {".", ".."} or Path(name).name != name:
        return ""
    if ".." in PurePosixPath(name).parts:
        return ""
    return f"{sub}/{name}" if sub else name


def _stat_file(root: Path, subfolder: str, filename: str) -> tuple[bool, int, int]:
    """Return ``(exists, file_size, mtime_ms)``; traversal outside root reports missing."""

    candidate = (root / Path(subfolder) / Path(filename).name).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        return (False, 0, 0)
    if not candidate.is_file():
        return (False, 0, 0)
    try:
        stat = candidate.stat()
    except OSError:
        return (False, 0, 0)
    return (True, int(stat.st_size), int(stat.st_mtime * 1000))


def _artifact_exists(row: sqlite3.Row) -> bool:
    metadata = _json_value(row["metadata_json"])
    return not (isinstance(metadata, Mapping) and metadata.get("exists") is False)


def _preview_artifact_row(connection: sqlite3.Connection, generation_id: str) -> sqlite3.Row | None:
    """Return the single artifact that represents a work everywhere.

    列表缩略图、详情大图与手机端预览必须指向同一张图。高清二采会同时产出首采图
    与二采成品，而 ComfyUI 两个 SaveImage 的落盘顺序并不稳定，所以代表图要显式选
    择：非首采、文件仍存在的最后一张输出；实在只剩首采时才退回用它。
    """

    rows = connection.execute(
        "SELECT * FROM artifacts WHERE generation_id = ? AND image_type = 'output' "
        "ORDER BY created_at DESC, artifact_id DESC",
        (generation_id,),
    ).fetchall()
    if not rows:
        rows = connection.execute(
            "SELECT * FROM artifacts WHERE generation_id = ? "
            "ORDER BY created_at DESC, artifact_id DESC",
            (generation_id,),
        ).fetchall()
    usable = [row for row in rows if _artifact_exists(row)]
    # 角色优先：显式 artifact_role='final' 才是主作品，不再只靠文件名和时间猜。
    for row in usable:
        if _row_text(row, "artifact_role", 32) == ARTIFACT_ROLE_FINAL:
            return row
    for row in usable:
        if not is_hires_base_filename(row["filename"]):
            return row
    if usable:
        return usable[0]
    # 所有输出都已损坏/被覆盖：宁可不给缩略图，也不能指向别人的图。
    return None


def _row_flag(row: sqlite3.Row, name: str) -> bool:
    """Read a 0/1 column that may be absent from a not-yet-migrated row."""

    try:
        return bool(row[name])
    except (IndexError, KeyError):
        return False


def _row_int(row: sqlite3.Row, name: str) -> int:
    try:
        return int(row[name] or 0)
    except (IndexError, KeyError, TypeError, ValueError):
        return 0


def _row_text(row: sqlite3.Row, name: str, limit: int = 2000) -> str:
    try:
        return str(row[name] or "")[:limit]
    except (IndexError, KeyError):
        return ""


_STABLE_ID_NAMESPACE = "easy-panel:creative-index:stable-id:v1"


def _stable_id(namespace: str, value: Any) -> str:
    """Return a rebuildable, namespaced 128-bit hexadecimal identifier."""

    canonical = json.dumps(
        sanitize_json_value(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    material = f"{_STABLE_ID_NAMESPACE}:{namespace}:{canonical}".encode("utf-8")
    return hashlib.sha256(material).hexdigest()[:32]


def _stable_generation_id(
    snapshot: Mapping[str, Any],
    *,
    snapshot_id: str | None = None,
    prompt_id: str = "",
    request_id: str = "",
) -> str:
    """Derive a stable generation ID without using secrets or timestamps.

    Source identifiers are intentionally ordered from the strongest native
    identity to a sanitized complete-record fingerprint.  The explicit kind
    in the digest input prevents the same text used by two source systems from
    collapsing into one namespace.
    """

    for kind, value in (
        ("snapshot_id", snapshot_id),
        ("prompt_id", prompt_id),
        ("request_id", request_id),
    ):
        clean = _safe_text(value, 4096)
        if clean:
            return _stable_id("generation", {"kind": kind, "value": clean})
    return _stable_id("generation", {"kind": "record", "value": sanitize_json_value(snapshot)})


def _stable_artifact_id(generation_id: str, artifact: Mapping[str, Any]) -> str:
    """Derive an artifact ID from its owning generation and safe reference."""

    return _stable_id(
        "artifact",
        {
            "generation_id": generation_id,
            "filename": _safe_text(artifact.get("filename"), 512),
            "subfolder": _safe_text(artifact.get("subfolder"), 512),
            "type": _safe_text(artifact.get("image_type"), 32),
            "kind": _safe_text(artifact.get("artifact_kind"), 32),
        },
    )


def _stable_key(prefix: str, value: Any) -> str:
    canonical = json.dumps(sanitize_json_value(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return f"{prefix}-{hashlib.sha256(canonical.encode('utf-8')).hexdigest()[:32]}"


def _normalise_subfolder(value: Any) -> str:
    raw = str(value or "").replace("\\", "/").strip("/")
    if not raw:
        return ""
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise CreativeIndexError("artifact subfolder 无效。")
    return "/".join(path.parts)[:512]


def normalize_artifact_ref(raw: Any, output_root: Path | None = None) -> tuple[dict[str, Any] | None, str | None]:
    """Validate a ComfyUI image reference and optionally verify its file."""

    if isinstance(raw, Mapping):
        filename = str(raw.get("filename") or raw.get("name") or "").strip()
        subfolder = str(raw.get("subfolder") or "")
        image_type = str(raw.get("type") or raw.get("image_type") or "output").strip()
        kind = str(raw.get("artifact_kind") or raw.get("kind") or "output").strip().casefold()
        metadata = raw.get("metadata") if isinstance(raw.get("metadata"), Mapping) else {}
        declared_role = str(raw.get("artifact_role") or raw.get("role") or "").strip().casefold()
    else:
        filename = str(raw or "").strip()
        subfolder = ""
        image_type = "output"
        kind = "output"
        metadata = {}
        declared_role = ""
    filename = filename.replace("\\", "/")
    if not filename or Path(filename).name != filename or filename in {".", ".."}:
        return None, "图片文件名包含路径或为空，已跳过。"
    if ".." in PurePosixPath(filename).parts:
        return None, "图片文件名包含路径穿越片段，已跳过。"
    try:
        subfolder = _normalise_subfolder(subfolder)
    except CreativeIndexError as exc:
        return None, str(exc)
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", image_type):
        image_type = "output"
    if kind not in {"output", "intermediate"}:
        kind = "output"
    safe_metadata = sanitize_json_value(metadata)
    if not isinstance(safe_metadata, dict):
        safe_metadata = {}
    if declared_role not in ARTIFACT_ROLE_VALUES:
        declared_role = _artifact_role_for(filename, image_type, kind)
    exists: bool | None = True
    if output_root is not None:
        root = Path(output_root).resolve()
        candidate = (root / Path(subfolder) / filename).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            return None, "图片路径超出输出目录，已跳过。"
        exists, size, mtime = _stat_file(root, subfolder, filename)
        if not exists:
            return {
                "filename": filename,
                "subfolder": subfolder,
                "image_type": image_type,
                "artifact_kind": kind,
                "artifact_role": declared_role,
                "metadata": {**safe_metadata, "exists": False, "file_state": "missing"},
            }, f"图片不存在，已保留记录：{filename}"
        safe_metadata.update({"file_state": "ready", "file_size": size, "file_mtime": mtime})
    safe_metadata["exists"] = exists
    return {
        "filename": filename,
        "subfolder": subfolder,
        "image_type": image_type,
        "artifact_kind": kind,
        "artifact_role": declared_role,
        "metadata": safe_metadata,
    }, None


def artifact_url(filename: str, subfolder: str = "", image_type: str = "output") -> str:
    query = {"name": filename, "type": image_type or "output"}
    if subfolder:
        query["subfolder"] = subfolder
    return "/api/rpg/image?" + urlencode(query)


# 受保护的作品：手动收藏、加入收藏组、或被作品项目引用
_PROTECTED_SELECT = """
    SELECT g.generation_id FROM generations g
    WHERE g.favorite = 1
       OR EXISTS (SELECT 1 FROM generation_favorite_groups fg WHERE fg.generation_id = g.generation_id)
       OR EXISTS (SELECT 1 FROM project_items pi WHERE pi.generation_id = g.generation_id)
"""


def _comfy_record_from_png(path: Path) -> dict[str, Any] | None:
    """从 ComfyUI 写入 PNG 的 prompt 元数据里还原生成参数（快照 JSON 上线前的作品只能这么补）。"""

    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        with Image.open(path) as image:
            raw = image.info.get("prompt")
            size = image.size
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(raw, str) or not raw.strip():
        return None
    try:
        graph = json.loads(raw)
    except (TypeError, ValueError):
        return None
    if not isinstance(graph, Mapping):
        return None

    model = ""
    seed: Any = None
    positive = ""
    negative = ""
    loras: list[dict[str, Any]] = []
    for node in graph.values():
        if not isinstance(node, Mapping):
            continue
        class_type = str(node.get("class_type") or "")
        inputs = node.get("inputs") if isinstance(node.get("inputs"), Mapping) else {}
        meta = node.get("_meta") if isinstance(node.get("_meta"), Mapping) else {}
        title = str(meta.get("title") or "").lower()
        if class_type == "CheckpointLoaderSimple":
            model = model or str(inputs.get("ckpt_name") or "")
        elif class_type in {"UNETLoader", "DiffusionModelLoader"}:
            model = model or str(inputs.get("unet_name") or "")
        elif class_type.startswith("KSampler"):
            seed = seed if seed is not None else inputs.get("seed")
        elif class_type.startswith("LoraLoader"):
            name = str(inputs.get("lora_name") or "")
            if name:
                try:
                    weight = float(inputs.get("strength_model"))
                except (TypeError, ValueError):
                    weight = 1.0
                loras.append({"name": name, "weight": weight})
        elif class_type == "CLIPTextEncode" and isinstance(inputs.get("text"), str):
            text = str(inputs["text"])
            if not text.strip():
                continue
            if "negative" in title and not negative:
                negative = text
            elif not positive:
                positive = text
    return {
        "model": model,
        "seed": seed,
        "width": int(size[0]),
        "height": int(size[1]),
        "positive": positive,
        "negative": negative,
        "loras": loras,
    }


class CreativeIndex:
    """Transactional SQLite index with safe legacy import helpers."""

    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()

    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(str(self.path), timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def _purged_ids(self, connection: sqlite3.Connection, generation_ids: Any) -> set[str]:
        wanted = [str(item) for item in (generation_ids or ()) if item]
        if not wanted:
            return set()
        found: set[str] = set()
        for start in range(0, len(wanted), 400):
            piece = wanted[start:start + 400]
            marks = ",".join("?" for _ in piece)
            found.update(str(row[0]) for row in connection.execute(
                f"SELECT generation_id FROM purged_generations WHERE generation_id IN ({marks})", piece))
        return found

    def _mark_purged(self, connection: sqlite3.Connection, generation_ids: Any, reason: str = "") -> None:
        """记下被删除的作品编号，避免 legacy JSON 重新导入时“复活”。"""

        stamp = now_ms()
        rows = [(str(item), stamp, str(reason)[:80]) for item in (generation_ids or ()) if item]
        if rows:
            connection.executemany(
                "INSERT OR REPLACE INTO purged_generations(generation_id, purged_at, reason) "
                "VALUES(?, ?, ?)", rows)

    def _mark_purged_files(self, connection: sqlite3.Connection, file_keys: Any,
                           reason: str = "") -> None:
        """按磁盘身份写墓碑：同名文件被删除后，输出扫描不会再把它导回来。"""

        stamp = now_ms()
        rows = []
        for key in file_keys or ():
            clean = str(key or "").strip()
            if clean:
                rows.append((clean, stamp, str(reason)[:80]))
        if rows:
            connection.executemany(
                "INSERT OR REPLACE INTO purged_files(file_key, purged_at, reason) "
                "VALUES(?, ?, ?)", rows)

    def _ensure_schema(self, connection: sqlite3.Connection) -> None:
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
            )
            row = connection.execute(
                "SELECT value FROM schema_meta WHERE key = 'schema_version'"
            ).fetchone()
            current = _safe_int(row[0], 0) if row else 0
            if current is None:
                current = 0
            if current > SCHEMA_VERSION:
                raise CreativeIndexError(
                    f"创作索引版本 {current} 高于当前支持版本 {SCHEMA_VERSION}。"
                )
            # Version 0 was the pre-index state.  The CREATE IF NOT EXISTS
            # calls make an empty database upgradeable, while the column pass
            # below also repairs a partially-created v0 database without
            # rewriting any legacy JSON source file.
            self._create_schema_v1(connection)
            self._ensure_schema_v1_columns(connection)
            self._create_schema_v1_indexes(connection)
            connection.execute(
                # INSERT OR REPLACE works with the older SQLite builds that
                # ship in some desktop Python distributions as well as new
                # SQLite, and this tiny metadata table has no dependent FK.
                "INSERT OR REPLACE INTO schema_meta(key, value) VALUES('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )
            connection.commit()
        except Exception:
            connection.rollback()
            raise

    @staticmethod
    def _ensure_schema_v1_columns(connection: sqlite3.Connection) -> None:
        """Apply additive v1 migrations to a database made by an older build.

        SQLite cannot add a primary key or foreign-key constraint with ALTER
        TABLE.  Such a malformed legacy table is rejected explicitly; normal
        v0 databases (which had no index tables) are created by
        ``_create_schema_v1`` above.  All v1 fields that can be added safely
        are declared with defaults so an interrupted migration remains
        retryable.
        """

        added: list[tuple[str, str]] = []
        expected: dict[str, dict[str, str]] = {
            "generations": {
                "snapshot_id": "TEXT",
                "prompt_id": "TEXT NOT NULL DEFAULT ''",
                "request_id": "TEXT NOT NULL DEFAULT ''",
                "operation": "TEXT NOT NULL DEFAULT 'unknown'",
                "status": "TEXT NOT NULL DEFAULT 'unknown'",
                "created_at": "INTEGER NOT NULL DEFAULT 0",
                "updated_at": "INTEGER NOT NULL DEFAULT 0",
                "schema_version": "INTEGER NOT NULL DEFAULT 0",
                "panel_version": "TEXT NOT NULL DEFAULT ''",
                "workflow_version": "TEXT NOT NULL DEFAULT ''",
                "inference_version": "TEXT NOT NULL DEFAULT ''",
                "model": "TEXT NOT NULL DEFAULT ''",
                "seed": "TEXT",
                "width": "INTEGER",
                "height": "INTEGER",
                "quality": "TEXT NOT NULL DEFAULT ''",
                "input_json": "TEXT NOT NULL DEFAULT '{}'",
                "compiled_json": "TEXT NOT NULL DEFAULT '{}'",
                "inference_json": "TEXT NOT NULL DEFAULT '{}'",
                "workflow_json": "TEXT NOT NULL DEFAULT '{}'",
                "snapshot_json": "TEXT NOT NULL DEFAULT '{}'",
                "error_json": "TEXT NOT NULL DEFAULT '{}'",
                # Review fields are additive and default-valued, so an older
                # database keeps working and the migration stays retryable.
                "favorite": "INTEGER NOT NULL DEFAULT 0",
                "rating": "INTEGER NOT NULL DEFAULT 0",
                "note": "TEXT NOT NULL DEFAULT ''",
                "fingerprint": "TEXT NOT NULL DEFAULT ''",
            },
            "artifacts": {
                "generation_id": "TEXT",
                "filename": "TEXT NOT NULL DEFAULT ''",
                "subfolder": "TEXT NOT NULL DEFAULT ''",
                "image_type": "TEXT NOT NULL DEFAULT 'output'",
                "artifact_kind": "TEXT NOT NULL DEFAULT 'output'",
                "artifact_role": "TEXT NOT NULL DEFAULT ''",
                "artifact_stage": "TEXT NOT NULL DEFAULT ''",
                "metadata_json": "TEXT NOT NULL DEFAULT '{}'",
                "created_at": "INTEGER NOT NULL DEFAULT 0",
            },
            "derivations": {
                "parent_generation_id": "TEXT",
                "child_generation_id": "TEXT",
                "parent_artifact_id": "TEXT",
                "child_artifact_id": "TEXT",
                "operation": "TEXT NOT NULL DEFAULT 'unknown'",
                "created_at": "INTEGER NOT NULL DEFAULT 0",
                "metadata_json": "TEXT NOT NULL DEFAULT '{}'",
            },
            "generation_loras": {
                "generation_id": "TEXT",
                "position": "INTEGER NOT NULL DEFAULT 0",
                "name": "TEXT NOT NULL DEFAULT ''",
                "weight": "TEXT",
                "trigger": "TEXT NOT NULL DEFAULT ''",
                "role": "TEXT NOT NULL DEFAULT 'other'",
                "source": "TEXT NOT NULL DEFAULT ''",
                "metadata_json": "TEXT NOT NULL DEFAULT '{}'",
            },
        }
        for table, columns in expected.items():
            actual = {
                str(row[1])
                for row in connection.execute(f"PRAGMA table_info({table})").fetchall()
            }
            if not actual:
                continue
            if table == "generations" and "generation_id" not in actual:
                raise CreativeIndexError("旧创作索引缺少 generations.generation_id，无法安全迁移。")
            if table == "artifacts" and "artifact_id" not in actual:
                raise CreativeIndexError("旧创作索引缺少 artifacts.artifact_id，无法安全迁移。")
            if table == "derivations" and "derivation_id" not in actual:
                raise CreativeIndexError("旧创作索引缺少 derivations.derivation_id，无法安全迁移。")
            for name, declaration in columns.items():
                if name not in actual:
                    connection.execute(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")
                    added.append((table, name))
        if ("artifacts", "artifact_role") in added:
            # 旧库回填角色：_base_ 文件是首采对照图，其余输出当作成品。
            connection.execute(
                "UPDATE artifacts SET artifact_role = CASE "
                "WHEN filename LIKE '%\\_base\\_%' ESCAPE '\\' THEN 'comparison' "
                "ELSE 'final' END "
                "WHERE image_type = 'output' AND artifact_kind = 'output' AND artifact_role = ''"
            )
        if ("artifacts", "artifact_stage") in added:
            # 旧库只能从文件名识别首采图；其余 stage 无法回溯，保持空。
            connection.execute(
                "UPDATE artifacts SET artifact_stage = 'base' "
                "WHERE image_type = 'output' AND artifact_stage = '' "
                "AND filename LIKE '%\\_base\\_%' ESCAPE '\\'"
            )

    @staticmethod
    def _create_schema_v1(connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS generations (
                generation_id TEXT PRIMARY KEY,
                snapshot_id TEXT UNIQUE,
                prompt_id TEXT NOT NULL DEFAULT '',
                request_id TEXT NOT NULL DEFAULT '',
                operation TEXT NOT NULL DEFAULT 'unknown',
                status TEXT NOT NULL DEFAULT 'unknown',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                schema_version INTEGER NOT NULL DEFAULT 0,
                panel_version TEXT NOT NULL DEFAULT '',
                workflow_version TEXT NOT NULL DEFAULT '',
                inference_version TEXT NOT NULL DEFAULT '',
                model TEXT NOT NULL DEFAULT '',
                seed TEXT,
                width INTEGER,
                height INTEGER,
                quality TEXT NOT NULL DEFAULT '',
                input_json TEXT NOT NULL DEFAULT '{}',
                compiled_json TEXT NOT NULL DEFAULT '{}',
                inference_json TEXT NOT NULL DEFAULT '{}',
                workflow_json TEXT NOT NULL DEFAULT '{}',
                snapshot_json TEXT NOT NULL DEFAULT '{}',
                error_json TEXT NOT NULL DEFAULT '{}',
                favorite INTEGER NOT NULL DEFAULT 0,
                rating INTEGER NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT '',
                fingerprint TEXT NOT NULL DEFAULT ''
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS artifacts (
                artifact_id TEXT PRIMARY KEY,
                generation_id TEXT REFERENCES generations(generation_id) ON DELETE CASCADE,
                filename TEXT NOT NULL,
                subfolder TEXT NOT NULL DEFAULT '',
                image_type TEXT NOT NULL DEFAULT 'output',
                artifact_kind TEXT NOT NULL DEFAULT 'output',
                artifact_role TEXT NOT NULL DEFAULT '',
                artifact_stage TEXT NOT NULL DEFAULT '',
                metadata_json TEXT NOT NULL DEFAULT '{}',
                created_at INTEGER NOT NULL,
                UNIQUE(generation_id, filename, subfolder, image_type, artifact_kind)
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS derivations (
                derivation_id TEXT PRIMARY KEY,
                parent_generation_id TEXT REFERENCES generations(generation_id) ON DELETE CASCADE,
                child_generation_id TEXT REFERENCES generations(generation_id) ON DELETE CASCADE,
                parent_artifact_id TEXT REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
                child_artifact_id TEXT REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
                operation TEXT NOT NULL DEFAULT 'unknown',
                created_at INTEGER NOT NULL,
                metadata_json TEXT NOT NULL DEFAULT '{}',
                CHECK(parent_generation_id IS NOT NULL OR parent_artifact_id IS NOT NULL),
                CHECK(child_generation_id IS NOT NULL OR child_artifact_id IS NOT NULL)
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS generation_loras (
                generation_id TEXT NOT NULL REFERENCES generations(generation_id) ON DELETE CASCADE,
                position INTEGER NOT NULL,
                name TEXT NOT NULL,
                weight TEXT,
                trigger TEXT NOT NULL DEFAULT '',
                role TEXT NOT NULL DEFAULT 'other',
                source TEXT NOT NULL DEFAULT '',
                metadata_json TEXT NOT NULL DEFAULT '{}',
                PRIMARY KEY(generation_id, position)
            )
            """
        )
        # 用户自命名的收藏组：与 generations 多对多，删除作品/删除组都会自动清理关联，
        # 且不存储任何生成参数，因此不会影响复现与谱系。
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS favorite_groups (
                group_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS generation_favorite_groups (
                generation_id TEXT NOT NULL REFERENCES generations(generation_id) ON DELETE CASCADE,
                group_id TEXT NOT NULL REFERENCES favorite_groups(group_id) ON DELETE CASCADE,
                created_at INTEGER NOT NULL,
                PRIMARY KEY(generation_id, group_id)
            )
            """
        )
        # 作品项目：把「一张一张生图」升级成「做一个角色作品」。
        # projects 存项目本身与分区定义，project_items 存项目内的作品（可分区、可排序、
        # 可加备注），project_links 存 LoRA / Prompt 预设 / 实验 / 收藏组等关联资源。
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS projects (
                project_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                sections_json TEXT NOT NULL DEFAULT '[]',
                favorites_group_id TEXT NOT NULL DEFAULT '',
                cover_artifact_id TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS project_items (
                item_id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
                generation_id TEXT REFERENCES generations(generation_id) ON DELETE CASCADE,
                section TEXT NOT NULL DEFAULT '',
                position INTEGER NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                UNIQUE(project_id, generation_id)
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS project_links (
                link_id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
                kind TEXT NOT NULL DEFAULT 'lora',
                ref TEXT NOT NULL DEFAULT '',
                label TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                UNIQUE(project_id, kind, ref)
            )
            """
        )

    @staticmethod
    def _create_schema_v1_indexes(connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS purged_generations (
                generation_id TEXT PRIMARY KEY,
                purged_at INTEGER NOT NULL,
                reason TEXT NOT NULL DEFAULT ''
            )
            """
        )
        # 文件级墓碑：删除作品后，导入扫描不会再把同一张图建成新记录。
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS purged_files (
                file_key TEXT PRIMARY KEY,
                purged_at INTEGER NOT NULL DEFAULT 0,
                reason TEXT NOT NULL DEFAULT ''
            )
            """
        )
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generations_created ON generations(created_at DESC)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generations_updated ON generations(updated_at DESC)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generations_prompt ON generations(prompt_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generations_request ON generations(request_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_artifacts_generation ON artifacts(generation_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_derivations_parent ON derivations(parent_generation_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_derivations_child ON derivations(child_generation_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generation_favorite_groups_group ON generation_favorite_groups(group_id)")
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_favorite_groups_name "
            "ON favorite_groups(name COLLATE NOCASE)"
        )
        connection.execute("CREATE INDEX IF NOT EXISTS idx_generations_fingerprint ON generations(fingerprint)")
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_name ON projects(name COLLATE NOCASE)"
        )
        connection.execute("CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at DESC)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_project_items_project ON project_items(project_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_project_items_generation ON project_items(generation_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_project_links_project ON project_links(project_id)")

    @contextlib.contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            self._ensure_schema(connection)
            yield connection
        finally:
            connection.close()

    @contextlib.contextmanager
    def _write_transaction(self) -> Iterator[sqlite3.Connection]:
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def initialize(self) -> int:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT value FROM schema_meta WHERE key = 'schema_version'"
            ).fetchone()
            return _safe_int(row[0], SCHEMA_VERSION) if row else SCHEMA_VERSION

    @staticmethod
    def _snapshot_parts(snapshot: Mapping[str, Any]) -> tuple[dict, dict, dict, dict, dict]:
        payload = snapshot.get("payload") if isinstance(snapshot.get("payload"), Mapping) else {}
        source = snapshot.get("source") if isinstance(snapshot.get("source"), Mapping) else {}
        compiled = snapshot.get("compiled") if isinstance(snapshot.get("compiled"), Mapping) else {}
        workflow = snapshot.get("workflow") if isinstance(snapshot.get("workflow"), Mapping) else {}
        environment = snapshot.get("environment") if isinstance(snapshot.get("environment"), Mapping) else {}
        return dict(payload), dict(source), dict(compiled), dict(workflow), dict(environment)

    @staticmethod
    def _snapshot_operation(snapshot: Mapping[str, Any], explicit: Any = "") -> str:
        explicit_raw = str(explicit or "").strip().casefold()
        chosen = normalize_operation(explicit, "unknown")
        if chosen != "unknown":
            return chosen
        workflow = snapshot.get("workflow") if isinstance(snapshot.get("workflow"), Mapping) else {}
        raw = str(workflow.get("operation") or snapshot.get("operation") or "").casefold()
        # 快照自己声明的操作码优先（例如 flux_edit）：以前只认旧列表里的
        # 几个值，任何新操作都会被降级成 unknown，作品库就丢了这个标签。
        declared = normalize_operation(raw, "unknown")
        if declared != "unknown":
            return declared
        if explicit_raw == "unknown" or (explicit_raw and explicit_raw not in {"panel.generate", "rpg.generate"}):
            return "unknown"
        if "upscale" in raw:
            return "upscale"
        if "inpaint" in raw or "repair" in raw:
            return "inpaint"
        if "img2img" in raw:
            return "img2img"
        return "txt2img" if raw in {"", "panel.generate", "rpg.generate"} else "unknown"

    @classmethod
    def _snapshot_record_values(
        cls,
        snapshot: Mapping[str, Any],
        *,
        operation: Any = "",
        status: Any = "unknown",
        prompt_id: Any = "",
        request_id: Any = "",
    ) -> dict[str, Any]:
        payload, source, compiled, workflow, environment = cls._snapshot_parts(snapshot)
        source_generation = source.get("generation") if isinstance(source.get("generation"), Mapping) else {}
        payload_generation = payload.get("generation") if isinstance(payload.get("generation"), Mapping) else {}
        generation = {**dict(payload_generation), **dict(source_generation)}
        client = payload.get("client") if isinstance(payload.get("client"), Mapping) else {}
        snapshot_id = _safe_text(snapshot.get("id") or snapshot.get("snapshot_id"), 128) or None
        prompt = _safe_text(prompt_id or snapshot.get("promptId") or snapshot.get("prompt_id"), 128)
        request = _safe_text(request_id or snapshot.get("requestId") or snapshot.get("request_id"), 128)
        if not request:
            request = _safe_text(client.get("requestId") or client.get("request_id"), 128)
        model = _safe_text(source.get("checkpoint") or payload.get("model") or generation.get("model"), 800)
        seed = generation.get("seed") if generation.get("seed") is not None else payload.get("seed")
        if seed is not None:
            seed = _safe_text(seed, 128)
        width = _safe_int(generation.get("width") or payload.get("width"))
        height = _safe_int(generation.get("height") or payload.get("height"))
        quality = _safe_text(generation.get("quality") or payload.get("quality"), 80)
        created = _safe_int(snapshot.get("createdAt") or snapshot.get("created_at"), now_ms()) or now_ms()
        schema_version = _safe_int(snapshot.get("schemaVersion") or snapshot.get("schema_version"), 0) or 0
        panel_version = _safe_text(environment.get("panelVersion") or snapshot.get("panelVersion"), 80)
        workflow_version = _safe_text(
            workflow.get("version") or workflow.get("workflowVersion") or panel_version,
            80,
        )
        inference_version = _safe_text(
            environment.get("inferenceVersion") or environment.get("panelVersion") or panel_version,
            80,
        )
        inference = {
            "generation": generation,
            "environment": environment,
            "modelStrategy": source.get("modelStrategy", {}),
        }
        return {
            "snapshot_id": snapshot_id,
            "prompt_id": prompt,
            "request_id": request,
            "operation": cls._snapshot_operation(snapshot, operation),
            "status": normalize_status(status, "unknown"),
            "created_at": created,
            "schema_version": schema_version,
            "panel_version": panel_version,
            "workflow_version": workflow_version,
            "inference_version": inference_version,
            "model": model,
            "seed": seed,
            "width": width,
            "height": height,
            "quality": quality,
            "input_json": _json_text(payload or source),
            "compiled_json": _json_text(compiled),
            "inference_json": _json_text(inference),
            "workflow_json": _json_text(workflow),
            "snapshot_json": _json_text(snapshot),
            "error_json": _json_text(snapshot.get("error") or {}),
        }

    @staticmethod
    def _extract_loras(snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
        payload, source, _compiled, _workflow, _environment = CreativeIndex._snapshot_parts(snapshot)
        raw = source.get("loras")
        if not isinstance(raw, list) or not raw:
            raw = payload.get("loras")
        if not isinstance(raw, list) or not raw:
            raw = list(payload.get("characterLoras") or []) + list(payload.get("styleLoras") or [])
        result: list[dict[str, Any]] = []
        for item in raw[:128]:
            if isinstance(item, str):
                item = {"name": item}
            if not isinstance(item, Mapping):
                continue
            name = _safe_text(item.get("name"), 800)
            if not name:
                continue
            role = _safe_text(item.get("role"), 40).casefold() or "other"
            if role not in {"character", "style", "other"}:
                role = "other"
            weight = item.get("weight")
            if weight is not None:
                weight = _safe_text(weight, 80)
            result.append({
                "name": name,
                "weight": weight,
                "trigger": _safe_text(item.get("trigger"), 2400),
                "role": role,
                "source": _safe_text(item.get("source") or item.get("sourceKind"), 80),
                "metadata": sanitize_json_value(item),
            })
        return result

    @staticmethod
    def _snapshot_artifacts(snapshot: Mapping[str, Any]) -> list[Any]:
        return _legacy_artifacts(snapshot)

    @staticmethod
    def _find_existing(
        connection: sqlite3.Connection,
        snapshot_id: str | None,
        prompt_id: str,
        request_id: str,
    ) -> sqlite3.Row | None:
        if snapshot_id:
            row = connection.execute(
                "SELECT * FROM generations WHERE snapshot_id = ?", (snapshot_id,)
            ).fetchone()
            if row:
                return row
        if prompt_id:
            row = connection.execute(
                "SELECT * FROM generations WHERE prompt_id = ? ORDER BY updated_at DESC LIMIT 1",
                (prompt_id,),
            ).fetchone()
            if row:
                return row
        if request_id:
            return connection.execute(
                "SELECT * FROM generations WHERE request_id = ? ORDER BY updated_at DESC LIMIT 1",
                (request_id,),
            ).fetchone()
        return None

    def _upsert_artifacts(
        self,
        connection: sqlite3.Connection,
        generation_id: str,
        outputs: Sequence[Any],
        output_root: Path | None,
        *,
        warnings: list[str],
        pending_files: frozenset[str] = frozenset(),
        stage: str = "",
    ) -> list[str]:
        artifact_ids: list[str] = []
        for raw in list(outputs)[:128]:
            ref, warning = normalize_artifact_ref(raw, output_root)
            if warning:
                warnings.append(warning)
            if not ref:
                continue
            if ref["filename"] in pending_files:
                # 文件还在写：标记 pending（不是 missing），reconcile 会继续落定。
                ref["metadata"] = {**ref["metadata"], "exists": False, "file_state": "pending"}
            metadata_json = _json_text(ref["metadata"])
            stage_value = _artifact_stage_value(ref, stage)
            existing = connection.execute(
                """SELECT artifact_id FROM artifacts
                   WHERE generation_id = ? AND filename = ? AND subfolder = ?
                     AND image_type = ? AND artifact_kind = ?""",
                (
                    generation_id,
                    ref["filename"],
                    ref["subfolder"],
                    ref["image_type"],
                    ref["artifact_kind"],
                ),
            ).fetchone()
            if existing:
                artifact_id = str(existing[0])
                # 后续回写（对账 / 状态同步）可能拿不到阶段：不能把已经记录的
                # artifact_stage 清掉，否则作品会丢掉“从哪一步来”的信息。
                connection.execute(
                    "UPDATE artifacts SET metadata_json = ?, artifact_role = ?, "
                    "artifact_stage = CASE WHEN ? <> '' THEN ? ELSE artifact_stage END "
                    "WHERE artifact_id = ?",
                    (metadata_json, ref.get("artifact_role") or "", stage_value, stage_value, artifact_id),
                )
            else:
                # 同一张图只能属于一条作品：如果扫描导入先建了空壳记录，就把文件
                # 移交给真实作品并删掉空壳；否则拒绝重复登记（避免作品库里两张一样的图）。
                conflict = connection.execute(
                    """SELECT artifact_id, generation_id FROM artifacts
                       WHERE filename = ? AND subfolder = ? AND image_type = ? AND generation_id <> ?
                       ORDER BY created_at ASC LIMIT 1""",
                    (ref["filename"], ref["subfolder"], ref["image_type"], generation_id),
                ).fetchone()
                adopted = ""
                if conflict:
                    # 只接手“导入扫描产生的空壳”：真实作品之间的同名（历史编号回退、
                    # ComfyUI 覆写旧文件）保留原样，由 mark_duplicate_artifacts_missing()
                    # 按“最新为准”统一标记，避免破坏既有修复语义。
                    if self._adopt_imported_shell(
                        connection,
                        str(conflict["generation_id"]),
                        generation_id,
                        str(conflict["artifact_id"]),
                        metadata_json=metadata_json,
                        role=ref.get("artifact_role") or "",
                    ):
                        adopted = str(conflict["artifact_id"])
                if adopted:
                    artifact_id = adopted
                else:
                    artifact_id = _stable_artifact_id(generation_id, ref)
                    collision = connection.execute(
                        """SELECT generation_id, filename, subfolder, image_type, artifact_kind
                           FROM artifacts WHERE artifact_id = ?""",
                        (artifact_id,),
                    ).fetchone()
                    if collision:
                        identity = (generation_id, ref["filename"], ref["subfolder"], ref["image_type"], ref["artifact_kind"])
                        existing_identity = tuple(collision[column] for column in (
                            "generation_id", "filename", "subfolder", "image_type", "artifact_kind",
                        ))
                        if existing_identity != identity:
                            raise CreativeIndexError("artifact_id 稳定哈希冲突，已拒绝写入。")
                    connection.execute(
                        """INSERT INTO artifacts(
                               artifact_id, generation_id, filename, subfolder, image_type,
                               artifact_kind, artifact_role, artifact_stage, metadata_json, created_at
                           ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            artifact_id,
                            generation_id,
                            ref["filename"],
                            ref["subfolder"],
                            ref["image_type"],
                            ref["artifact_kind"],
                            ref.get("artifact_role") or "",
                            stage_value,
                            metadata_json,
                            now_ms(),
                        ),
                    )
            artifact_ids.append(artifact_id)
        return artifact_ids

    @staticmethod
    def _adopt_imported_shell(
        connection: sqlite3.Connection,
        source_generation_id: str,
        target_generation_id: str,
        artifact_id: str,
        *,
        metadata_json: str,
        role: str,
    ) -> bool:
        """把「输出扫描导入的空壳记录」的文件移交给真实作品。

        仅当来源记录是 imported、且没有任何用户数据（收藏/评分/备注/收藏组/项目/
        谱系）且只有这一个 artifact 时才会接手；迁移后删掉空壳行（先改归属再删，
        否则 ON DELETE CASCADE 会把 artifact 一起带走）。
        """

        if not source_generation_id or source_generation_id == target_generation_id:
            return False
        row = connection.execute(
            "SELECT operation, favorite, rating, note FROM generations WHERE generation_id = ?",
            (source_generation_id,),
        ).fetchone()
        if row is None:
            return False
        if str(row["operation"] or "") != "imported":
            return False
        if _row_flag(row, "favorite") or _row_int(row, "rating") or _row_text(row, "note", 1).strip():
            return False
        for sql, params in (
            ("SELECT 1 FROM generation_favorite_groups WHERE generation_id = ? LIMIT 1",
             (source_generation_id,)),
            ("SELECT 1 FROM project_items WHERE generation_id = ? LIMIT 1",
             (source_generation_id,)),
            ("SELECT 1 FROM derivations WHERE parent_generation_id = ? OR child_generation_id = ? LIMIT 1",
             (source_generation_id, source_generation_id)),
        ):
            if connection.execute(sql, params).fetchone():
                return False
        count = connection.execute(
            "SELECT COUNT(*) FROM artifacts WHERE generation_id = ?", (source_generation_id,)
        ).fetchone()[0]
        if int(count or 0) > 1:
            return False
        connection.execute(
            "UPDATE artifacts SET generation_id = ?, metadata_json = ?, artifact_role = ? "
            "WHERE artifact_id = ?",
            (target_generation_id, metadata_json, role, artifact_id),
        )
        connection.execute("DELETE FROM generations WHERE generation_id = ?", (source_generation_id,))
        return True

    @staticmethod
    def _insert_derivation(
        connection: sqlite3.Connection,
        *,
        parent_generation_id: str = "",
        child_generation_id: str = "",
        parent_artifact_id: str = "",
        child_artifact_id: str = "",
        operation: Any = "unknown",
        metadata: Any = None,
    ) -> bool:
        parent_generation_id = str(parent_generation_id or "")
        child_generation_id = str(child_generation_id or "")
        parent_artifact_id = str(parent_artifact_id or "")
        child_artifact_id = str(child_artifact_id or "")
        if not (parent_generation_id or parent_artifact_id) or not (child_generation_id or child_artifact_id):
            return False
        if parent_generation_id and not connection.execute(
            "SELECT 1 FROM generations WHERE generation_id = ?", (parent_generation_id,)
        ).fetchone():
            return False
        if child_generation_id and not connection.execute(
            "SELECT 1 FROM generations WHERE generation_id = ?", (child_generation_id,)
        ).fetchone():
            return False
        if parent_artifact_id and not connection.execute(
            "SELECT 1 FROM artifacts WHERE artifact_id = ?", (parent_artifact_id,)
        ).fetchone():
            return False
        if child_artifact_id and not connection.execute(
            "SELECT 1 FROM artifacts WHERE artifact_id = ?", (child_artifact_id,)
        ).fetchone():
            return False
        op = normalize_operation(operation)
        existing = connection.execute(
            """SELECT derivation_id FROM derivations
               WHERE COALESCE(parent_generation_id, '') = ?
                 AND COALESCE(child_generation_id, '') = ?
                 AND COALESCE(parent_artifact_id, '') = ?
                 AND COALESCE(child_artifact_id, '') = ?
                 AND operation = ? LIMIT 1""",
            (parent_generation_id, child_generation_id, parent_artifact_id, child_artifact_id, op),
        ).fetchone()
        if existing:
            return False
        connection.execute(
            """INSERT INTO derivations(
                   derivation_id, parent_generation_id, child_generation_id,
                   parent_artifact_id, child_artifact_id, operation, created_at, metadata_json
               ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                _new_id(),
                parent_generation_id or None,
                child_generation_id or None,
                parent_artifact_id or None,
                child_artifact_id or None,
                op,
                now_ms(),
                _json_text(metadata or {}),
            ),
        )
        return True

    def add_derivation(
        self,
        *,
        parent_generation_id: Any = "",
        child_generation_id: Any = "",
        parent_artifact_id: Any = "",
        child_artifact_id: Any = "",
        operation: Any = "unknown",
        metadata: Any = None,
    ) -> bool:
        """Add one lineage edge, or return False when either side is unknown.

        This is intentionally a narrow index-only operation.  It never edits
        the source snapshot/job JSON and is idempotent for the same endpoints
        and operation.
        """

        with self._write_transaction() as connection:
            return self._insert_derivation(
                connection,
                parent_generation_id=_safe_text(parent_generation_id, 128),
                child_generation_id=_safe_text(child_generation_id, 128),
                parent_artifact_id=_safe_text(parent_artifact_id, 128),
                child_artifact_id=_safe_text(child_artifact_id, 128),
                operation=operation,
                metadata=metadata,
            )

    def import_output_images(
        self,
        output_root: str | Path,
        *,
        prefix: str = "EasyPanel_",
        limit: int = 0,
    ) -> dict[str, Any]:
        """扫描输出目录，把没有记录的成品图按 PNG 元数据补进作品库（只新增，不改已有记录）。

        快照 JSON 上线之前的作品没有任何 JSON 记录，只能靠 ComfyUI 写进 PNG 的
        ``prompt`` 元数据还原模型、seed、尺寸与提示词。
        """

        import hashlib

        root = Path(output_root).expanduser()
        if not root.is_dir():
            raise CreativeIndexError(f"输出目录不存在：{root}")
        connection = self._connect()
        try:
            self._ensure_schema(connection)
            known = {
                (str(row["filename"]), str(row["subfolder"] or ""))
                for row in connection.execute("SELECT filename, subfolder FROM artifacts")
            }
            purged = {str(row[0]) for row in connection.execute(
                "SELECT generation_id FROM purged_generations")}
            purged_files = {str(row[0]) for row in connection.execute(
                "SELECT file_key FROM purged_files")}
        finally:
            connection.close()

        candidates: list[tuple[Path, str]] = []
        for path in sorted(root.rglob("*.png")):
            if not path.name.startswith(prefix):
                continue
            relative = path.relative_to(root)
            subfolder = "" if str(relative.parent) == "." else relative.parent.as_posix()
            if is_aux_subfolder(subfolder):
                # EasyPanel_aux 里是首采对照 / 机位预览这类辅助图，不当作品入库。
                continue
            if (path.name, subfolder) in known:
                continue
            candidates.append((path, subfolder))
        if limit > 0:
            candidates = candidates[:limit]

        imported = 0
        skipped = 0
        failed: list[str] = []
        for path, subfolder in candidates:
            key = _file_key(subfolder, path.name)
            if key and key in purged_files:
                # 用户删过这张图：不再自动导回（文件重生成时文件名会变）。
                skipped += 1
                continue
            record = _comfy_record_from_png(path)
            if record is None:
                skipped += 1
                continue
            generation_id = hashlib.sha256(
                f"import:{subfolder}/{path.name}".encode("utf-8")).hexdigest()[:32]
            if generation_id in purged:
                skipped += 1
                continue
            artifact_id = hashlib.sha256(
                f"artifact:{generation_id}:{path.name}".encode("utf-8")).hexdigest()[:32]
            created_at = int(path.stat().st_mtime * 1000)
            exists, size, mtime = _stat_file(Path(str(root)).resolve(), subfolder, path.name)
            artifact_metadata = {
                "exists": exists,
                "file_state": "ready" if exists else "missing",
                "file_size": size,
                "file_mtime": mtime,
            }
            payload = {
                "positivePrompt": record["positive"],
                "negativePrompt": record["negative"],
                "loras": record["loras"],
                "importedFrom": "output-scan",
            }
            try:
                with self._write_transaction() as conn:
                    conn.execute(
                        """INSERT OR IGNORE INTO generations(
                               generation_id, prompt_id, request_id, operation, status,
                               created_at, updated_at, model, seed, width, height,
                               input_json, compiled_json, fingerprint)
                           VALUES(?, '', '', 'imported', 'completed', ?, ?, ?, ?, ?, ?, ?, ?, '')""",
                        (
                            generation_id,
                            created_at,
                            created_at,
                            record["model"],
                            None if record["seed"] is None else str(record["seed"]),
                            record["width"],
                            record["height"],
                            _json_text(payload),
                            _json_text(payload),
                        ),
                    )
                    conn.execute(
                        """INSERT OR IGNORE INTO artifacts(
                               artifact_id, generation_id, filename, subfolder,
                               image_type, artifact_kind, artifact_role, metadata_json, created_at)
                           VALUES(?, ?, ?, ?, 'output', 'output', ?, ?, ?)""",
                        (artifact_id, generation_id, path.name, subfolder,
                         _artifact_role_for(path.name, "output", "output"),
                         _json_text(artifact_metadata), created_at),
                    )
                    for position, lora in enumerate(record["loras"]):
                        conn.execute(
                            """INSERT INTO generation_loras(
                                   generation_id, position, name, weight, trigger, role, source, metadata_json
                               ) VALUES(?, ?, ?, ?, '', '', 'import', '{}')""",
                            (generation_id, position, lora["name"], lora["weight"]),
                        )
            except Exception as error:  # noqa: BLE001
                failed.append(f"{path.name}: {error}")
                continue
            imported += 1
        return {
            "scanned": len(candidates),
            "imported": imported,
            "skipped": skipped,
            "errors": failed[:20],
            "output_root": str(root),
        }

    def upsert_snapshot(
        self,
        snapshot: Mapping[str, Any],
        *,
        operation: Any = "",
        status: Any = "queued",
        prompt_id: Any = "",
        request_id: Any = "",
        output_root: str | Path | None = None,
        parent_generation_id: Any = "",
        parent_artifact_id: Any = "",
    ) -> dict[str, Any]:
        if not isinstance(snapshot, Mapping):
            raise CreativeIndexError("snapshot 必须是 JSON 对象。")
        values = self._snapshot_record_values(
            snapshot,
            operation=operation,
            status=status,
            prompt_id=prompt_id,
            request_id=request_id,
        )
        output_path = Path(output_root).expanduser() if output_root is not None else None
        warnings: list[str] = []
        with self._write_transaction() as connection:
            existing = self._find_existing(
                connection,
                values["snapshot_id"],
                values["prompt_id"],
                values["request_id"],
            )
            created = existing is None
            generation_id = str(existing["generation_id"]) if existing else _stable_generation_id(
                snapshot,
                snapshot_id=values["snapshot_id"],
                prompt_id=values["prompt_id"],
                request_id=values["request_id"],
            )
            if created and self._purged_ids(connection, [generation_id]):
                # 用户删掉过的作品不再从 legacy JSON 里被重新导入。
                return {"created": False, "updated": False, "purged": True,
                        "generation_id": generation_id}
            merged_status = _merged_status(existing["status"], values["status"]) if existing else values["status"]
            created_at = int(existing["created_at"]) if existing else values["created_at"]
            row_values = {**values, "status": merged_status, "created_at": created_at, "updated_at": now_ms(),
                          "fingerprint": _snapshot_fingerprint(snapshot)}
            columns = (
                "generation_id", "snapshot_id", "prompt_id", "request_id", "operation", "status",
                "created_at", "updated_at", "schema_version", "panel_version", "workflow_version",
                "inference_version", "model", "seed", "width", "height", "quality", "input_json",
                "compiled_json", "inference_json", "workflow_json", "snapshot_json", "error_json",
                "fingerprint",
            )
            if created:
                connection.execute(
                    f"INSERT INTO generations({', '.join(columns)}) VALUES({', '.join('?' for _ in columns)})",
                    tuple(generation_id if column == "generation_id" else row_values[column] for column in columns),
                )
            else:
                assignments = ", ".join(f"{column} = ?" for column in columns if column != "generation_id")
                connection.execute(
                    f"UPDATE generations SET {assignments} WHERE generation_id = ?",
                    tuple(row_values[column] for column in columns if column != "generation_id") + (generation_id,),
                )
            connection.execute("DELETE FROM generation_loras WHERE generation_id = ?", (generation_id,))
            for position, lora in enumerate(self._extract_loras(snapshot)):
                connection.execute(
                    """INSERT INTO generation_loras(
                           generation_id, position, name, weight, trigger, role, source, metadata_json
                       ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        generation_id,
                        position,
                        lora["name"],
                        lora["weight"],
                        lora["trigger"],
                        lora["role"],
                        lora["source"],
                        _json_text(lora["metadata"]),
                    ),
                )
            artifact_ids = self._upsert_artifacts(
                connection,
                generation_id,
                self._snapshot_artifacts(snapshot),
                output_path,
                warnings=warnings,
            )
            parent_generation = _safe_text(parent_generation_id, 64)
            parent_artifact = _safe_text(parent_artifact_id, 64)
            if not parent_generation and isinstance(snapshot.get("derivation"), Mapping):
                derivation = snapshot["derivation"]
                parent_generation = _safe_text(derivation.get("parentGenerationId") or derivation.get("parent_generation_id"), 64)
                parent_artifact = _safe_text(derivation.get("parentArtifactId") or derivation.get("parent_artifact_id"), 64)
            if parent_generation or parent_artifact:
                self._insert_derivation(
                    connection,
                    parent_generation_id=parent_generation,
                    child_generation_id=generation_id,
                    parent_artifact_id=parent_artifact,
                    child_artifact_id=artifact_ids[0] if artifact_ids else "",
                    operation=row_values["operation"],
                    metadata={"source": "snapshot"},
                )
            row = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (generation_id,)
            ).fetchone()
            return {
                "generation_id": generation_id,
                "created": created,
                "warnings": warnings,
                "generation": self._summary_from_row(connection, row),
            }

    def update_snapshot_status(
        self,
        snapshot_id: Any,
        *,
        status: Any,
        images: Sequence[Any] = (),
        comparison_images: Sequence[Any] = (),
        pending_files: Sequence[Any] = (),
        stage: Any = "",
        output_root: str | Path | None = None,
    ) -> dict[str, Any] | None:
        wanted = _safe_text(snapshot_id, 128)
        if not wanted:
            return None
        output_path = Path(output_root).expanduser() if output_root is not None else None
        pending_set = frozenset(Path(str(name)).name for name in (pending_files or ())
                                if str(name).strip())
        warnings: list[str] = []
        with self._write_transaction() as connection:
            row = connection.execute(
                "SELECT * FROM generations WHERE snapshot_id = ?", (wanted,)
            ).fetchone()
            if not row:
                return None
            next_status = _merged_status(row["status"], status)
            connection.execute(
                "UPDATE generations SET status = ?, updated_at = ? WHERE generation_id = ?",
                (next_status, now_ms(), row["generation_id"]),
            )
            self._upsert_artifacts(
                connection,
                str(row["generation_id"]),
                list(images),
                output_path,
                warnings=warnings,
                pending_files=pending_set,
                stage=str(stage or ""),
            )
            # 首采对照图也登记，但角色是 comparison、stage 固定 base。
            self._upsert_artifacts(
                connection,
                str(row["generation_id"]),
                list(comparison_images),
                output_path,
                warnings=warnings,
                stage=str(stage or ""),
            )
            latest = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (row["generation_id"],)
            ).fetchone()
            return {
                "generation_id": str(row["generation_id"]),
                "warnings": warnings,
                "generation": self._summary_from_row(connection, latest),
            }

    def update_job(
        self,
        *,
        prompt_id: Any = "",
        request_id: Any = "",
        snapshot_id: Any = "",
        status: Any = "unknown",
        images: Sequence[Any] = (),
        comparison_images: Sequence[Any] = (),
        pending_files: Sequence[Any] = (),
        stage: Any = "",
        output_root: str | Path | None = None,
    ) -> dict[str, Any] | None:
        wanted_snapshot = _safe_text(snapshot_id, 128)
        wanted_prompt = _safe_text(prompt_id, 128)
        wanted_request = _safe_text(request_id, 128)
        output_path = Path(output_root).expanduser() if output_root is not None else None
        pending_set = frozenset(Path(str(name)).name for name in (pending_files or ())
                                if str(name).strip())
        warnings: list[str] = []
        with self._write_transaction() as connection:
            row = self._find_existing(connection, wanted_snapshot or None, wanted_prompt, wanted_request)
            if not row:
                return None
            next_status = _merged_status(row["status"], status)
            connection.execute(
                """UPDATE generations
                   SET prompt_id = CASE WHEN ? <> '' THEN ? ELSE prompt_id END,
                       request_id = CASE WHEN ? <> '' THEN ? ELSE request_id END,
                       status = ?, updated_at = ?
                   WHERE generation_id = ?""",
                (
                    wanted_prompt,
                    wanted_prompt,
                    wanted_request,
                    wanted_request,
                    next_status,
                    now_ms(),
                    row["generation_id"],
                ),
            )
            self._upsert_artifacts(
                connection,
                str(row["generation_id"]),
                list(images),
                output_path,
                warnings=warnings,
                pending_files=pending_set,
                stage=str(stage or ""),
            )
            self._upsert_artifacts(
                connection,
                str(row["generation_id"]),
                list(comparison_images),
                output_path,
                warnings=warnings,
                stage=str(stage or ""),
            )
            latest = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (row["generation_id"],)
            ).fetchone()
            return {
                "generation_id": str(row["generation_id"]),
                "warnings": warnings,
                "generation": self._summary_from_row(connection, latest),
            }

    def list_unfinished_jobs(self, *, limit: Any = 1000) -> list[dict[str, Any]]:
        """Return indexed jobs that still need ComfyUI status reconciliation.

        The creative index is intentionally a query-oriented projection.  A
        server-side reconciler needs only stable identifiers, not the full
        snapshot payload, so keep this result narrow and cheap to read.
        """

        page_limit = max(1, min(1000, _safe_int(limit, 1000) or 1000))
        with self._connection() as connection:
            rows = connection.execute(
                """SELECT generation_id, snapshot_id, prompt_id, request_id, status,
                          created_at, updated_at
                   FROM generations
                   WHERE status IN ('queued', 'running') AND prompt_id <> ''
                   ORDER BY updated_at ASC, generation_id ASC
                   LIMIT ?""",
                (page_limit,),
            ).fetchall()
        return [
            {
                "generation_id": str(row["generation_id"]),
                "snapshot_id": str(row["snapshot_id"] or ""),
                "prompt_id": str(row["prompt_id"] or ""),
                "request_id": str(row["request_id"] or ""),
                "status": normalize_status(row["status"]),
                "created_at": int(row["created_at"] or 0),
                "updated_at": int(row["updated_at"] or 0),
            }
            for row in rows
        ]

    @staticmethod
    def _summary_from_row(connection: sqlite3.Connection, row: sqlite3.Row | None) -> dict[str, Any]:
        if row is None:
            return {}
        generation_id = str(row["generation_id"])
        # 高清二采的首采对照图（artifact_role='comparison'）不是成品：数量与列表
        # 都不计入，否则作品库里会同时出现“原图”和成品，看起来像重复生成。
        artifact_rows = connection.execute(
            "SELECT filename, artifact_role, metadata_json FROM artifacts WHERE generation_id = ?",
            (generation_id,),
        ).fetchall()
        artifact_count = sum(1 for item in artifact_rows if not _is_comparison_artifact(item))
        # 文件还在写盘（file_state='pending'）：列表要能显示“保存中”，而不是让
        # 用户以为作品库坏了（图片打不开）。
        pending_count = 0
        for item in artifact_rows:
            if _is_comparison_artifact(item):
                continue
            metadata = _json_value(item["metadata_json"])
            if isinstance(metadata, Mapping) and str(metadata.get("file_state") or "") == "pending":
                pending_count += 1
        parent_count = connection.execute(
            "SELECT COUNT(*) FROM derivations WHERE child_generation_id = ?", (generation_id,)
        ).fetchone()[0]
        child_count = connection.execute(
            "SELECT COUNT(*) FROM derivations WHERE parent_generation_id = ?", (generation_id,)
        ).fetchone()[0]
        lora_count = connection.execute(
            "SELECT COUNT(*) FROM generation_loras WHERE generation_id = ?", (generation_id,)
        ).fetchone()[0]
        thumbnail_url = None
        preview_row = _preview_artifact_row(connection, generation_id)
        primary_artifact_id = ""
        primary_stage = ""
        if preview_row is not None:
            primary_artifact_id = str(preview_row["artifact_id"])
            primary_stage = _row_text(preview_row, "artifact_stage", 32)
            thumbnail_url = artifact_url(
                str(preview_row["filename"]),
                str(preview_row["subfolder"]),
                str(preview_row["image_type"]),
            )
        return {
            "generation_id": generation_id,
            "snapshot_id": row["snapshot_id"] or None,
            "prompt_id": row["prompt_id"] or None,
            "request_id": row["request_id"] or None,
            "operation": normalize_operation(row["operation"]),
            "status": normalize_status(row["status"]),
            "created_at": int(row["created_at"]),
            "updated_at": int(row["updated_at"]),
            "schema_version": int(row["schema_version"]),
            "panel_version": row["panel_version"] or "",
            "workflow_version": row["workflow_version"] or "",
            "inference_version": row["inference_version"] or "",
            "model": row["model"] or "",
            "seed": row["seed"],
            "width": row["width"],
            "height": row["height"],
            "quality": row["quality"] or "",
            "favorite": _row_flag(row, "favorite"),
            "rating": _row_int(row, "rating"),
            "note": _row_text(row, "note"),
            "fingerprint": _row_text(row, "fingerprint"),
            "groups": _groups_for_generation(connection, generation_id),
            "lora_count": int(lora_count),
            "artifact_count": int(artifact_count),
            "pending_artifacts": int(pending_count),
            "file_state": "pending" if pending_count else "ready",
            "parent_count": int(parent_count),
            "child_count": int(child_count),
            # 列表、桌面详情与手机详情共用同一个代表图，避免小图与大图不一致。
            "primary_artifact_id": primary_artifact_id or None,
            "stage": primary_stage,
            "thumbnail_url": thumbnail_url,
        }

    @staticmethod
    def _artifact_from_row(row: sqlite3.Row) -> dict[str, Any]:
        metadata = _json_value(row["metadata_json"])
        if not isinstance(metadata, dict):
            metadata = {}
        exists = metadata.get("exists")
        return {
            "artifact_id": str(row["artifact_id"]),
            "generation_id": row["generation_id"],
            "filename": str(row["filename"]),
            "subfolder": str(row["subfolder"] or ""),
            "type": str(row["image_type"] or "output"),
            "kind": str(row["artifact_kind"] or "output"),
            "role": _row_text(row, "artifact_role", 32),
            "stage": _row_text(row, "artifact_stage", 32),
            "exists": exists,
            "metadata": metadata,
            "url": artifact_url(str(row["filename"]), str(row["subfolder"] or ""), str(row["image_type"] or "output"))
            if exists is not False else None,
            "created_at": int(row["created_at"]),
        }

    def _loras_for_generation(self, connection: sqlite3.Connection, generation_id: str) -> list[dict[str, Any]]:
        rows = connection.execute(
            "SELECT * FROM generation_loras WHERE generation_id = ? ORDER BY position ASC",
            (generation_id,),
        ).fetchall()
        return [
            {
                "position": int(row["position"]),
                "name": row["name"],
                "weight": row["weight"],
                "trigger": row["trigger"],
                "role": row["role"],
                "source": row["source"],
                "metadata": _json_value(row["metadata_json"]),
            }
            for row in rows
        ]

    def get_generation(self, generation_id: Any, *, include_hires_base: bool = False) -> dict[str, Any] | None:
        wanted = _safe_generation_id(generation_id)
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            if not row:
                return None
            summary = self._summary_from_row(connection, row)
            artifacts = connection.execute(
                "SELECT * FROM artifacts WHERE generation_id = ? ORDER BY created_at ASC, artifact_id ASC",
                (wanted,),
            ).fetchall()
            # 旧记录里曾把二采的首采图一并存下来：默认不再返回给作品库，
            # 角色优先（comparison），旧记录没有角色时回退文件名。
            # 需要核对时可用 include_hires_base=True 取回（数据本身不删）。
            every_artifact = [self._artifact_from_row(item) for item in artifacts]
            visible = [item for item in every_artifact if not _is_comparison_artifact(item)]
            hires_base_count = len(every_artifact) - len(visible)
            preview_row = _preview_artifact_row(connection, wanted)
            snapshot = _json_value(row["snapshot_json"])
            input_value = _json_value(row["input_json"])
            compiled = _json_value(row["compiled_json"])
            inference = _json_value(row["inference_json"])
            workflow = _json_value(row["workflow_json"])
            return {
                **summary,
                "input": input_value,
                "compiled": compiled,
                "inference": inference,
                "workflow": workflow,
                "snapshot": snapshot,
                "error": _json_value(row["error_json"]),
                "loras": self._loras_for_generation(connection, wanted),
                "artifacts": every_artifact if include_hires_base else visible,
                "hires_base_count": hires_base_count,
                # 与列表缩略图完全同一张图：客户端直接用 preview 显示大图。
                "preview": self._artifact_from_row(preview_row) if preview_row is not None else None,
                "replay": {
                    "can_submit": False,
                    "action": "restore_to_form",
                    "payload": input_value,
                    "operation": normalize_operation(row["operation"]),
                    "seed": row["seed"],
                    "note": "仅恢复到现有编辑/生成表单；必须由用户显式点击生成。",
                },
                "variation": {
                    "can_submit": False,
                    "action": "restore_to_form",
                    "payload": input_value,
                    "operation": normalize_operation(row["operation"]),
                    "seed": None,
                    "note": "变化版只预览恢复参数；换 Seed 后仍必须由用户显式点击生成。",
                },
            }

    def generation_for_output(self, filename: Any, subfolder: Any = "") -> str:
        """按成品文件名反查它属于哪条生成（FLUX 修图自动记录父子谱系用）。

        同名多引用时取最新的一条；找不到返回空字符串。
        """

        name = str(filename or "").replace("\\", "/").strip()
        if not name:
            return ""
        folder = str(subfolder or "").replace("\\", "/").strip("/")
        rows = None
        with self._connection() as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                "SELECT a.generation_id, a.metadata_json FROM artifacts a "
                "JOIN generations g ON g.generation_id = a.generation_id "
                "WHERE a.filename = ? AND COALESCE(a.subfolder, '') = ? "
                "ORDER BY g.created_at DESC, a.created_at DESC LIMIT 4",
                (name, folder),
            ).fetchall()
        for row in rows or []:
            metadata = _json_value(row["metadata_json"])
            if isinstance(metadata, dict) and metadata.get("exists") is False:
                continue
            return str(row["generation_id"])
        return str(rows[0]["generation_id"]) if rows else ""

    def mark_duplicate_artifacts_missing(self, *, limit: int = 200) -> dict[str, int]:
        """同名图片被多条作品引用时，只保留最新那条，其余标记缺失。

        ComfyUI 的 SaveImage 计数器一旦回退（重启、清理、换目录）就会重新使用旧
        编号并覆盖旧图，旧记录于是指向别人的图。图片本体已无法找回，与其显示错图，
        不如标记 exists=false 让作品库换成占位。新生成已使用唯一前缀，不会再发生。
        """

        bounded = max(1, min(1000, _safe_int(limit, 200) or 200))
        marked = 0
        groups = 0
        with self._write_transaction() as connection:
            rows = connection.execute(
                "SELECT filename, subfolder, image_type FROM artifacts "
                "GROUP BY filename, subfolder, image_type HAVING COUNT(DISTINCT generation_id) > 1 "
                "LIMIT ?",
                (bounded,),
            ).fetchall()
            for group in rows:
                groups += 1
                owners = connection.execute(
                    "SELECT a.artifact_id, a.metadata_json FROM artifacts a "
                    "JOIN generations g ON g.generation_id = a.generation_id "
                    "WHERE a.filename = ? AND a.subfolder = ? AND a.image_type = ? "
                    "ORDER BY g.created_at DESC, a.created_at DESC",
                    (str(group["filename"]), str(group["subfolder"]), str(group["image_type"])),
                ).fetchall()
                for owner in owners[1:]:
                    metadata = _json_value(owner["metadata_json"])
                    if not isinstance(metadata, dict):
                        metadata = {}
                    if metadata.get("exists") is False:
                        continue
                    metadata["exists"] = False
                    metadata["reason"] = "同名图片已被后续任务覆盖（ComfyUI 文件名编号回退）。"
                    connection.execute(
                        "UPDATE artifacts SET metadata_json = ? WHERE artifact_id = ?",
                        (_json_text(metadata), str(owner["artifact_id"])),
                    )
                    marked += 1
        return {"marked": marked, "groups": groups}

    def prune_missing_outputs(self, output_root: Any, *, limit: int = 400) -> dict[str, int]:
        """Delete generations whose recorded output images no longer exist on disk.

        Works in place over a bounded number of terminal generations that already
        have at least one recorded output artifact.  For every scanned generation
        each output artifact is re-checked against ``output_root``; artifact
        ``metadata.exists`` is refreshed to the current on-disk state.  Files
        recorded as ``file_state='pending'`` (history returned before the write
        finished) stay pending during ``PENDING_FILE_GRACE_MS`` and are never
        treated as deletion evidence until the grace window expires.  A
        generation is only deleted when none of its output files survive, which
        removes its artifacts, derivations and LoRA rows through ON DELETE
        CASCADE.  Queued/running rows (which usually have no artifacts yet) are
        never touched.  Returns counts of scanned/pruned/refreshed items.
        """

        root = Path(str(output_root)).resolve()
        scan_limit = max(1, min(4000, int(limit)))
        pruned: list[str] = []
        pending_kept = 0
        scanned = 0
        refreshed = 0
        current_ms = now_ms()
        with self._write_transaction() as connection:
            rows = connection.execute(
                """
                SELECT DISTINCT g.generation_id, g.updated_at
                FROM generations g
                JOIN artifacts a ON a.generation_id = g.generation_id
                WHERE g.status IN ('completed', 'error', 'cancelled', 'unknown')
                  AND a.image_type = 'output'
                ORDER BY g.updated_at DESC, g.generation_id ASC
                LIMIT ?
                """,
                (scan_limit,),
            ).fetchall()
            for row in rows:
                scanned += 1
                generation_id = str(row["generation_id"])
                generation_age = current_ms - (_safe_int(row["updated_at"], current_ms) or current_ms)
                artifacts = connection.execute(
                    """SELECT artifact_id, filename, subfolder, image_type, metadata_json
                       FROM artifacts
                       WHERE generation_id = ? AND image_type = 'output'
                       ORDER BY created_at ASC, artifact_id ASC""",
                    (generation_id,),
                ).fetchall()
                exists_any = False
                pending_any = False
                for artifact in artifacts:
                    filename = str(artifact["filename"] or "")
                    subfolder = str(artifact["subfolder"] or "").replace("\\", "/").strip("/")
                    exists, size, mtime = _stat_file(root, subfolder, filename)
                    exists_any = exists_any or exists
                    metadata = _json_value(artifact["metadata_json"])
                    if not isinstance(metadata, Mapping):
                        metadata = {}
                    else:
                        metadata = dict(metadata)
                    was_pending = str(metadata.get("file_state") or "") == "pending"
                    updates = {"exists": exists,
                               "file_state": "ready" if exists else "missing"}
                    if exists:
                        updates.update({"file_size": size, "file_mtime": mtime})
                    elif was_pending and generation_age < PENDING_FILE_GRACE_MS:
                        # 还在写盘：保持 pending，不当作删除依据。
                        updates = {"exists": False, "file_state": "pending"}
                        pending_any = True
                    if any(metadata.get(key) != value for key, value in updates.items()):
                        metadata.update(updates)
                        connection.execute(
                            "UPDATE artifacts SET metadata_json = ? WHERE artifact_id = ?",
                            (json.dumps(metadata, ensure_ascii=False), artifact["artifact_id"]),
                        )
                        refreshed += 1
                if pending_any:
                    pending_kept += 1
                if not exists_any and not pending_any:
                    pruned.append(generation_id)
            for generation_id in pruned:
                connection.execute("DELETE FROM generations WHERE generation_id = ?", (generation_id,))
        return {
            "scanned_generations": scanned,
            "pruned_generations": len(pruned),
            "refreshed_artifacts": refreshed,
            "pending_generations": pending_kept,
        }

    def index_report(self, output_root: Any, *, limit: int = 4000,
                     prefix: str = "EasyPanel_") -> dict[str, Any]:
        """作品库健康报告：缺失文件 / 重复文件 / 孤儿文件 / 导入记录。

        只读：不改记录、不删文件。``limit`` 限制输出目录扫描量，超过时用
        ``truncated`` 标记，避免几万张图把接口拖慢。
        """

        root = Path(str(output_root)).resolve()
        scan_limit = max(1, min(20000, int(limit)))
        with self._connection() as connection:
            total = int(connection.execute("SELECT COUNT(*) FROM generations").fetchone()[0] or 0)
            imported = int(connection.execute(
                "SELECT COUNT(*) FROM generations WHERE operation = 'imported'").fetchone()[0] or 0)
            missing_artifacts = 0
            pending_artifacts = 0
            live_owners: dict[tuple[str, str], set[str]] = {}
            for row in connection.execute(
                    "SELECT filename, subfolder, generation_id, metadata_json FROM artifacts "
                    "WHERE image_type = 'output' LIMIT 20000"):
                metadata = _json_value(row["metadata_json"])
                if isinstance(metadata, Mapping) and metadata.get("exists") is False:
                    if str(metadata.get("file_state") or "") == "pending":
                        pending_artifacts += 1
                    else:
                        missing_artifacts += 1
                    continue
                key = (str(row["filename"] or ""), str(row["subfolder"] or ""))
                live_owners.setdefault(key, set()).add(str(row["generation_id"]))
            live_duplicates = sorted(
                ((key, owners) for key, owners in live_owners.items() if len(owners) > 1),
                key=lambda item: (-len(item[1]), item[0][0]))
            recorded = {_file_key(sub, name) for name, sub in live_owners}
        duplicates = [
            {"file": _file_key(sub, name), "owners": len(owners)}
            for (name, sub), owners in live_duplicates[:20]
        ]
        scanned_files = 0
        orphan_files: list[str] = []
        truncated = False
        if root.is_dir():
            for path in sorted(root.rglob("*.png")):
                if prefix and not path.name.startswith(prefix):
                    continue
                relative = path.relative_to(root)
                subfolder = "" if str(relative.parent) == "." else relative.parent.as_posix()
                if is_aux_subfolder(subfolder):
                    continue
                scanned_files += 1
                if scanned_files > scan_limit:
                    truncated = True
                    break
                key = _file_key(subfolder, path.name)
                if key and key not in recorded:
                    orphan_files.append(key)
        return {
            "generations": total,
            "imported_generations": imported,
            "missing_artifacts": missing_artifacts,
            "pending_artifacts": pending_artifacts,
            "duplicate_total": len(live_duplicates),
            "duplicates": duplicates,
            "orphan_total": len(orphan_files),
            "orphan_sample": orphan_files[:20],
            "scanned_files": min(scanned_files, scan_limit),
            "truncated": truncated,
            "output_root": str(root),
        }

    def repair_index(self, output_root: Any, *, limit: int = 400, max_import: int = 200,
                     prefix: str = "EasyPanel_") -> dict[str, Any]:
        """一键修复：报告 → 增量导入未登记的成品 → 清理丢失记录 → 同名重复标记。

        同名重复沿用既有语义（最新为准，旧记录标缺失而不删行），因为旧图已被
        ComfyUI 覆写，删除行会丢掉当时的生成参数。
        """

        before = self.index_report(output_root, prefix=prefix)
        imported = self.import_output_images(output_root, prefix=prefix, limit=max_import)
        pruned = self.prune_missing_outputs(output_root, limit=limit)
        duplicates = self.mark_duplicate_artifacts_missing()
        after = self.index_report(output_root, prefix=prefix)
        return {"before": before, "imported": imported, "pruned": pruned,
                "duplicates": duplicates, "after": after}

    def delete_generation(self, generation_id: Any, output_root: Any = None) -> dict[str, Any] | None:
        """Delete one generation record together with its recorded output files.

        Returns ``None`` when the generation does not exist.  Only
        ``image_type == 'output'`` artifacts are unlinked on disk, and only
        when ``output_root`` is provided.  Every candidate path is resolved and
        must stay inside ``output_root``; anything that escapes the root is
        skipped (never followed).  The database row plus its artifacts,
        derivations and LoRA rows are removed through ON DELETE CASCADE in a
        second write transaction.  File deletion is best-effort: a file that is
        already missing is reported in ``missing_files``, never raised.
        """
        wanted = _safe_generation_id(generation_id)
        root = Path(str(output_root)).resolve() if output_root else None
        targets: list[tuple[str, str, str, str]] = []
        with self._connection() as connection:
            row = connection.execute(
                "SELECT generation_id FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            if row is None:
                return None
            artifacts = connection.execute(
                "SELECT artifact_id, filename, subfolder, image_type FROM artifacts "
                "WHERE generation_id = ?",
                (wanted,),
            ).fetchall()
            for artifact in artifacts:
                targets.append((
                    str(artifact["artifact_id"]),
                    str(artifact["image_type"] or "output"),
                    str(artifact["filename"] or ""),
                    str(artifact["subfolder"] or "").replace("\\", "/").strip("/"),
                ))
        removed_files: list[str] = []
        missing_files: list[str] = []
        if root is not None:
            for _artifact_id, image_type, filename, subfolder in targets:
                if image_type != "output" or not filename:
                    continue
                if filename in (".", ".."):
                    continue
                candidate = (root / Path(subfolder) / Path(filename).name).resolve()
                try:
                    candidate.relative_to(root)
                except ValueError:
                    # Path traversal outside the output root is never followed.
                    continue
                try:
                    candidate.unlink()
                    removed_files.append(filename)
                except FileNotFoundError:
                    missing_files.append(filename)
                except OSError:
                    pass
        with self._write_transaction() as connection:
            self._mark_purged(connection, [wanted], "delete")
            self._mark_purged_files(
                connection,
                [_file_key(subfolder, filename) for _a, image_type, filename, subfolder in targets
                 if image_type == "output" and _file_key(subfolder, filename)],
                "delete",
            )
            cursor = connection.execute(
                "DELETE FROM generations WHERE generation_id = ?", (wanted,)
            )
            deleted_rows = max(0, cursor.rowcount)
        return {
            "deleted_generation": wanted,
            "deleted": deleted_rows > 0,
            "removed_files": removed_files,
            "missing_files": missing_files,
            "artifact_count": len(targets),
        }

    def purge_failed_generations(
        self,
        statuses: Any = ("error",),
        *,
        output_root: Any = None,
        protect_favorite: bool = True,
        dry_run: bool = False,
        unfavorited_only: bool = False,
    ) -> dict[str, Any]:
        """一键清理生成失败的作品（默认 status='error'）。

        ``unfavorited_only=True`` 时忽略 statuses，改为删除所有不在收藏 / 收藏组 / 项目里的作品
        （即“只保留收藏”）。被收藏记录引用的同名文件一律不删。``dry_run=True`` 只统计不落地。
        """

        wanted = tuple(str(item).strip().lower() for item in (statuses or ()) if str(item).strip())
        if not wanted and not unfavorited_only:
            raise CreativeIndexError("需要指定要清理的状态。")
        root = Path(str(output_root)).resolve() if output_root else None
        placeholders = ",".join("?" for _ in wanted)
        with self._connection() as connection:
            if unfavorited_only:
                targets = [str(row["generation_id"]) for row in connection.execute(
                    f"SELECT generation_id FROM generations "
                    f"WHERE generation_id NOT IN ({_PROTECTED_SELECT})")]
            else:
                targets = [str(row["generation_id"]) for row in connection.execute(
                    f"SELECT generation_id FROM generations WHERE LOWER(status) IN ({placeholders})",
                    wanted,
                )]
            if not targets:
                return {"deleted": 0, "removed_files": 0, "missing_files": 0,
                        "protected_files": 0, "statuses": list(wanted), "generations": [],
                        "dry_run": bool(dry_run)}
            protected_files: set[tuple[str, str]] = set()
            if protect_favorite and root is not None:
                protected_files = {
                    (str(row["filename"]),
                     str(row["subfolder"] or "").replace("\\", "/").strip("/"))
                    for row in connection.execute(
                        f"""SELECT a.filename, a.subfolder FROM artifacts a
                            WHERE a.generation_id IN ({_PROTECTED_SELECT})""")
                }
            chunk = ",".join("?" for _ in targets)
            artifacts = [
                (str(row["filename"] or ""), str(row["subfolder"] or "").replace("\\", "/").strip("/"),
                 str(row["image_type"] or "output"))
                for row in connection.execute(
                    f"SELECT filename, subfolder, image_type FROM artifacts "
                    f"WHERE generation_id IN ({chunk})", targets)
            ]

        removable: list[tuple[str, str]] = []
        skipped_protected = 0
        seen: set[tuple[str, str]] = set()
        for filename, subfolder, image_type in artifacts:
            if image_type != "output" or not filename or filename in (".", ".."):
                continue
            key = (filename, subfolder)
            if key in seen:
                continue
            seen.add(key)
            if key in protected_files:
                skipped_protected += 1
                continue
            removable.append(key)

        if dry_run:
            return {"deleted": len(targets), "removed_files": len(removable), "missing_files": 0,
                    "protected_files": skipped_protected, "statuses": list(wanted),
                    "generations": targets[:200], "dry_run": True}

        removed_files = 0
        missing_files = 0
        if root is not None:
            for filename, subfolder in removable:
                candidate = (root / Path(subfolder) / Path(filename).name).resolve()
                try:
                    candidate.relative_to(root)
                except ValueError:
                    continue
                try:
                    candidate.unlink()
                    removed_files += 1
                except FileNotFoundError:
                    missing_files += 1
                except OSError:
                    pass

        deleted = 0
        with self._write_transaction() as connection:
            self._mark_purged(connection, targets, "purge:" + ",".join(wanted))
            self._mark_purged_files(
                connection,
                [_file_key(subfolder, filename) for filename, subfolder in removable
                 if _file_key(subfolder, filename)],
                "purge:" + ",".join(wanted),
            )
            for start in range(0, len(targets), 400):
                piece = targets[start:start + 400]
                marks = ",".join("?" for _ in piece)
                cursor = connection.execute(
                    f"DELETE FROM generations WHERE generation_id IN ({marks})", piece)
                deleted += max(0, cursor.rowcount)
        return {
            "deleted": deleted,
            "removed_files": removed_files,
            "missing_files": missing_files,
            "protected_files": skipped_protected,
            "statuses": list(wanted),
            "generations": targets[:200],
            "dry_run": False,
        }

    def purge_unfavorited(self, *, output_root: Any = None, dry_run: bool = False) -> dict[str, Any]:
        """只保留收藏（手动收藏 / 收藏组 / 项目引用）的作品，其余记录连同文件一并清理。"""

        return self.purge_failed_generations((), output_root=output_root, protect_favorite=False,
                                             dry_run=dry_run, unfavorited_only=True)

    def set_generation_flags(
        self,
        generation_id: Any,
        *,
        favorite: Any = None,
        rating: Any = None,
        note: Any = None,
    ) -> dict[str, Any] | None:
        """Save the human review state (入选 / 评分 / 备注) of one generation.

        These fields never change the recipe: the snapshot payload stays the
        same, so 收藏 marks a version instead of creating a new one.
        """

        wanted = _safe_generation_id(generation_id)
        assignments: list[str] = []
        params: list[Any] = []
        if favorite is not None:
            assignments.append("favorite = ?")
            params.append(1 if _flag_value(favorite) else 0)
        if rating is not None:
            assignments.append("rating = ?")
            params.append(max(0, min(5, _safe_int(rating, 0) or 0)))
        if note is not None:
            assignments.append("note = ?")
            params.append(_note_text(note))
        if not assignments:
            raise CreativeIndexError("没有需要保存的收藏字段。")
        with self._write_transaction() as connection:
            row = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            if row is None:
                return None
            connection.execute(
                f"UPDATE generations SET {', '.join(assignments)} WHERE generation_id = ?",
                tuple(params) + (wanted,),
            )
            updated = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            return self._summary_from_row(connection, updated) if updated else None

    def list_favorite_groups(self) -> dict[str, Any]:
        """Return every user-defined 收藏组 with its work count."""

        with self._connection() as connection:
            rows = connection.execute(
                "SELECT g.group_id, g.name, g.created_at, g.updated_at, "
                "(SELECT COUNT(*) FROM generation_favorite_groups l WHERE l.group_id = g.group_id) "
                "AS item_count FROM favorite_groups g ORDER BY g.name COLLATE NOCASE ASC"
            ).fetchall()
        items = [{**_group_from_row(row), "item_count": int(row["item_count"] or 0)} for row in rows]
        return {"items": items, "total": len(items)}

    def create_favorite_group(self, name: Any) -> dict[str, Any]:
        """Create a named 收藏组; a case-insensitive duplicate returns the existing one."""

        clean = _normalized_group_name(name)
        with self._write_transaction() as connection:
            existing = connection.execute(
                "SELECT * FROM favorite_groups WHERE name = ? COLLATE NOCASE", (clean,)
            ).fetchone()
            if existing is not None:
                return {"created": False, "group": _group_from_row(existing),
                        "message": "已存在同名收藏组，直接使用该组。"}
            total = connection.execute("SELECT COUNT(*) FROM favorite_groups").fetchone()[0]
            if int(total or 0) >= MAX_FAVORITE_GROUPS:
                raise CreativeIndexError(f"收藏组数量已达上限（{MAX_FAVORITE_GROUPS}）。")
            stamp = now_ms()
            group_id = _new_id()
            connection.execute(
                "INSERT INTO favorite_groups(group_id, name, created_at, updated_at) VALUES(?,?,?,?)",
                (group_id, clean, stamp, stamp),
            )
            row = connection.execute(
                "SELECT * FROM favorite_groups WHERE group_id = ?", (group_id,)
            ).fetchone()
            return {"created": True, "group": _group_from_row(row), "message": "收藏组已创建。"}

    def rename_favorite_group(self, group_id: Any, name: Any) -> dict[str, Any] | None:
        wanted = _safe_group_id(group_id)
        clean = _normalized_group_name(name)
        with self._write_transaction() as connection:
            row = connection.execute(
                "SELECT * FROM favorite_groups WHERE group_id = ?", (wanted,)
            ).fetchone()
            if row is None:
                return None
            clash = connection.execute(
                "SELECT group_id FROM favorite_groups WHERE name = ? COLLATE NOCASE AND group_id <> ?",
                (clean, wanted),
            ).fetchone()
            if clash is not None:
                raise CreativeIndexError("已存在同名收藏组，请换一个名称。")
            connection.execute(
                "UPDATE favorite_groups SET name = ?, updated_at = ? WHERE group_id = ?",
                (clean, now_ms(), wanted),
            )
            updated = connection.execute(
                "SELECT * FROM favorite_groups WHERE group_id = ?", (wanted,)
            ).fetchone()
            return _group_from_row(updated)

    def delete_favorite_group(self, group_id: Any) -> dict[str, Any] | None:
        """Delete one 收藏组. The works themselves are never touched."""

        wanted = _safe_group_id(group_id)
        with self._write_transaction() as connection:
            row = connection.execute(
                "SELECT name FROM favorite_groups WHERE group_id = ?", (wanted,)
            ).fetchone()
            if row is None:
                return None
            links = connection.execute(
                "SELECT COUNT(*) FROM generation_favorite_groups WHERE group_id = ?", (wanted,)
            ).fetchone()[0]
            cursor = connection.execute(
                "DELETE FROM favorite_groups WHERE group_id = ?", (wanted,)
            )
            return {"deleted": max(0, cursor.rowcount) > 0,
                    "group_id": wanted, "name": str(row["name"]),
                    "removed_links": int(links or 0)}

    def set_generation_groups(self, generation_id: Any, group_ids: Any, *,
                              mode: str = "replace") -> dict[str, Any] | None:
        """Add / remove / replace the 收藏组 membership of one work.

        Membership is pure metadata: no generation parameter is written, so a
        work can sit in several groups without creating a new version.
        """

        wanted = _safe_generation_id(generation_id)
        candidates: list[str] = []
        for raw in (group_ids if isinstance(group_ids, (list, tuple, set)) else [group_ids]):
            try:
                candidate = _safe_group_id(raw)
            except CreativeIndexError:
                continue
            if candidate and candidate not in candidates:
                candidates.append(candidate)
        if len(candidates) > MAX_GROUPS_PER_GENERATION:
            raise CreativeIndexError(f"单个作品最多加入 {MAX_GROUPS_PER_GENERATION} 个收藏组。")
        action = str(mode or "replace").strip().casefold()
        if action not in {"replace", "add", "remove"}:
            raise CreativeIndexError("未知的收藏组操作。")
        with self._write_transaction() as connection:
            row = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            if row is None:
                return None
            known = {
                str(item["group_id"])
                for item in connection.execute("SELECT group_id FROM favorite_groups").fetchall()
            }
            if action != "remove":
                missing = [item for item in candidates if item not in known]
                if missing:
                    raise CreativeIndexError("收藏组不存在，请刷新后重试。")
            if action == "replace":
                connection.execute(
                    "DELETE FROM generation_favorite_groups WHERE generation_id = ?", (wanted,)
                )
            if action in {"replace", "add"}:
                stamp = now_ms()
                for group_id in candidates:
                    connection.execute(
                        "INSERT OR IGNORE INTO generation_favorite_groups"
                        "(generation_id, group_id, created_at) VALUES(?,?,?)",
                        (wanted, group_id, stamp),
                    )
            else:
                for group_id in candidates:
                    connection.execute(
                        "DELETE FROM generation_favorite_groups WHERE generation_id = ? AND group_id = ?",
                        (wanted, group_id),
                    )
            updated = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            return self._summary_from_row(connection, updated) if updated else None

    def find_generations_by_fingerprint(
        self,
        fingerprint: Any,
        *,
        limit: Any = 5,
        statuses: Sequence[Any] = ("completed",),
    ) -> dict[str, Any]:
        """按任务指纹查已有的相同作品（重复提交检测用）。

        指纹只覆盖配方（模型 / LoRA / 提示词 / seed / 采样与二采参数），
        所以同一次生成被点两次时能立刻找到已有结果。
        """

        wanted = _safe_text(fingerprint, 128).casefold()
        if not wanted:
            return {"items": [], "total": 0, "fingerprint": ""}
        wanted_statuses = [normalize_status(status) for status in (statuses or ())]
        clause = ""
        params: list[Any] = [wanted]
        if wanted_statuses:
            clause = f" AND status IN ({', '.join('?' for _ in wanted_statuses)})"
            params.extend(wanted_statuses)
        params.append(max(1, min(MAX_PAGE_SIZE, _safe_int(limit, 5) or 5)))
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT * FROM generations WHERE fingerprint = ?" + clause
                + " ORDER BY created_at DESC LIMIT ?",
                tuple(params),
            ).fetchall()
            items = [self._summary_from_row(connection, row) for row in rows]
        return {"items": items, "total": len(items), "fingerprint": wanted}

    # ---------------------------------------------------------------- 作品项目
    @staticmethod
    def _project_from_row(connection: sqlite3.Connection, row: sqlite3.Row | None) -> dict[str, Any]:
        if row is None:
            return {}
        project_id = str(row["project_id"])
        sections = _json_value(row["sections_json"])
        section_names = [str(item) for item in sections] if isinstance(sections, list) else []
        cover_artifact_id = str(row["cover_artifact_id"] or "")
        cover_url = None
        if cover_artifact_id:
            artifact = connection.execute(
                "SELECT filename, subfolder, image_type FROM artifacts WHERE artifact_id = ?",
                (cover_artifact_id,),
            ).fetchone()
            if artifact is not None:
                cover_url = artifact_url(str(artifact["filename"]), str(artifact["subfolder"]),
                                         str(artifact["image_type"]))
        count = connection.execute(
            "SELECT COUNT(*) FROM project_items WHERE project_id = ?", (project_id,)
        ).fetchone()[0]
        return {
            "project_id": project_id,
            "name": str(row["name"]),
            "note": str(row["note"] or ""),
            "sections": section_names or list(DEFAULT_PROJECT_SECTIONS),
            "favorites_group_id": str(row["favorites_group_id"] or "") or None,
            "cover_artifact_id": cover_artifact_id or None,
            "cover_url": cover_url,
            "item_count": int(count or 0),
            "created_at": int(row["created_at"]),
            "updated_at": int(row["updated_at"]),
        }

    def list_projects(self) -> dict[str, Any]:
        """全部作品项目（按最近更新排序）。"""

        with self._connection() as connection:
            rows = connection.execute("SELECT * FROM projects ORDER BY updated_at DESC").fetchall()
            items = [self._project_from_row(connection, row) for row in rows]
        return {"items": items, "total": len(items), "defaultSections": list(DEFAULT_PROJECT_SECTIONS)}

    def get_project(self, project_id: Any, *, limit: Any = MAX_PROJECT_ITEMS) -> dict[str, Any] | None:
        """项目详情：按分区组织的作品 + 关联资源（LoRA / 预设 / 实验 / 收藏组）。"""

        wanted = _safe_project_id(project_id)
        bounded = max(1, min(MAX_PROJECT_ITEMS, _safe_int(limit, MAX_PROJECT_ITEMS) or MAX_PROJECT_ITEMS))
        with self._connection() as connection:
            row = connection.execute("SELECT * FROM projects WHERE project_id = ?", (wanted,)).fetchone()
            if row is None:
                return None
            project = self._project_from_row(connection, row)
            item_rows = connection.execute(
                "SELECT * FROM project_items WHERE project_id = ?"
                " ORDER BY position ASC, created_at ASC LIMIT ?",
                (wanted, bounded),
            ).fetchall()
            items: list[dict[str, Any]] = []
            for item_row in item_rows:
                generation_row = connection.execute(
                    "SELECT * FROM generations WHERE generation_id = ?",
                    (str(item_row["generation_id"]),),
                ).fetchone()
                items.append({
                    "item_id": str(item_row["item_id"]),
                    "section": str(item_row["section"] or ""),
                    "position": int(item_row["position"]),
                    "note": str(item_row["note"] or ""),
                    "created_at": int(item_row["created_at"]),
                    "generation": self._summary_from_row(connection, generation_row),
                })
            link_rows = connection.execute(
                "SELECT * FROM project_links WHERE project_id = ? ORDER BY created_at ASC", (wanted,)
            ).fetchall()
        buckets: dict[str, list[dict[str, Any]]] = {kind: [] for kind in PROJECT_LINK_KINDS}
        for link_row in link_rows:
            kind = str(link_row["kind"])
            buckets.setdefault(kind, []).append({
                "link_id": str(link_row["link_id"]),
                "kind": kind,
                "ref": str(link_row["ref"]),
                "label": str(link_row["label"] or ""),
                "created_at": int(link_row["created_at"]),
            })
        names = list(project["sections"])
        for item in items:
            section = str(item["section"] or "")
            if section and section not in names:
                names.append(section)
        sections = [{"name": name, "items": [item for item in items if str(item["section"]) == name]}
                    for name in names]
        ungrouped = [item for item in items if not str(item["section"])]
        if ungrouped:
            sections.append({"name": "", "items": ungrouped})
        return {"project": project, "sections": sections, "links": buckets,
                "total": len(items), "truncated": len(items) >= bounded}

    def create_project(self, name: Any, *, note: Any = "", sections: Any = None) -> dict[str, Any]:
        """新建项目；同名项目直接复用（不会创建第二个）。"""

        clean = _normalized_project_name(name)
        with self._write_transaction() as connection:
            existing = connection.execute(
                "SELECT * FROM projects WHERE name = ? COLLATE NOCASE", (clean,)
            ).fetchone()
            if existing is not None:
                return {"created": False, "project": self._project_from_row(connection, existing),
                        "message": "已存在同名项目，直接打开该项目。"}
            total = connection.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
            if int(total or 0) >= MAX_PROJECTS:
                raise CreativeIndexError(f"项目数量已达上限（{MAX_PROJECTS}）。")
            stamp = now_ms()
            project_id = _new_id()
            connection.execute(
                "INSERT INTO projects(project_id, name, note, sections_json, favorites_group_id,"
                " cover_artifact_id, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (project_id, clean, _note_text(note), _json_text(_safe_project_sections(sections)),
                 "", "", stamp, stamp),
            )
        detail = self.get_project(project_id) or {}
        return {"created": True, "project": detail.get("project", {}), "message": "项目已创建。"}

    def update_project(self, project_id: Any, *, name: Any = None, note: Any = None,
                       sections: Any = None, favorites_group_id: Any = None) -> dict[str, Any] | None:
        wanted = _safe_project_id(project_id)
        assignments: list[str] = []
        params: list[Any] = []
        if name is not None:
            assignments.append("name = ?")
            params.append(_normalized_project_name(name))
        if note is not None:
            assignments.append("note = ?")
            params.append(_note_text(note))
        if sections is not None:
            assignments.append("sections_json = ?")
            params.append(_json_text(_safe_project_sections(sections)))
        if favorites_group_id is not None:
            assignments.append("favorites_group_id = ?")
            params.append(_safe_text(favorites_group_id, 64).casefold())
        if not assignments:
            raise CreativeIndexError("没有需要保存的项目字段。")
        with self._write_transaction() as connection:
            row = connection.execute("SELECT * FROM projects WHERE project_id = ?", (wanted,)).fetchone()
            if row is None:
                return None
            if name is not None:
                clash = connection.execute(
                    "SELECT project_id FROM projects WHERE name = ? COLLATE NOCASE AND project_id <> ?",
                    (_normalized_project_name(name), wanted),
                ).fetchone()
                if clash is not None:
                    raise CreativeIndexError("已存在同名项目，请换一个名称。")
            connection.execute(
                f"UPDATE projects SET {', '.join(assignments)}, updated_at = ? WHERE project_id = ?",
                tuple(params) + (now_ms(), wanted),
            )
        detail = self.get_project(wanted) or {}
        return detail.get("project")

    def delete_project(self, project_id: Any) -> dict[str, Any] | None:
        """删除项目；作品本身与收藏状态不受影响。"""

        wanted = _safe_project_id(project_id)
        with self._write_transaction() as connection:
            row = connection.execute("SELECT name FROM projects WHERE project_id = ?", (wanted,)).fetchone()
            if row is None:
                return None
            items = connection.execute(
                "SELECT COUNT(*) FROM project_items WHERE project_id = ?", (wanted,)
            ).fetchone()[0]
            links = connection.execute(
                "SELECT COUNT(*) FROM project_links WHERE project_id = ?", (wanted,)
            ).fetchone()[0]
            connection.execute("DELETE FROM projects WHERE project_id = ?", (wanted,))
        return {"deleted": True, "project_id": wanted, "name": str(row["name"]),
                "removed_items": int(items or 0), "removed_links": int(links or 0)}

    def add_project_items(self, project_id: Any, generation_ids: Any, *,
                          section: Any = "") -> dict[str, Any] | None:
        """把作品加入项目（可指定分区）；已在项目里的作品会被跳过。"""

        wanted = _safe_project_id(project_id)
        candidates: list[str] = []
        for raw in (generation_ids if isinstance(generation_ids, (list, tuple, set)) else [generation_ids]):
            try:
                candidate = _safe_generation_id(raw)
            except CreativeIndexError:
                continue
            if candidate not in candidates:
                candidates.append(candidate)
        if not candidates:
            raise CreativeIndexError("没有可加入项目的作品。")
        placed = 0
        skipped = 0
        with self._write_transaction() as connection:
            project = connection.execute("SELECT * FROM projects WHERE project_id = ?", (wanted,)).fetchone()
            if project is None:
                return None
            defined = [str(item) for item in (_json_value(project["sections_json"]) or [])]
            target = " ".join(str(section or "").split())[:PROJECT_SECTION_LIMIT]
            if target and target not in defined:
                raise CreativeIndexError("该项目没有这个分区，请先在项目里添加分区。")
            count = int(connection.execute(
                "SELECT COUNT(*) FROM project_items WHERE project_id = ?", (wanted,)
            ).fetchone()[0] or 0)
            stamp = now_ms()
            for generation_id in candidates:
                if connection.execute("SELECT 1 FROM generations WHERE generation_id = ?",
                                      (generation_id,)).fetchone() is None:
                    skipped += 1
                    continue
                if connection.execute(
                    "SELECT 1 FROM project_items WHERE project_id = ? AND generation_id = ?",
                    (wanted, generation_id),
                ).fetchone() is not None:
                    skipped += 1
                    continue
                if count >= MAX_PROJECT_ITEMS:
                    raise CreativeIndexError(f"单个项目最多 {MAX_PROJECT_ITEMS} 件作品。")
                connection.execute(
                    "INSERT INTO project_items(item_id, project_id, generation_id, section, position,"
                    " note, created_at) VALUES(?,?,?,?,?,?,?)",
                    (_new_id(), wanted, generation_id, target, count, "", stamp),
                )
                count += 1
                placed += 1
            if placed:
                connection.execute("UPDATE projects SET updated_at = ? WHERE project_id = ?",
                                   (stamp, wanted))
        return {"added": placed, "skipped": skipped, "message": f"已加入 {placed} 件作品。",
                "project": (self.get_project(wanted) or {}).get("project")}

    def remove_project_items(self, project_id: Any, *, item_ids: Any = None,
                             generation_ids: Any = None) -> dict[str, Any] | None:
        """从项目移除作品（可按 item_id 或 generation_id）。"""

        wanted = _safe_project_id(project_id)
        wanted_items = {str(item) for item in (
            item_ids if isinstance(item_ids, (list, tuple, set)) else [item_ids]) if str(item or "").strip()}
        wanted_generations: set[str] = set()
        for raw in (generation_ids if isinstance(generation_ids, (list, tuple, set)) else [generation_ids]):
            try:
                wanted_generations.add(_safe_generation_id(raw))
            except CreativeIndexError:
                continue
        if not wanted_items and not wanted_generations:
            raise CreativeIndexError("没有要移除的项目内容。")
        removed = 0
        with self._write_transaction() as connection:
            if connection.execute("SELECT 1 FROM projects WHERE project_id = ?", (wanted,)).fetchone() is None:
                return None
            rows = connection.execute(
                "SELECT item_id, generation_id FROM project_items WHERE project_id = ?", (wanted,)
            ).fetchall()
            for row in rows:
                if str(row["item_id"]) in wanted_items or str(row["generation_id"]) in wanted_generations:
                    connection.execute("DELETE FROM project_items WHERE item_id = ?", (str(row["item_id"]),))
                    removed += 1
            if removed:
                connection.execute("UPDATE projects SET updated_at = ? WHERE project_id = ?",
                                   (now_ms(), wanted))
        return {"removed": removed, "message": f"已移出 {removed} 件作品。",
                "project": (self.get_project(wanted) or {}).get("project")}

    def update_project_item(self, project_id: Any, item_id: Any, *, section: Any = None,
                            note: Any = None, position: Any = None) -> dict[str, Any] | None:
        """调整项目内一件作品的分区 / 备注 / 排序。"""

        wanted = _safe_project_id(project_id)
        wanted_item = _safe_text(item_id, 64)
        if not wanted_item:
            raise CreativeIndexError("项目条目编号无效。")
        assignments: list[str] = []
        params: list[Any] = []
        if section is not None:
            target = " ".join(str(section or "").split())[:PROJECT_SECTION_LIMIT]
            assignments.append("section = ?")
            params.append(target)
        if note is not None:
            assignments.append("note = ?")
            params.append(_note_text(note))
        if position is not None:
            assignments.append("position = ?")
            params.append(max(0, min(MAX_PROJECT_ITEMS, _safe_int(position, 0) or 0)))
        if not assignments:
            raise CreativeIndexError("没有需要保存的条目字段。")
        with self._write_transaction() as connection:
            project = connection.execute("SELECT * FROM projects WHERE project_id = ?", (wanted,)).fetchone()
            if project is None:
                return None
            row = connection.execute(
                "SELECT * FROM project_items WHERE project_id = ? AND item_id = ?", (wanted, wanted_item)
            ).fetchone()
            if row is None:
                return None
            if section is not None:
                target = " ".join(str(section or "").split())[:PROJECT_SECTION_LIMIT]
                defined = [str(item) for item in (_json_value(project["sections_json"]) or [])]
                if target and target not in defined:
                    raise CreativeIndexError("该项目没有这个分区，请先在项目里添加分区。")
            connection.execute(
                f"UPDATE project_items SET {', '.join(assignments)} WHERE item_id = ?",
                tuple(params) + (wanted_item,),
            )
            connection.execute("UPDATE projects SET updated_at = ? WHERE project_id = ?",
                               (now_ms(), wanted))
        detail = self.get_project(wanted) or {}
        for section_entry in detail.get("sections", []):
            for item in section_entry.get("items", []):
                if str(item["item_id"]) == wanted_item:
                    return item
        return None

    def set_project_cover(self, project_id: Any, *, artifact_id: Any = "",
                          generation_id: Any = "") -> dict[str, Any] | None:
        """设置项目封面；也可以直接指定作品，取其代表图。"""

        wanted = _safe_project_id(project_id)
        wanted_artifact = _safe_text(artifact_id, 64)
        wanted_generation = ""
        if not wanted_artifact and generation_id:
            try:
                wanted_generation = _safe_generation_id(generation_id)
            except CreativeIndexError:
                wanted_generation = ""
        if not wanted_artifact and not wanted_generation:
            raise CreativeIndexError("请选择要作为封面的图片。")
        with self._write_transaction() as connection:
            if connection.execute("SELECT 1 FROM projects WHERE project_id = ?", (wanted,)).fetchone() is None:
                return None
            if wanted_generation:
                preview = _preview_artifact_row(connection, wanted_generation)
                if preview is not None:
                    wanted_artifact = str(preview["artifact_id"])
            if wanted_artifact and connection.execute(
                "SELECT 1 FROM artifacts WHERE artifact_id = ?", (wanted_artifact,)
            ).fetchone() is None:
                raise CreativeIndexError("封面图片不存在。")
            connection.execute(
                "UPDATE projects SET cover_artifact_id = ?, updated_at = ? WHERE project_id = ?",
                (wanted_artifact, now_ms(), wanted),
            )
        return (self.get_project(wanted) or {}).get("project")

    def add_project_link(self, project_id: Any, kind: Any, ref: Any, *,
                         label: Any = "") -> dict[str, Any] | None:
        """给项目关联一条资源：LoRA / Prompt 预设 / 实验 / 收藏组。"""

        wanted = _safe_project_id(project_id)
        link_kind = _safe_link_kind(kind)
        target = _safe_text(ref, 400)
        if not target:
            raise CreativeIndexError("关联内容不能为空。")
        with self._write_transaction() as connection:
            if connection.execute("SELECT 1 FROM projects WHERE project_id = ?", (wanted,)).fetchone() is None:
                return None
            total = int(connection.execute(
                "SELECT COUNT(*) FROM project_links WHERE project_id = ?", (wanted,)
            ).fetchone()[0] or 0)
            if total >= MAX_PROJECT_LINKS:
                raise CreativeIndexError(f"单个项目最多 {MAX_PROJECT_LINKS} 条关联。")
            connection.execute(
                "INSERT OR IGNORE INTO project_links(link_id, project_id, kind, ref, label, created_at)"
                " VALUES(?,?,?,?,?,?)",
                (_new_id(), wanted, link_kind, target, _safe_text(label, 120), now_ms()),
            )
            connection.execute("UPDATE projects SET updated_at = ? WHERE project_id = ?",
                               (now_ms(), wanted))
        return (self.get_project(wanted) or {}).get("project")

    def remove_project_link(self, project_id: Any, link_id: Any) -> dict[str, Any] | None:
        wanted = _safe_project_id(project_id)
        wanted_link = _safe_text(link_id, 64)
        if not wanted_link:
            raise CreativeIndexError("关联编号无效。")
        with self._write_transaction() as connection:
            if connection.execute("SELECT 1 FROM projects WHERE project_id = ?", (wanted,)).fetchone() is None:
                return None
            connection.execute(
                "DELETE FROM project_links WHERE project_id = ? AND link_id = ?", (wanted, wanted_link)
            )
            connection.execute("UPDATE projects SET updated_at = ? WHERE project_id = ?",
                               (now_ms(), wanted))
        return {"removed": True, "project": (self.get_project(wanted) or {}).get("project")}

    def list_generations(
        self,
        *,
        limit: Any = 20,
        offset: Any = 0,
        operation: Any = "",
        status: Any = "",
        model: Any = "",
        favorite: Any = None,
        group: Any = "",
        sort: Any = "created_at",
        order: Any = "desc",
    ) -> dict[str, Any]:
        page_limit = max(1, min(MAX_PAGE_SIZE, _safe_int(limit, 20) or 20))
        page_offset = max(0, min(MAX_OFFSET, _safe_int(offset, 0) or 0))
        op = str(operation or "").strip().casefold()
        op = normalize_operation(op) if op else ""
        state = str(status or "").strip().casefold()
        state = normalize_status(state) if state else ""
        model_filter = _safe_text(model, 800)
        sort_sql = SORT_FIELDS.get(str(sort or "created_at").strip().casefold(), SORT_FIELDS["created_at"])
        direction = "ASC" if str(order or "").strip().casefold() == "asc" else "DESC"
        where: list[str] = []
        params: list[Any] = []
        if op:
            where.append("g.operation = ?")
            params.append(op)
        if state:
            where.append("g.status = ?")
            params.append(state)
        favorite_filter = str(favorite or "").strip().casefold()
        if favorite_filter in {"1", "true", "yes", "favorite", "favourite", "star", "入选"}:
            where.append("g.favorite = 1")
        elif favorite_filter in {"0", "false", "no", "unfavorite", "unfavourite", "未入选"}:
            where.append("g.favorite = 0")
        group_filter = str(group or "").strip().casefold()
        if group_filter == "ungrouped":
            where.append("NOT EXISTS (SELECT 1 FROM generation_favorite_groups l WHERE l.generation_id = g.generation_id)")
        elif group_filter:
            try:
                wanted_group = _safe_group_id(group_filter)
            except CreativeIndexError:
                wanted_group = ""
            if wanted_group:
                where.append(
                    "EXISTS (SELECT 1 FROM generation_favorite_groups l "
                    "WHERE l.generation_id = g.generation_id AND l.group_id = ?)"
                )
                params.append(wanted_group)
            else:
                # 未知的组编号不应把它当成“全部作品”静默返回。
                where.append("1 = 0")
        if model_filter:
            where.append("LOWER(g.model) LIKE LOWER(?)")
            params.append(f"%{model_filter}%")
        if _flag_value(favorite):
            where.append("g.favorite = 1")
        where_sql = " WHERE " + " AND ".join(where) if where else ""
        with self._connection() as connection:
            total = int(connection.execute(f"SELECT COUNT(*) FROM generations g{where_sql}", tuple(params)).fetchone()[0])
            rows = connection.execute(
                f"SELECT g.* FROM generations g{where_sql} ORDER BY {sort_sql} {direction}, g.generation_id ASC LIMIT ? OFFSET ?",
                tuple(params) + (page_limit, page_offset),
            ).fetchall()
            items = [self._summary_from_row(connection, row) for row in rows]
            return {
                "items": items,
                "total": total,
                "limit": page_limit,
                "offset": page_offset,
                "has_more": page_offset + len(items) < total,
                "schema_version": SCHEMA_VERSION,
            }

    def _lineage_walk(
        self,
        connection: sqlite3.Connection,
        start: str,
        direction: str,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        queue: list[tuple[str, int]] = [(start, 0)]
        visited = {start}
        nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        while queue and len(nodes) < MAX_LINEAGE_NODES:
            current, depth = queue.pop(0)
            if direction == "parents":
                rows = connection.execute(
                    "SELECT * FROM derivations WHERE child_generation_id = ? ORDER BY created_at ASC",
                    (current,),
                ).fetchall()
                related_key = "parent_generation_id"
                edge_parent = "parent_generation_id"
                edge_child = "child_generation_id"
            else:
                rows = connection.execute(
                    "SELECT * FROM derivations WHERE parent_generation_id = ? ORDER BY created_at ASC",
                    (current,),
                ).fetchall()
                related_key = "child_generation_id"
                edge_parent = "parent_generation_id"
                edge_child = "child_generation_id"
            for row in rows:
                related = str(row[related_key] or "")
                edges.append({
                    "derivation_id": str(row["derivation_id"]),
                    "parent_generation_id": row[edge_parent],
                    "child_generation_id": row[edge_child],
                    "parent_artifact_id": row["parent_artifact_id"],
                    "child_artifact_id": row["child_artifact_id"],
                    "operation": normalize_operation(row["operation"]),
                    "created_at": int(row["created_at"]),
                    "metadata": _json_value(row["metadata_json"]),
                })
                if not related or related in visited:
                    continue
                visited.add(related)
                related_row = connection.execute(
                    "SELECT * FROM generations WHERE generation_id = ?", (related,)
                ).fetchone()
                if not related_row:
                    continue
                nodes.append({"depth": depth + 1, **self._summary_from_row(connection, related_row)})
                if depth < MAX_LINEAGE_NODES:
                    queue.append((related, depth + 1))
                if len(nodes) >= MAX_LINEAGE_NODES:
                    break
        return nodes, edges

    def get_lineage(self, generation_id: Any) -> dict[str, Any] | None:
        wanted = _safe_generation_id(generation_id)
        with self._connection() as connection:
            root = connection.execute(
                "SELECT * FROM generations WHERE generation_id = ?", (wanted,)
            ).fetchone()
            if not root:
                return None
            ancestors, parent_edges = self._lineage_walk(connection, wanted, "parents")
            descendants, child_edges = self._lineage_walk(connection, wanted, "children")
            return {
                "generation_id": wanted,
                "ancestors": ancestors,
                "descendants": descendants,
                "edges": parent_edges + [edge for edge in child_edges if edge not in parent_edges],
                "schema_version": SCHEMA_VERSION,
            }

    def import_legacy_files(
        self,
        snapshots_source: str | Path | Sequence[Any] | None,
        jobs_source: str | Path | Sequence[Any] | None,
        *,
        output_root: str | Path | None = None,
    ) -> dict[str, Any]:
        """Import old JSON rows without rewriting either source file."""

        report: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "inserted": 0,
            "updated": 0,
            "skipped": 0,
            "warnings": [],
            "errors": [],
        }

        def load_source(source: Any, label: str) -> list[Any]:
            if source is None:
                return []
            if isinstance(source, (str, Path)):
                try:
                    parsed = json.loads(Path(source).read_text(encoding="utf-8"))
                except (OSError, UnicodeError, json.JSONDecodeError) as exc:
                    report["errors"].append(f"{label} 文件无法读取：{type(exc).__name__}")
                    return []
            else:
                parsed = source
            if not isinstance(parsed, list):
                report["errors"].append(f"{label} 必须是 JSON 数组，已跳过整份文件。")
                return []
            return parsed

        snapshots = load_source(snapshots_source, "generation_snapshots.json")
        jobs = load_source(jobs_source, "rpg_jobs.json")
        for index, item in enumerate(snapshots):
            if not isinstance(item, Mapping):
                report["skipped"] += 1
                report["warnings"].append(f"snapshot[{index}] 不是对象，已跳过。")
                continue
            try:
                result = self.upsert_snapshot(
                    item,
                    operation=self._snapshot_operation(item),
                    status=infer_legacy_status(item),
                    output_root=output_root,
                )
                if result.get("purged"):
                    report["skipped"] += 1
                    continue
                report["inserted" if result["created"] else "updated"] += 1
                report["warnings"].extend(result.get("warnings") or [])
            except Exception as exc:
                report["skipped"] += 1
                report["errors"].append(f"snapshot[{index}] 导入失败：{type(exc).__name__}")

        for index, item in enumerate(jobs):
            if not isinstance(item, Mapping):
                report["skipped"] += 1
                report["warnings"].append(f"job[{index}] 不是对象，已跳过。")
                continue
            prompt_id = _safe_text(item.get("prompt_id") or item.get("promptId"), 128)
            request_id = _safe_text(item.get("request_id") or item.get("requestId"), 128)
            snapshot_id = _safe_text(item.get("snapshot_id") or item.get("snapshotId"), 128)
            legacy_status = infer_legacy_status(item)
            legacy_artifacts = _legacy_artifacts(item)
            if snapshot_id or prompt_id or request_id:
                updated = self.update_job(
                    prompt_id=prompt_id,
                    request_id=request_id,
                    snapshot_id=snapshot_id,
                    status=legacy_status,
                    images=legacy_artifacts,
                    output_root=output_root,
                )
                if updated:
                    report["updated"] += 1
                    report["warnings"].extend(updated.get("warnings") or [])
                    continue
            try:
                synthetic_id = snapshot_id or _stable_key("legacy-job", item)
                client = item.get("client") if isinstance(item.get("client"), Mapping) else {}
                loras = list(item.get("character_loras") or []) + list(item.get("style_loras") or [])
                synthetic = {
                    "id": synthetic_id,
                    "createdAt": _safe_int(item.get("created_at") or item.get("createdAt"), now_ms()),
                    "schemaVersion": 0,
                    "promptId": prompt_id,
                    "payload": {
                        "client": sanitize_json_value(client),
                        "model": _safe_text(item.get("model"), 800),
                        "loras": sanitize_json_value(loras),
                    },
                    "source": {
                        "checkpoint": _safe_text(item.get("model"), 800),
                        "loras": sanitize_json_value(loras),
                    },
                    "workflow": {"kind": "legacy-job", "operation": "legacy.job"},
                    "outputs": legacy_artifacts,
                }
                result = self.upsert_snapshot(
                    synthetic,
                    operation="txt2img",
                    status=legacy_status,
                    request_id=request_id,
                    output_root=output_root,
                )
                if result.get("purged"):
                    report["skipped"] += 1
                    continue
                report["inserted" if result["created"] else "updated"] += 1
                report["warnings"].extend(result.get("warnings") or [])
            except Exception as exc:
                report["skipped"] += 1
                report["errors"].append(f"job[{index}] 导入失败：{type(exc).__name__}")
        report["warnings"] = report["warnings"][:200]
        report["errors"] = report["errors"][:200]
        return report


__all__ = [
    "CreativeIndex",
    "CreativeIndexError",
    "KNOWN_STATUSES",
    "MAX_LINEAGE_NODES",
    "MAX_OFFSET",
    "MAX_PAGE_SIZE",
    "SCHEMA_VERSION",
    "SUPPORTED_OPERATIONS",
    "artifact_url",
    "infer_legacy_status",
    "normalize_artifact_ref",
    "normalize_operation",
    "normalize_status",
    "sanitize_json_value",
]
