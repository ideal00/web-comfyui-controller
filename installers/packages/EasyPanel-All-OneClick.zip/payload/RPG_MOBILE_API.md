# Easy Panel × RPGBox 手机生图接口（API v2）

Easy Panel 现在可以作为 RPGBox 的视觉后端。手机只访问 Easy Panel `8190`，Easy Panel 再在电脑本机访问 ComfyUI `8188`。

当前配套版本：Easy Panel 服务端 `2.3.3`，Android 客户端 `mobile-v1.4.7`（versionCode `1004007`）。协议仍为 RPG API v2。

## 1. 启动手机模式

运行：

`G:\ComfyUI\EasyPanel_一键启动.bat`

该入口会同时按需启动本机 ComfyUI `8188` 和局域网模式 Easy Panel `8190`。如需只查看计划而不启停进程，可运行 `ComfyUI_Easy_Panel\tools\EasyPanel-Service.ps1 -Mode Start -DryRun`。

脚本会：

- 让 Easy Panel 监听 `0.0.0.0:8190`；
- 保持 ComfyUI 为 `127.0.0.1:8188`；
- 创建 `rpg_mobile_token.txt`；
- 显示电脑局域网 IP 和 Token。

手机与电脑处于同一局域网时，RPGBox 使用类似 `http://192.168.1.10:8190` 的地址。

> 不建议把 8190 直接裸露到公网。跨公网使用时请放在 VPN / Tailscale / HTTPS 反向代理之后。

## 2. 鉴权

除 `/api/rpg/ping` 外，RPG API 请求需要：

`X-RPG-Token: <rpg_mobile_token.txt 中的内容>`

也支持：

`Authorization: Bearer <token>`

远程访问 Easy Panel 的完整网页、旧版 `/api/*`、快照详情/对比和 `/output` 也需要同一个 Token。桌面浏览器第一次收到 HTTP Basic 鉴权挑战后，可将 Token 填入密码完成会话；服务器只返回短时 HttpOnly、签名 Cookie。Android 高级 WebView 只在首次根页面请求通过原生 `X-RPG-Token` 请求头引导该会话，Token 不会出现在 URL、网页 JavaScript 或 localStorage 中。局域网/ Tailscale 仍建议只在私网内开放 8190。

## 3. 连通性

### GET `/api/rpg/ping`

返回：

```json
{
  "ok": true,
  "api_version": 2,
  "service": "ComfyUI Easy Panel RPG Bridge",
  "token_required": true
}
```


### GET `/api/rpg/capabilities`

返回手机端可用能力、推荐轮询间隔和尺寸限制。RPGBox 可用它判断服务端是否支持 `requestId` 去重、任务恢复、子目录图片等能力。

### GET `/api/rpg/jobs/by-request/{requestId}`

用于手机切后台、切网络或 App 重启后的任务恢复。`requestId` 应由 RPGBox 在第一次提交前生成并持久化。

### GET `/api/rpg/models`

返回 Easy Panel 当前实际可用的 Checkpoint、Anima、Krea 2 模型。

### POST `/api/rpg/prompt-instruction`

为快速生图的中文描述生成可复制给 DeepSeek 的模型族适配指令。接口会使用请求中的 `model` 对应模型；如果 `model` 为空，则按 Easy Panel 的默认模型选择规则解析实际 Checkpoint。请求需要 RPG Token：

```json
{
  "text": "黄昏时安静的书店，窗边暖光，一位金发女孩正在看书",
  "model": "waiIllustriousSDXL_v140.safetensors",
  "safetyLevel": "safe"
}
```

返回 `family`、实际 `model`、`family_label` 和 `instruction`。`instruction` 固定要求 AI 返回 `POSITIVE:` / `NEGATIVE:` 两行；Anima、Illustrious、SDXL 和 Krea 2 分别使用各自的标签或自然语言规则。该接口只生成转换指令，不会提交生图任务。

### GET `/api/rpg/profiles`

读取 `rpg_visual_profiles.json`。

### POST `/api/rpg/profiles`

保存角色视觉配置。

## 4. 生成剧情 CG

### POST `/api/rpg/generate`

最小请求：

```json
{
  "client": {
    "gameId": "demo",
    "sceneId": "chapter1_turn15",
    "requestId": "demo_chapter1_turn15"
  },
  "visual": {
    "characters": [
      {
        "id": "luna",
        "expression": "shy, blush",
        "pose": "standing",
        "action": "looking away"
      }
    ],
    "location": "school rooftop",
    "time": "sunset",
    "shot": "cowboy shot",
    "lighting": "warm rim light"
  },
  "generation": {
    "seed": -1
  }
}
```

模型可省略：Easy Panel 会优先选择 WAI / Spectacular / Illustrious 系模型；也可指定：

```json
"generation": {
  "model": "waiIllustriousSDXL_v140.safetensors",
  "width": 832,
  "height": 1216,
  "seed": -1,
  "regional": false
}
```

`generation` 还可以携带与桌面面板同名的高级参数：`steps`、`cfg`、`sampler`、`scheduler`、`illustriousMode`、`guidance`、`vae`、`modelEnhancement` 等。高清二次采样使用 `hiresScale`、`hiresDenoise`、`hiresSteps`、`hiresCfg`、`hiresSampler`、`hiresScheduler`，并可用
`hiresPromptMode`（`inherit` / `append` / `replace`，默认 `append`）、`hiresPositive`、`hiresNegative` 指定二采提示词，用 `hiresCompositionLock` 开启“优先保持首采构图”（二采重绘幅度强制 ≤ 0.35）：

`generation` 也支持桌面面板的「分区替换」（只改一项的同一个底层能力），只替换指定分区、其余全部保持：

```json
"generation": {
  "sectionEdit": {
    "section": "clothing",
    "value": "maid outfit, white apron",
    "mode": "replace"
  }
}
```

`section` 取值：`subject` / `appearance` / `expression` / `clothing` / `pose` / `composition` / `scene` / `lighting` / `style` / `naturalLanguage` / `manual`；`mode` 为 `replace`（默认，清空旧内容）或 `append`（保留旧内容，适合加饰品）。未知分区会被忽略而不会影响整次生成；生成的快照 / 作品库会把操作记为 `outfit_change` / `scene_change` / `style_change` / `section_change`。

```json
"generation": {
  "illustriousMode": "hires",
  "hiresScale": 1.3,
  "hiresDenoise": 0.25,
  "hiresSteps": 16,
  "hiresCfg": 4.0,
  "hiresPromptMode": "append",
  "hiresPositive": "torn clothes, bloodstains, detailed fabric texture",
  "hiresNegative": "",
  "hiresCompositionLock": true
}
```

首采提示词决定构图，二采提示词只负责补细节：`inherit` 直接沿用首采；`append` 在首采基础上追加（留空则等同 `inherit`，不会白白多建节点）；`replace` 完全独立（某一框留空时该项沿用首采）。多人区域提示词开启时二采会按 `inherit` 处理，请勿同时依赖区域蒙版与独立二采提示词。

开启高清二次采样时，Easy Panel 会把首采图另存为独立输出 `<prefix>_base_00001_.png`，供桌面面板做首采 / 二采对照；移动端结果接口会自动过滤这一类文件，只返回最终图（若一次任务只剩首采图则回退返回它）。

`requestId` 是幂等键：同一个 `requestId` 因网络超时而重复 POST 时，Easy Panel 会返回已有任务，不会再次提交 ComfyUI。

提交成功：

```json
{
  "api_version": 2,
  "job_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "status": "queued",
  "status_url": "/api/rpg/jobs/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
}
```

## 5. 查询任务

### GET `/api/rpg/jobs/{job_id}`

生成中：

```json
{
  "job_id": "...",
  "status": "running",
  "images": []
}
```

完成：

```json
{
  "job_id": "...",
  "status": "completed",
  "images": [
    {
      "filename": "RPGBox_demo_chapter1_turn15_00001_.png",
      "url": "/api/rpg/image?name=RPGBox_demo_chapter1_turn15_00001_.png"
    }
  ]
}
```

RPGBox 应把相对 `url` 拼到 Easy Panel Base URL，然后带同一个 Token 下载图片。

## 6. 角色 LoRA / 固定服装

编辑 `rpg_visual_profiles.json`：

```json
{
  "version": 1,
  "defaults": {
    "model": "waiIllustriousSDXL_v140.safetensors",
    "width": 832,
    "height": 1216,
    "safetyLevel": "safe",
    "style": "",
    "negative": "",
    "regional": false
  },
  "characters": {
    "luna": {
      "name": "Luna",
      "gender": "female",
      "trigger": "luna",
      "appearance": "grey hair, short hair, bob cut, blue eyes, pink x-shaped hairclip",
      "loras": [
        {"name": "characters/luna.safetensors", "weight": 0.9}
      ],
      "default_outfit": "default",
      "outfits": {
        "default": "blue cropped top, cropped jacket, blue shorts, white thighhighs",
        "maid": "maid, maid headdress, white apron, frilled apron"
      }
    }
  }
}
```

之后 RPGBox 只发：

```json
{"id":"luna","outfit":"maid","expression":"smile"}
```

Easy Panel 自动补角色 LoRA、外貌和服装，再交给原有模型提示词编译器。

## 7. 双人 Regional Prompting

两名角色时可设置：

```json
"generation": {"regional": true}
```

Easy Panel 会调用项目现有的 Regional Prompting 路线，把两名角色分到左右软区域。每个角色配置的第一项 LoRA 会作为对应区域绑定 LoRA。Anima / Krea 2 会继续遵守项目原有限制，不允许 Regional Prompting。

## 8. Android 注意事项

如果 RPGBox Android 使用 `http://192.168.x.x:8190`，Android WebView/Capacitor 需要允许局域网明文 HTTP（cleartext traffic）。更稳妥的长期方案是给 Easy Panel 加 HTTPS / Tailscale。

推荐交互顺序：

1. RPGBox 先显示 LLM 剧情；
2. 异步 POST `/api/rpg/generate`；
3. 每 1.5~2 秒查询 `/api/rpg/jobs/{id}`；
4. `completed` 后下载图片并缓存到 Android 本地；
5. 断网/切后台后用保存的 `job_id` 继续查询。

Easy Panel 同时在服务端定期对账 ComfyUI 历史。即使手机或电脑页面退出，已提交任务仍会继续执行；任务完成后，作品库状态会自动从 `queued` / `running` 更新为 `completed`，不依赖客户端一直在线。


## 9. API v2 移动端可靠性修正

- 支持 `client.requestId` 幂等提交，避免弱网重试重复生图。
- 支持 `/api/rpg/jobs/by-request/{requestId}` 恢复任务。
- 图片 URL 会保留 ComfyUI `subfolder`，输出到子目录也能下载。
- 图片下载会验证最终路径仍位于 ComfyUI output 目录内，阻止目录穿越。
- 附带 `rpgbox_mobile_sdk/`，可直接复制进 RPGBox React/Capacitor 项目。

## 10. 生成快照与恢复

- `/api/rpg/snapshots` 只返回摘要；`/api/rpg/snapshots/{id}` 在鉴权后返回完整可恢复记录。
- Web 完整面板的 `/api/snapshots`、`/api/snapshot-compare` 和 `/output` 也受面板鉴权保护，不能通过无 Token 的远程请求读取完整提示词、生成参数或图片。
- Android 的“完整恢复”会附加服务器记录的 LoRA、采样、区域和增强配置；“只换 Seed”只改 Seed；“继续编辑”保留该附加配置并允许修改当前可见字段。
- Android 点击“解除快照高级配置 / 转为普通生图”后，仅提交当前可见的普通生图字段，不再隐式带上旧快照高级参数。

## 11. 作品库（Easy Panel 2.2.x · Creative Library Foundation）

Easy Panel 2.2.x 在不改变 JSON 源记录的前提下维护一个可重建的 SQLite 创作索引。Android 快速页面和桌面 Web 面板的“作品库”入口读取以下只读接口：

作品代表图：列表响应的 `thumbnail_url`、`primary_artifact_id` 与详情响应的 `preview`（同一个 artifact）都指向同一张**成品图**——索引库按“优先非首采、文件仍存在的最后一张输出”选择；高清二采的 `<prefix>_base_*.png` 只在旧记录中作为输出列出（`artifacts`），不会被选为代表图，也不会出现在手机端结果列表。

- `GET /api/rpg/library/generations`：分页列表，支持 `limit`、`offset`、`operation`、`status`、`model`、`favorite`、`group`、`sort` 和 `order`；`favorite=favorite` 只返回已入选，`favorite=unfavorite` 只返回未入选；`group=<组编号>` 只看该收藏组，`group=ungrouped` 只看未加入任何收藏组的作品（未知组编号返回空列表，不会静默当成全部）；
- `GET /api/rpg/library/generations/{generation_id}`：作品详情、完整快照、LoRA、输出和结构化 replay / variation 预览；
- `GET /api/rpg/library/generations/{generation_id}/lineage`：父 / 子作品谱系；
- `POST /api/rpg/library/favorite`：保存人工标记，body 为 `{ "generation_id": "<32 位十六进制>", "favorite": true, "rating": 0-5, "note": "≤2000 字", "groups": ["<组编号>"] }`；`favorite`/`rating`/`note`/`groups` 至少给一个；`groups` 为**整体替换**成员关系，也可改用 `group_add` / `group_remove` 只增删；只更新标记，不修改任何生成参数、不新建版本，返回更新后的 `generation` 摘要与最新 `groups`（组列表带 `item_count`）。
- `GET /api/rpg/library/groups`：列出全部自命名收藏组（`groups[]` 含 `group_id` / `name` / `item_count` / `created_at` / `updated_at`）；作品列表与保存标记的响应也会带同一份 `groups`，手机端无需额外请求。
- `POST /api/rpg/library/groups`：`{ "action": "create" | "rename" | "delete", "group_id": "<组编号>", "name": "≤60 字" }`；`create` 同名（忽略大小写/多余空格）时直接返回已有组（`result.created=false`），`rename`/`delete` 不存在的组返回 404；删除组只解除关系，**不会删除任何作品**。

### 11.1 收藏 / 入选 / 评分 / 备注 / 收藏组

`generations` 表的 `favorite INTEGER NOT NULL DEFAULT 0`、`rating INTEGER NOT NULL DEFAULT 0`、`note TEXT NOT NULL DEFAULT ''` 由 V1 的增量迁移自动补齐（旧库无需重建）。收藏组使用 `favorite_groups`（`group_id` / `name`（忽略大小写唯一）/ `created_at` / `updated_at`）与 `generation_favorite_groups`（`generation_id` + `group_id` 多对多，均带 `ON DELETE CASCADE`）两张新表，由同一次 `CREATE TABLE IF NOT EXISTS` 自动建立；作品删除会连带清理关系，组删除则只清理关系。列表与详情响应都会带这些字段，Android 端 `setEasyPanelGenerationFlags()` / `createEasyPanelFavoriteGroup()` / `renameEasyPanelFavoriteGroup()` / `deleteEasyPanelFavoriteGroup()` 与桌面端「★ 入选 / 评分 / 备注 / 收藏组」写入同一份索引：两端共用同一状态，重新读取列表即同步。`favorite` 与收藏组都只是人对作品的判断，绝不会影响生成、恢复或派生流程。

### 11.2 生成前检查与显存风险（仅桌面 Web）

生成前检查是纯前端护栏：它调用面板现有的 `/api/prompt-compile` 与对应模型族的 `*-preflight` 接口，再合并本地可见的尺寸 / LoRA / ControlNet / 二采 / 修复器信息，得到一份清单与**相对**显存等级。它不会提交任务、不修改参数，也不会向新的接口写数据；检查接口不可用时直接放行，由原有后端校验给出错误。

这些接口复用 RPG Token。`replay.can_submit` / `variation.can_submit` 始终为 `false`；Android 和桌面 Web 的恢复只把参数填回当前表单，用户仍需明确点击“生成图片”。恢复后的下一次显式提交最多携带一次父作品关系，提交成功后清除，失败保留供重试，也可取消关联；换 Seed 固定映射为 `seed_variant`，复现 / 继续编辑保留已有记录的 operation。作品库恢复不会自动挑选具体 artifact 作为图生图、局部重绘或修复输入，当前也不会因此建立 `parentArtifactId`；未来只有真实使用用户明确选择的具体输入时才可建立该关系。桌面 Web 入口支持分页、操作 / 状态 / 模型筛选和排序；输出通过现有带鉴权的 `/api/rpg/image` 路径打开或下载，缺失文件不会被图片接口提供。Android 作品库首屏只加载可视区域缩略图，缩略图请求可附加 `preview=1` 获取 360px 预览；原图仍通过不带 `preview=1` 的鉴权路径打开或下载。旧服务端忽略该参数时仍可回退为原图请求。旧服务端 404、空索引、断网或缺少谱系接口时只显示回退提示，不会自动提交生成。完整 schema、迁移、重建命令和后续规划见 [CREATIVE_STATE_ARCHITECTURE.md](CREATIVE_STATE_ARCHITECTURE.md)。
