"""Smart LoRA metadata, same-name TXT, and JSON-note utilities.

This module never loads tensor data.  Safetensors inspection reads only the
JSON header, and TXT recognition is deterministic and fully local.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from collections import Counter
from datetime import datetime
from pathlib import Path

from easy_panel_app.tag_classifier import (
    CATEGORIES,
    classify_tag,
    classify_tag_list,
    is_trigger_or_character,
    normalize_tag,
)


SIDECAR_MARKER = "# Easy Panel LoRA Sidecar v2"
# LORA_MEMO_RULES.md §3.1 标准侧车：头部【键】与分项块
STANDARD_HEADER_FIELDS = {
    "显示标题": "title", "标题": "title",
    "底模": "base_model", "适用底模": "base_model",
    "建议权重": "weight", "推荐权重": "weight", "权重": "weight",
    "页面url": "url", "页面 url": "url", "url": "url",
    "顶层触发词": "trigger", "触发词": "trigger",
}
STANDARD_HEADER_SKIP = {"模型文件名", "文件名", "相对路径", "路径", "sha256", "生成器来源", "备注"}
STANDARD_MAIN_FIELDS = {
    "角色": "subject", "人物": "subject", "character": "subject", "subject": "subject",
    "外貌": "appearance", "appearance": "appearance",
    "服装": "clothing", "clothing": "clothing",
    "姿势": "pose", "pose": "pose",
    "构图": "composition", "composition": "composition",
    "场景": "scene", "scene": "scene",
    "光线": "lighting", "lighting": "lighting",
    "画风": "style", "style": "style",
    "上色": "coloring", "coloring": "coloring",
    "负面": "negative", "negative": "negative",
    "其他": "other", "other": "other",
}
RULE_MAIN_CLASSES = {
    "subject": "character", "appearance": "appearance", "clothing": "clothing", "pose": "pose",
    "composition": "composition", "scene": "scene", "lighting": "lighting", "style": "style",
    "coloring": "coloring", "negative": "negative", "other": "other",
}
RULE_MAIN_LABELS = {
    "subject": "角色", "appearance": "外貌", "clothing": "服装", "pose": "姿势",
    "composition": "构图", "scene": "场景", "lighting": "光线", "style": "画风",
    "coloring": "上色", "negative": "负面", "other": "其他",
}


def parse_standard_sidecar(text: str) -> tuple[list[tuple[str, str, str]], dict[str, str]]:
    """Read the LORA_MEMO_RULES.md §3.1 layout.

    Returns ``(items, meta)`` where each item is ``(name, category_field, content)``
    and ``meta`` uses the same keys as :func:`_extract_meta` plus
    ``_explicit_trigger`` when the file declares the top-level trigger state.
    """
    items: list[tuple[str, str, str]] = []
    meta: dict[str, str] = {}
    lines = [raw.strip() for raw in str(text or "").splitlines()]
    index = 0
    while index < len(lines):
        line = lines[index]
        if not line:
            index += 1
            continue
        header = re.match(r"^[\[【]([^\]】]{1,20})[\]】]\s*(.*)$", line)
        if header:
            key = normalize_tag(header.group(1))
            value = header.group(2).strip()
            field = STANDARD_HEADER_FIELDS.get(key) or STANDARD_HEADER_FIELDS.get(header.group(1).strip().lower())
            if field:
                if field == "trigger":
                    meta["_explicit_trigger"] = "1"
                    if value and not value.startswith("无"):
                        meta["trigger"] = re.split(r"[,，;；]", value, maxsplit=1)[0].strip()
                elif value and not meta.get(field):
                    meta[field] = value
            index += 1
            continue
        name = re.match(r"^名称\s*[:：]\s*(.*)$", line)
        if not name:
            index += 1
            continue
        item_name = name.group(1).strip()
        cursor = index + 1
        category = ""
        if cursor < len(lines):
            main = re.match(r"^主类\s*[:：]\s*(.+)$", lines[cursor])
            if main:
                parts = [part.strip() for part in main.group(1).split("/")]
                category = STANDARD_MAIN_FIELDS.get(parts[0], "") if parts else ""
                for part in reversed(parts[1:]):
                    token = STANDARD_MAIN_FIELDS.get(part.lower(), "")
                    if token:
                        category = token
                        break
                cursor += 1
        prompt = re.match(r"^提示词\s*[:：]\s*(.*)$", lines[cursor]) if cursor < len(lines) else None
        if not prompt:
            index = cursor
            continue
        body: list[str] = []
        if prompt.group(1).strip():
            body.append(prompt.group(1).strip())
        cursor += 1
        while cursor < len(lines):
            candidate = lines[cursor]
            if re.match(r"^(?:名称|主类|提示词)\s*[:：]", candidate) or re.match(r"^[\[【]", candidate):
                break
            if candidate:
                body.append(candidate)
            cursor += 1
        content = "\n".join(body).strip()
        if item_name and content:
            items.append((item_name, category or "other", content))
        index = cursor
    return items, meta


NOTE_FIELDS = ("subject", "appearance", "clothing", "pose", "composition", "scene",
               "lighting", "style", "coloring", "negative", "other")
OUTFIT_MAIN_CLASS_FIELDS = (
    ("subject", "character"), ("appearance", "appearance"),
    ("clothing", "clothing"), ("prompt", "clothing"),
    ("pose", "pose"), ("composition", "composition"), ("scene", "scene"),
    ("lighting", "lighting"), ("style", "style"), ("coloring", "coloring"),
    ("negative", "negative"), ("other", "other"), ("manual", "other"),
)
SECTION_LABELS = {
    "subject": "人物与角色",
    "appearance": "角色外貌",
    "clothing": "服装与配饰",
    "pose": "姿势与动作",
    "composition": "构图与镜头",
    "scene": "场景与背景",
    "lighting": "光线",
    "style": "画风与媒介",
    "negative": "负面标签",
    "other": "其他标签",
}

_META_KEYS = {
    "title": ("名称", "标题", "name", "title", "lora"),
    "base_model": ("适用底模", "底模", "base model", "base_model", "model"),
    "weight": ("推荐权重", "推荐强度", "权重", "重量", "weight", "strength", "best weight",
               "recommended weight"),
    "trigger": ("触发词", "触发点", "trigger", "trigger word", "activation text"),
    "url": ("来源", "链接", "网址", "url", "source"),
}

_CATEGORY_ALIASES = {
    "subject": ("人物与角色", "人物", "角色", "角色tag", "character", "characters",
                "character tag", "character tags", "subject", "personality", "性格", "基础角色"),
    "appearance": ("角色外貌", "外貌", "appearance", "character appearance", "face", "hair", "body"),
    "clothing": ("服装与配饰", "服装", "衣服", "配饰", "clothes", "clothing", "outfit",
                 "outfits", "costume", "dress", "uniform", "swimsuit", "bikini"),
    "pose": ("姿势与动作", "姿势", "动作", "pose", "poses", "action", "weapon", "武器"),
    "composition": ("构图与镜头", "构图", "镜头", "视角", "composition", "camera", "framing"),
    "scene": ("场景与背景", "场景", "背景", "scene", "background", "environment", "location"),
    "lighting": ("光线", "灯光", "lighting", "light", "illumination"),
    "style": ("画风与媒介", "画风", "风格", "上色", "style", "medium", "rendering", "coloring"),
    "negative": ("负面标签", "负面", "反向", "negative", "negative prompt", "undesired"),
    "other": ("其他标签", "其他", "补充", "others", "other", "misc", "extra", "optional tags"),
}

_SKIP_LINE_PREFIXES = (
    "备注", "说明", "注意", "免责声明", "简介", "作者", "训练信息", "本文件", "生成器",
    "训练参数", "note", "notes", "description", "disclaimer", "training info",
    "training parameters", "generated by",
)

_QUALITY_TAGS = {
    "masterpiece", "best quality", "high quality", "highres", "absurdres", "newest",
    "safe", "sensitive", "nsfw", "explicit", "score 9", "score 8 up", "score 7 up",
    "source anime", "source cartoon", "rating safe", "rating explicit",
}


def _unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        item = str(value or "").strip().strip("，,、;；")
        key = normalize_tag(item)
        if item and key and key not in seen:
            seen.add(key)
            result.append(item)
    return result


def split_prompt_tags(value: str, limit: int = 500) -> list[str]:
    """Split tags without breaking weighted parentheses or quoted fragments."""
    text = re.sub(r"<lora:[^>]+>", "", str(value or ""), flags=re.I)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    result: list[str] = []
    buffer: list[str] = []
    depth = 0
    quote = ""
    for char in text:
        if quote:
            buffer.append(char)
            if char == quote:
                quote = ""
            continue
        if char in {'"', "'"}:
            quote = char
            buffer.append(char)
        elif char in "([{" :
            depth += 1
            buffer.append(char)
        elif char in ")]}" :
            depth = max(0, depth - 1)
            buffer.append(char)
        elif depth == 0 and char in ",，、;；\n":
            item = "".join(buffer).strip().strip("-•* \t")
            if item:
                result.append(item)
            buffer = []
        else:
            buffer.append(char)
    item = "".join(buffer).strip().strip("-•* \t")
    if item:
        result.append(item)
    cleaned: list[str] = []
    for item in result:
        item = re.sub(r"^(?:tags?|prompt)\s*[:：]\s*", "", item, flags=re.I).strip()
        if re.fullmatch(r"https?://\S+", item, re.I):
            continue
        if item:
            cleaned.append(item)
    return _unique(cleaned)[:limit]


def _category_for_header(header: str) -> tuple[str | None, str | None]:
    """Return ``(forced_category, preset_name)`` for a TXT block header."""
    raw = str(header or "").strip().strip("[]【】#：:")
    if "::" in raw:
        preset, category_header = raw.split("::", 1)
        category, _ = _category_for_header(category_header)
        if category:
            return category, preset.strip() or "自动识别"
    low = normalize_tag(raw)
    low = re.sub(r"^tags?\s*\((.*?)\)$", r"\1", low)
    low = re.sub(r"^tags?\s+", "", low)
    for category, aliases in _CATEGORY_ALIASES.items():
        if low in {normalize_tag(alias) for alias in aliases}:
            default_name = "默认服装" if category == "clothing" else None
            return category, default_name

    prefix_patterns = (
        ("subject", r"^(?:角色|人物|character)\s*[-—–]+\s*(.+)$"),
        ("appearance", r"^(?:外貌|appearance)\s*[-—–]+\s*(.+)$"),
        ("clothing", r"^(?:服装|衣服|outfit|costume)\s*[-—–]+\s*(.+)$"),
        ("pose", r"^(?:姿势|动作|pose|action)\s*[-—–]+\s*(.+)$"),
        ("scene", r"^(?:场景|背景|scene|background)\s*[-—–]+\s*(.+)$"),
    )
    for category, pattern in prefix_patterns:
        match = re.match(pattern, raw, re.I)
        if match:
            return category, match.group(1).strip()

    if re.search(r"替代服装|替换服装|alternative outfit", low):
        return "clothing", "替代服装"
    if re.search(r"第二.*服装|second outfit", low):
        return "clothing", "第二套服装"
    if re.search(r"服装触发|default outfit", low):
        return "clothing", "默认服装"
    return None, raw or None


def _meta_label(header: str) -> str | None:
    low = normalize_tag(header)
    for field, aliases in _META_KEYS.items():
        if low in {normalize_tag(alias) for alias in aliases}:
            return field
    return None


def _extract_meta(text: str, filename: str) -> dict[str, str]:
    result = {"title": "", "base_model": "", "weight": "",
              "trigger": "", "url": ""}
    for raw in str(text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        colon = re.match(r"^([^:：]{1,40})[:：]\s*(.+)$", line)
        if colon:
            field = _meta_label(colon.group(1))
            if field:
                value = colon.group(2).strip()
                if field == "trigger":
                    value = re.split(r"[,，;；]", value, maxsplit=1)[0].strip()
                if field == "url":
                    match = re.search(r"https?://\S+", value)
                    value = match.group(0).rstrip(".,，。") if match else value
                if value and not result[field]:
                    result[field] = value
        if not result["url"]:
            match = re.search(r"https?://\S+", line)
            if match:
                result["url"] = match.group(0).rstrip(".,，。")
        if not result["weight"]:
            match = re.search(
                r"(?:推荐|权重|重量|强度|weight|strength)[^0-9]{0,10}"
                r"([0-9]+(?:\.[0-9]+)?)(?:\s*[-~–—]\s*([0-9]+(?:\.[0-9]+)?))?",
                line, re.I,
            )
            if match:
                result["weight"] = match.group(1) + (("-" + match.group(2)) if match.group(2) else "")
        if not result["trigger"]:
            match = re.search(r"(?:触发词|触发点|trigger(?: word)?)\s*(?:为|[:：])\s*(.+)$", line, re.I)
            if match:
                result["trigger"] = re.split(r"[,，;；。]", match.group(1), maxsplit=1)[0].strip()
        if not result["base_model"]:
            match = re.search(r"(?:适用底模|底模|base model)\s*[:：]\s*([^,，;；。]+)", line, re.I)
            if match:
                result["base_model"] = match.group(1).strip()
    if not result["title"]:
        result["title"] = Path(filename or "LoRA").stem
    return result


def _is_probable_header(line: str) -> bool:
    value = str(line or "").strip()
    if not value or len(value) > 80 or re.search(r"[,，;；]", value):
        return False
    if re.match(r"^(?:%s)" % "|".join(map(re.escape, _SKIP_LINE_PREFIXES)), value, re.I):
        return False
    if _meta_label(value) or _category_for_header(value)[0]:
        return True
    category, _, confidence = classify_tag(value)
    if category != "other" and confidence >= 0.75:
        return False
    if is_trigger_or_character(value):
        return False
    latin_words = re.findall(r"[A-Za-z]+", value)
    cjk = re.findall(r"[\u4e00-\u9fff]", value)
    return bool(cjk) or len(latin_words) <= 6


def _text_blocks(text: str) -> list[tuple[str, list[str]]]:
    blocks: list[tuple[str, list[str]]] = []
    header = "默认预设"
    bracket_context = ""
    lines: list[str] = []

    def flush() -> None:
        nonlocal lines
        if lines:
            blocks.append((header, lines))
        lines = []

    clean_lines = [
        raw.strip().strip("\ufeff")
        for raw in str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if raw.strip().strip("\ufeff") and raw.strip().strip("\ufeff") != SIDECAR_MARKER
    ]

    for index, line in enumerate(clean_lines):
        bracket = re.match(r"^[\[【]([^\]】]{1,60})[\]】]\s*(.*)$", line)
        if bracket:
            flush()
            bracket_key = normalize_tag(bracket.group(1))
            if bracket_key in STANDARD_HEADER_FIELDS or bracket_key in STANDARD_HEADER_SKIP:
                bracket_context = ""
                continue
            header = bracket.group(1).strip()
            bracket_context = header
            if bracket.group(2).strip():
                lines.append(bracket.group(2).strip())
            continue
        colon = re.match(r"^([^:：]{1,60})[:：]\s*(.*)$", line)
        if colon:
            label, rest = colon.group(1).strip(), colon.group(2).strip()
            if _meta_label(label):
                if not rest:
                    flush()
                    bracket_context = ""
                    header = label
                continue
            if re.match(r"^(?:%s)" % "|".join(map(re.escape, _SKIP_LINE_PREFIXES)), label, re.I):
                continue
            flush()
            category, _ = _category_for_header(label)
            header = f"{bracket_context}::{label}" if bracket_context and category else label
            if not category:
                bracket_context = ""
            if rest:
                lines.append(rest)
            continue
        compact = re.match(r"^(角色|人物|服装)([^,，]{1,40})[,，]\s*(.+)$", line, re.I)
        if compact:
            flush()
            bracket_context = ""
            header = f"{compact.group(1)} - {compact.group(2).strip()}"
            body = compact.group(3).strip()
            if compact.group(1) in {"角色", "人物"}:
                body = f"{compact.group(2).strip()}, {body}"
            lines.append(body)
            continue
        compact_name = re.match(r"^([\u4e00-\u9fff]{1,12})([A-Z][^,，]{1,40})[,，]\s*(.+)$", line)
        if compact_name:
            flush()
            bracket_context = ""
            header = f"{compact_name.group(1).strip()} {compact_name.group(2).strip()}"
            lines.append(f"{compact_name.group(2).strip()}, {compact_name.group(3).strip()}")
            continue
        mixed = re.match(r"^([\u4e00-\u9fff]{2,16})\s+(.+[,，].+)$", line)
        if mixed:
            flush()
            bracket_context = ""
            header = mixed.group(1).strip()
            lines.append(mixed.group(2).strip())
            continue
        # A lone short line is usually the actual trigger/tag (for example HGK,
        # @artist or a character name), not an empty section title.  Only treat
        # an unlabelled short line as a header when content follows it.
        next_line = clean_lines[index + 1] if index + 1 < len(clean_lines) else ""
        explicit_header = bool(_meta_label(line) or _category_for_header(line)[0])
        next_looks_like_payload = bool(re.search(r"[,，;；]", next_line))
        if (_is_probable_header(line) and next_line
                and (explicit_header or next_looks_like_payload)):
            flush()
            bracket_context = ""
            header = line.rstrip("：:").strip()
            continue
        lines.append(line)
    flush()
    return blocks


def _block_tags(lines: list[str]) -> list[str]:
    tags: list[str] = []
    for line in lines:
        if re.match(r"^(?:%s)" % "|".join(map(re.escape, _SKIP_LINE_PREFIXES)), line, re.I):
            continue
        tags.extend(split_prompt_tags(line))
    return _unique(tags)


def _merge_sections(target: dict[str, list[str]], source: dict[str, list[str]]) -> None:
    for category in NOTE_FIELDS:
        target[category] = _unique(target.get(category, []) + source.get(category, []))


def _serialise_outfit(name: str, sections: dict[str, list[str]]) -> dict:
    result = {"name": str(name or "自动识别").strip() or "自动识别"}
    for category in NOTE_FIELDS:
        values = _unique(sections.get(category, []))
        if values:
            result[category] = ", ".join(values)
    return result


def _folder_hint(filename: str) -> str | None:
    """Use the containing folder only as a fallback for otherwise opaque tags."""
    value = str(filename or "").replace("\\", "/").casefold()
    groups = (
        ("style", ("画风", "风格", "/style", "style/", "styles/", "artist")),
        ("clothing", ("服装", "衣服", "丝袜", "穿搭", "/outfit", "/clothing", "costume")),
        ("subject", ("人物", "角色", "/character", "characters/")),
        ("pose", ("姿势", "动作", "/pose", "poses/")),
        ("scene", ("场景", "背景", "/scene", "background")),
    )
    for category, tokens in groups:
        if any(token in value for token in tokens):
            return category
    return None


def _meta_from_block(meta: dict[str, str], field: str, tags: list[str]) -> list[str]:
    """Consume a bare metadata block and return tags still worth classifying."""
    if not tags:
        return []
    joined = ", ".join(tags).strip()
    if field == "trigger":
        if not meta.get("trigger"):
            meta["trigger"] = tags[0]
        return tags
    if field == "weight":
        match = re.search(r"[0-9]+(?:\.[0-9]+)?(?:\s*[-~–—]\s*[0-9]+(?:\.[0-9]+)?)?", joined)
        if match and not meta.get("weight"):
            meta["weight"] = re.sub(r"\s*[-~–—]\s*", "-", match.group(0))
        return []
    if field == "url":
        match = re.search(r"https?://\S+", joined)
        value = match.group(0).rstrip(".,，。") if match else joined
    else:
        value = joined
    fallback_title = Path(str(meta.get("title", ""))).stem
    source_title = Path(str(meta.get("_source", ""))).stem
    if value and (not meta.get(field) or (field == "title" and fallback_title == source_title)):
        meta[field] = value
    return []


def smart_parse_lora_sidecar(content: str, filename: str = "") -> dict:
    """Parse arbitrary LoRA TXT into canonical, separately stored sections."""
    text = str(content or "")
    meta = _extract_meta(text, filename)
    meta["_source"] = filename
    standard_items, standard_meta = parse_standard_sidecar(text)
    for key, value in standard_meta.items():
        if key == "_explicit_trigger":
            meta["_explicit_trigger"] = value
        elif value:
            # 【键】头部比散落的中文冒号行更权威
            meta[key] = value
    if meta.get("_explicit_trigger") and not standard_meta.get("trigger"):
        meta["trigger"] = ""
    if standard_items:
        standard_outfits: list[dict] = []
        for item_name, category, item_content in standard_items:
            sections = {name: [] for name in NOTE_FIELDS}
            sections[category] = split_prompt_tags(item_content)
            if any(sections.values()):
                standard_outfits.append(_serialise_outfit(item_name, sections))
        if standard_outfits:
            standard_meta_out = {key: value for key, value in meta.items() if key != "_source"}
            standard_meta_out.pop("_explicit_trigger", None)
            return {
                "schema_version": 2,
                **standard_meta_out,
                "outfits": standard_outfits,
                "unclassified": [],
                "stats": {
                    "blocks": len(standard_outfits),
                    "presets": len(standard_outfits),
                    "classified_tags": sum(
                        len(split_prompt_tags(item.get(category, ""))) for item in standard_outfits
                        for category in NOTE_FIELDS
                    ),
                },
            }
    base_sections = {category: [] for category in NOTE_FIELDS}
    named: list[tuple[str, dict[str, list[str]]]] = []
    unclassified: list[str] = []
    blocks = _text_blocks(text)
    folder_hint = _folder_hint(filename)

    for header, lines in blocks:
        tags = _block_tags(lines)
        if not tags:
            continue
        meta_field = _meta_label(header)
        if meta_field:
            tags = _meta_from_block(meta, meta_field, tags)
            if not tags:
                continue
            header = "默认预设"
        forced, preset_name = _category_for_header(header)
        sections = classify_tag_list(tags)
        sections = {category: list(sections.get(category, [])) for category in NOTE_FIELDS}
        if forced:
            movable = list(sections.get("other", []))
            if movable and forced != "other":
                sections[forced] = _unique(sections.get(forced, []) + movable)
                sections["other"] = []

        # Folder names are useful for opaque activation tokens such as HGK or
        # an artist handle.  They are only allowed to override low-information
        # subject/other results, never a recognised garment, pose, scene, etc.
        populated = {category for category in NOTE_FIELDS if sections.get(category)}
        if not forced and folder_hint and populated and populated <= {"subject", "other"}:
            fallback = _unique(sections.get("subject", []) + sections.get("other", []))
            sections["subject"] = []
            sections["other"] = []
            sections[folder_hint] = fallback

        unclassified.extend(sections.get("other", []))

        generic_header = normalize_tag(header) in {
            "默认预设", "default", "recommended", "推荐", "可选tags", "可选标签",
        }
        if forced and preset_name is None:
            _merge_sections(base_sections, sections)
        elif generic_header:
            _merge_sections(base_sections, sections)
        else:
            name = preset_name or header or "自动识别"
            existing = next((entry for entry in named if normalize_tag(entry[0]) == normalize_tag(name)), None)
            if existing:
                _merge_sections(existing[1], sections)
            else:
                named.append((name, sections))

    outfits: list[dict] = []
    if any(base_sections[category] for category in NOTE_FIELDS):
        if base_sections["subject"] or base_sections["appearance"]:
            base_name = "基础角色"
        elif base_sections["clothing"]:
            base_name = "默认服装"
        else:
            base_name = "自动识别"
        outfits.append(_serialise_outfit(base_name, base_sections))
    outfits.extend(_serialise_outfit(name, sections) for name, sections in named
                   if any(sections[category] for category in NOTE_FIELDS))

    if not meta["trigger"] and not meta.get("_explicit_trigger"):
        subject_tags: list[str] = []
        for outfit in outfits:
            subject_tags.extend(split_prompt_tags(outfit.get("subject", "")))
        candidate = next((tag for tag in subject_tags if is_trigger_or_character(tag)), "")
        meta["trigger"] = candidate

    meta.pop("_source", None)
    meta.pop("_explicit_trigger", None)
    return {
        "schema_version": 2,
        **meta,
        "outfits": outfits,
        "unclassified": _unique(unclassified),
        "stats": {
            "blocks": len(blocks),
            "presets": len(outfits),
            "classified_tags": sum(
                len(split_prompt_tags(value))
                for outfit in outfits for key, value in outfit.items() if key != "name"
            ),
        },
    }


# Public compatibility name used by the panel.
parse_lora_sidecar = smart_parse_lora_sidecar


def read_safetensors_metadata(path: Path, max_header_bytes: int = 64 * 1024 * 1024) -> dict[str, str]:
    """Read only the safetensors JSON metadata header."""
    file = Path(path)
    with file.open("rb") as handle:
        size_raw = handle.read(8)
        if len(size_raw) != 8:
            raise ValueError("文件太短，不是有效的 safetensors。")
        header_size = int.from_bytes(size_raw, "little")
        if not 2 <= header_size <= max_header_bytes:
            raise ValueError(f"safetensors 头部大小异常：{header_size} bytes。")
        header = json.loads(handle.read(header_size).decode("utf-8"))
    metadata = header.get("__metadata__", {}) if isinstance(header, dict) else {}
    return {str(key): str(value) for key, value in metadata.items()} if isinstance(metadata, dict) else {}


def _json_object(value: str):
    try:
        return json.loads(str(value or ""))
    except (TypeError, json.JSONDecodeError):
        return None


def _metadata_tag_counter(metadata: dict[str, str]) -> Counter:
    counter: Counter = Counter()
    parsed = _json_object(metadata.get("ss_tag_frequency", ""))
    if isinstance(parsed, dict):
        for value in parsed.values():
            if isinstance(value, dict):
                for tag, count in value.items():
                    try:
                        counter[str(tag)] += int(count)
                    except (TypeError, ValueError):
                        continue
    for key in ("modelspec.tags", "modelspec.trigger_phrase", "trigger_words", "activation text"):
        raw = metadata.get(key, "")
        for tag in split_prompt_tags(raw):
            # Counter.total() was added in Python 3.10, while bundled
            # ComfyUI environments can still use older Python releases.
            counter[tag] += max(1, sum(counter.values()) // 100)
    return counter


def infer_base_model(metadata: dict[str, str], path: Path | None = None) -> str:
    haystack = " ".join(
        metadata.get(key, "") for key in (
            "ss_base_model_version", "ss_sd_model_name", "modelspec.architecture",
            "modelspec.implementation", "modelspec.title", "ss_network_module",
        )
    )
    if path:
        haystack += " " + str(path)
    low = haystack.casefold()
    if "anima" in low:
        return "Anima"
    if any(token in low for token in ("illustrious", "noobai", "ilxl", "wai")):
        return "Illustrious"
    if "pony" in low:
        return "Pony SDXL"
    if "flux" in low:
        return "FLUX"
    if any(token in low for token in ("sdxl", "stable-diffusion-xl", "sd_xl")):
        return "SDXL"
    if any(token in low for token in ("sd15", "sd 1.5", "stable-diffusion-v1")):
        return "SD 1.5"
    return ""


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sidecar_from_safetensors(path: Path, max_tags: int = 80) -> dict:
    """Build a smart sidecar document from embedded training metadata."""
    file = Path(path)
    metadata = read_safetensors_metadata(file)
    counter = _metadata_tag_counter(metadata)
    ranked: list[str] = []
    for tag, _ in counter.most_common(max_tags * 3):
        normalized = normalize_tag(tag)
        if not normalized or normalized in _QUALITY_TAGS or normalized.startswith("score "):
            continue
        if re.fullmatch(r"(?:rating|source|year)\s+\w+", normalized):
            continue
        ranked.append(tag)
        if len(ranked) >= max_tags:
            break
    sections = classify_tag_list(ranked)
    explicit_trigger = ""
    for key in ("modelspec.trigger_phrase", "trigger_words", "activation text"):
        candidates = split_prompt_tags(metadata.get(key, ""))
        if candidates:
            explicit_trigger = candidates[0]
            break
    trigger = explicit_trigger or next(
        (tag for tag in ranked if is_trigger_or_character(tag) and classify_tag(tag)[0] == "subject"),
        "",
    )
    title = metadata.get("modelspec.title") or metadata.get("ss_output_name") or file.stem
    url = metadata.get("modelspec.url", "")
    outfit = _serialise_outfit("自动提取", {key: sections.get(key, []) for key in NOTE_FIELDS})
    return {
        "schema_version": 2,
        "title": title,
        "file_name": file.name,
        "sha256": file_sha256(file),
        "base_model": infer_base_model(metadata, file),
        "weight": metadata.get("modelspec.recommended_weight", "0.7"),
        "trigger": trigger,
        "url": url,
        "outfits": [outfit] if len(outfit) > 1 else [],
        "metadata_keys": len(metadata),
        "training_tag_count": len(counter),
    }


def render_sidecar(document: dict, source_name: str = "") -> str:
    """渲染 LORA_MEMO_RULES.md §3.1 标准的同名 TXT。"""
    relative = str(document.get("relative_path") or source_name or "").replace("\\", "/")
    file_name = str(document.get("file_name") or "") or (Path(relative).name if relative else "")
    url = str(document.get("url", "") or "").strip()
    known_url = bool(re.search(r"https?://", url))
    trigger = str(document.get("trigger", "") or "").strip()
    lines = [
        SIDECAR_MARKER,
        "# 本文件由本地元数据生成；请核对触发词后再正式出图。",
        f"【显示标题】{document.get('title', '')}",
        f"【模型文件名】{file_name}",
        f"【相对路径】{relative}",
        f"【SHA256】{document.get('sha256', '')}",
        f"【底模】{document.get('base_model', '')}",
        f"【建议权重】{str(document.get('weight', '') or '').strip()}",
        f"【页面URL】{url if known_url else ''}",
    ]
    if not known_url:
        lines.append("【顶层触发词】无（未确认独立触发词）")
        lines.append("")
        lines.append("备注：自动生成，未确认页面来源；请核对后再正式出图。")
    elif trigger:
        lines.append(f"【顶层触发词】{trigger}")
    else:
        lines.append("【顶层触发词】无")
    for outfit in document.get("outfits", []):
        filled = [(category, str(outfit.get(category, "") or "").strip())
                  for category in NOTE_FIELDS]
        filled = [(category, value) for category, value in filled if value]
        if not filled:
            continue
        base_name = str(outfit.get("name", "自动提取") or "自动提取").strip() or "自动提取"
        for index, (category, value) in enumerate(filled):
            label = RULE_MAIN_LABELS.get(category, category)
            item_name = base_name if index == 0 else f"{base_name}·{label}"
            main_class = RULE_MAIN_CLASSES.get(category, category)
            lines.extend(("", f"名称：{item_name}",
                          f"主类：{label} / {main_class} / {category}",
                          "提示词：", value))
    lines.append("")
    return "\n".join(lines)


def is_generated_sidecar(path: Path) -> bool:
    try:
        first = Path(path).read_text(encoding="utf-8-sig", errors="replace")[:200]
    except OSError:
        return False
    return SIDECAR_MARKER in first


def read_text_smart(path: Path) -> str:
    """Read common UTF/Chinese/Japanese TXT encodings without mojibake."""
    data = Path(path).read_bytes()
    if not data:
        return ""
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig")
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        pass
    if data.count(b"\x00") > max(2, len(data) // 20):
        for encoding in ("utf-16-le", "utf-16-be"):
            try:
                return data.decode(encoding)
            except UnicodeDecodeError:
                continue
    legacy: dict[str, str] = {}
    for encoding in ("gb18030", "cp932"):
        try:
            legacy[encoding] = data.decode(encoding)
        except UnicodeDecodeError:
            continue
    japanese = legacy.get("cp932", "")
    if japanese:
        # Full-width hiragana/katakana strongly indicates Japanese.  Do not
        # count half-width katakana here: Chinese GBK decoded as CP932 often
        # turns into a long run of half-width mojibake.
        kana = len(re.findall(r"[\u3040-\u30ff]", japanese))
        han = len(re.findall(r"[\u3400-\u9fff]", japanese))
        if kana >= 2 and kana * 2 >= max(1, han):
            return japanese
    if "gb18030" in legacy:
        return legacy["gb18030"]
    if japanese:
        return japanese
    return data.decode("utf-8", errors="replace")


def load_notes(path: Path) -> dict:
    file = Path(path)
    if not file.is_file():
        return {}
    with file.open("r", encoding="utf-8-sig") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("lora_notes.json 顶层必须是 JSON 对象。")
    return payload


def backup_notes(path: Path) -> Path | None:
    file = Path(path)
    if not file.is_file():
        return None
    backup_dir = file.parent / "backup"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    target = backup_dir / f"lora_notes.before-smart-import.{stamp}.json"
    suffix = 1
    while target.exists():
        target = backup_dir / f"lora_notes.before-smart-import.{stamp}.{suffix}.json"
        suffix += 1
    shutil.copy2(file, target)
    return target


def atomic_write_notes(path: Path, notes: dict) -> None:
    file = Path(path)
    file.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=file.name + ".", suffix=".tmp", dir=file.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(notes, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, file)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def outfit_main_class(outfit: dict) -> str:
    """Classify by the first populated editor field, left-to-right then top-to-bottom."""
    item = outfit if isinstance(outfit, dict) else {}
    return next((main_class for field, main_class in OUTFIT_MAIN_CLASS_FIELDS
                 if str(item.get(field, "") or "").strip()), "other")


def classify_lora_note_outfits(notes: dict) -> dict:
    """Set a deterministic main_class on every saved LoRA memo preset in place."""
    if not isinstance(notes, dict):
        return notes
    for note in notes.values():
        if not isinstance(note, dict):
            continue
        for outfit in note.get("outfits", []):
            if isinstance(outfit, dict):
                outfit["main_class"] = outfit_main_class(outfit)
    return notes


def _canonical_outfit(outfit: dict) -> dict:
    result = {"name": str(outfit.get("name", "自动识别") or "自动识别").strip()}
    aliases = {"clothing": ("clothing", "prompt"), "other": ("other", "manual")}
    for field in NOTE_FIELDS:
        values = aliases.get(field, (field,))
        value = next((str(outfit.get(key, "") or "").strip() for key in values
                      if str(outfit.get(key, "") or "").strip()), "")
        if value:
            result[field] = ", ".join(_unique(split_prompt_tags(value)))
    result["main_class"] = outfit_main_class(result)
    return result


def merge_note(existing: dict, parsed: dict, replace: bool = False) -> tuple[dict, bool]:
    """Merge parsed data while preserving non-empty manual fields by default."""
    old = existing if isinstance(existing, dict) else {}
    note = {} if replace else json.loads(json.dumps(old, ensure_ascii=False))
    for field in ("title", "base_model", "weight", "trigger", "url"):
        incoming = str(parsed.get(field, "") or "").strip()
        if incoming and (replace or not str(note.get(field, "") or "").strip()):
            note[field] = incoming
    existing_outfits = [] if replace else [_canonical_outfit(item) for item in note.get("outfits", [])
                                            if isinstance(item, dict)]
    for incoming_raw in parsed.get("outfits", []):
        if not isinstance(incoming_raw, dict):
            continue
        incoming = _canonical_outfit(incoming_raw)
        name_key = normalize_tag(incoming.get("name", ""))
        index = next((i for i, item in enumerate(existing_outfits)
                      if normalize_tag(item.get("name", "")) == name_key), None)
        if index is None:
            existing_outfits.append(incoming)
            continue
        if replace:
            existing_outfits[index] = incoming
            continue
        current = existing_outfits[index]
        for field in NOTE_FIELDS:
            if incoming.get(field) and not current.get(field):
                current[field] = incoming[field]
    for outfit in existing_outfits:
        outfit["main_class"] = outfit_main_class(outfit)
    if existing_outfits:
        note["outfits"] = existing_outfits
    return note, note != old


__all__ = [
    "NOTE_FIELDS",
    "OUTFIT_MAIN_CLASS_FIELDS",
    "SIDECAR_MARKER",
    "atomic_write_notes",
    "backup_notes",
    "classify_lora_note_outfits",
    "infer_base_model",
    "is_generated_sidecar",
    "outfit_main_class",
    "load_notes",
    "merge_note",
    "parse_lora_sidecar",
    "read_safetensors_metadata",
    "read_text_smart",
    "render_sidecar",
    "sidecar_from_safetensors",
    "smart_parse_lora_sidecar",
    "split_prompt_tags",
]
