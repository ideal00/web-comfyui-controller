(function (global) {
  'use strict';

  const OPERATIONS = Object.freeze([
    'txt2img', 'seed_variant', 'img2img', 'inpaint', 'face_fix',
    'hand_fix', 'upscale', 'outfit_change', 'scene_change', 'style_change', 'flux_edit', 'unknown',
  ]);
  const STATUSES = Object.freeze(['queued', 'running', 'completed', 'error', 'cancelled', 'unknown']);
  const FAVORITES = Object.freeze(['favorite', 'unfavorite']);
  const MAX_GROUPS = 24;
  const GROUP_NAME_LIMIT = 60;
  const PAGE_SIZE = 24;
  const MAX_PAGE_SIZE = 100;
  const MAX_OFFSET = 1000000;
  const IMAGE_PATH = '/api/rpg/image';
  const THUMBNAIL_CONCURRENCY = 4;
  const THUMBNAIL_CACHE_SIZE = 96;

  function thumbnailPath(value, baseOrigin) {
    const path = safeLibraryImagePath(value, baseOrigin);
    if (!path) return '';
    const parsed = new URL(path, baseOrigin || global.location?.origin || 'http://localhost');
    parsed.searchParams.set('preview', '1');
    return parsed.pathname + parsed.search;
  }

  function pageOffset(value, total, size = PAGE_SIZE) {
    const text = asText(value);
    const pages = Math.max(1, Math.ceil(total / size));
    if (!/^\d+$/u.test(text) || !Number.isSafeInteger(Number(text)) || Number(text) < 1 || Number(text) > pages) return null;
    return (Number(text) - 1) * size;
  }

  function asText(value) {
    return value == null ? '' : String(value).trim();
  }

  function clampInteger(value, fallback, minimum, maximum) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(maximum, Math.max(minimum, Math.round(parsed)));
  }

  function oneOf(value, values) {
    const normalized = asText(value).toLowerCase();
    return values.includes(normalized) ? normalized : '';
  }

  function buildListQuery(options) {
    const input = options && typeof options === 'object' ? options : {};
    const params = new URLSearchParams();
    params.set('limit', String(clampInteger(input.limit, PAGE_SIZE, 1, MAX_PAGE_SIZE)));
    params.set('offset', String(clampInteger(input.offset, 0, 0, MAX_OFFSET)));
    const operation = oneOf(input.operation, OPERATIONS);
    const status = oneOf(input.status, STATUSES);
    if (operation) params.set('operation', operation);
    if (status) params.set('status', status);
    const model = asText(input.model).slice(0, 200);
    if (model) params.set('model', model);
    const favorite = oneOf(input.favorite, FAVORITES);
    if (favorite) params.set('favorite', favorite);
    const group = asText(input.group);
    if (group === 'ungrouped') params.set('group', 'ungrouped');
    else if (/^[0-9a-f]{32}$/u.test(group.toLowerCase())) params.set('group', group.toLowerCase());
    const sort = oneOf(input.sort, ['created_at', 'updated_at', 'status', 'operation', 'model']);
    const order = oneOf(input.order, ['asc', 'desc']);
    if (sort) params.set('sort', sort);
    if (order) params.set('order', order);
    return params.toString();
  }

  function safeGenerationId(value) {
    const id = asText(value).toLowerCase();
    if (!/^[0-9a-f]{32}$/u.test(id)) throw new Error('作品编号无效。');
    return id;
  }

  function originFor(value) {
    try {
      return new URL(value || 'http://localhost', 'http://localhost').origin;
    } catch (_) {
      return 'http://localhost';
    }
  }

  function safeLibraryImagePath(value, baseOrigin) {
    const raw = asText(value);
    if (!raw) return '';
    try {
      const base = baseOrigin || (global.location && global.location.origin) || 'http://localhost';
      const parsed = new URL(raw, base);
      if (parsed.origin !== originFor(base) || parsed.pathname !== IMAGE_PATH) return '';
      return parsed.pathname + parsed.search;
    } catch (_) {
      return '';
    }
  }

  function safeOutputFilename(value) {
    const name = asText(value).replace(/\\/gu, '/');
    if (!name || name === '.' || name === '..' || name.includes('/') || name.includes('\u0000')) return '';
    if (name.includes('..')) return '';
    return name.slice(0, 512);
  }

  function safeOutputSubfolder(value) {
    const folder = asText(value).replace(/\\/gu, '/').replace(/^\/+|\/+$/gu, '');
    if (!folder) return '';
    const parts = folder.split('/');
    if (parts.some((part) => !part || part === '.' || part === '..' || part.includes('\u0000'))) return '';
    return parts.join('/').slice(0, 512);
  }

  function artifactPath(artifact, baseOrigin) {
    const supplied = safeLibraryImagePath(artifact && artifact.url, baseOrigin);
    if (supplied) return supplied;
    const filename = safeOutputFilename(artifact && artifact.filename);
    if (!filename) return '';
    const params = new URLSearchParams({
      name: filename,
      type: asText(artifact && (artifact.type || artifact.image_type)) || 'output',
    });
    const subfolder = safeOutputSubfolder(artifact && artifact.subfolder);
    if (subfolder) params.set('subfolder', subfolder);
    return IMAGE_PATH + '?' + params.toString();
  }

  function cloneObject(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    try {
      const cloned = JSON.parse(JSON.stringify(value));
      return cloned && typeof cloned === 'object' && !Array.isArray(cloned) ? cloned : {};
    } catch (_) {
      return {};
    }
  }

  function payloadFromDetail(detail) {
    if (!detail || typeof detail !== 'object') return {};
    const snapshot = detail.snapshot && typeof detail.snapshot === 'object' && !Array.isArray(detail.snapshot)
      ? detail.snapshot : {};
    const replay = detail.replay && typeof detail.replay === 'object' && !Array.isArray(detail.replay)
      ? detail.replay : {};
    const candidate = snapshot.payload && typeof snapshot.payload === 'object' && !Array.isArray(snapshot.payload)
      ? snapshot.payload
      : replay.payload && typeof replay.payload === 'object' && !Array.isArray(replay.payload)
        ? replay.payload
        : detail.input;
    return cloneObject(candidate);
  }

  function nextSeed(value) {
    const previous = asText(value);
    if (/^\d+$/u.test(previous)) {
      try {
        const next = BigInt(previous) + 1n;
        const maximum = 9223372036854775807n;
        return String(next > maximum ? 1n : next);
      } catch (_) {
        // Fall through to a bounded random seed if the host lacks BigInt.
      }
    }
    return String(Math.floor(Math.random() * 900000000000000000) + 1);
  }

  function restorePayloadForForm(detail, mode) {
    const payload = payloadFromDetail(detail);
    if (mode === 'seed-variant') {
      payload.seed = nextSeed(payload.seed == null ? detail && detail.seed : payload.seed);
    }
    return payload;
  }

  function derivationOperationForRestore(detail, mode) {
    if (mode === 'seed-variant') return 'seed_variant';
    const source = oneOf(detail && detail.operation, OPERATIONS);
    // Restore currently fills the existing form only.  It does not select a
    // concrete output as an img2img/inpaint/repair input, so keep the
    // recorded operation instead of claiming an edit input that was not used.
    return source && source !== 'unknown' ? source : 'txt2img';
  }

  function pendingDerivationContextForDetail(detail, mode) {
    if (!detail || typeof detail !== 'object') return null;
    let parentGenerationId;
    try { parentGenerationId = safeGenerationId(detail.generation_id); } catch (_) { return null; }
    return {
      parentGenerationId,
      operation: derivationOperationForRestore(detail, mode),
    };
  }

  function attachPendingDerivationToPayload(payload, context) {
    const result = cloneObject(payload);
    if (!context || typeof context !== 'object') return result;
    let parentGenerationId;
    try { parentGenerationId = safeGenerationId(context.parentGenerationId); } catch (_) { return result; }
    const operation = oneOf(context.operation, OPERATIONS);
    if (!operation) return result;
    result.parentGenerationId = parentGenerationId;
    if (context.parentArtifactId) {
      try { result.parentArtifactId = safeGenerationId(context.parentArtifactId); } catch (_) {}
    }
    result.operation = operation;
    return result;
  }

  function errorStatus(error) {
    return Number(error && (error.status || error.code)) || 0;
  }

  function libraryErrorMessage(error, action) {
    const status = errorStatus(error);
    if (status === 404) return '当前电脑端版本不支持作品库，现有生成面板仍可继续使用。';
    if (status === 401 || status === 403) return `${action || '读取作品库'}访问凭据已失效，请刷新面板后重试。`;
    if (status === 503) return '电脑端尚未配置 RPG Token；请先检查 Easy Panel 启动配置。';
    if (error && error.name === 'AbortError') return `${action || '读取作品库'}已取消。`;
    if (error && error.message) return `${action || '读取作品库'}失败：${error.message}`;
    return `${action || '读取作品库'}失败，请检查电脑端服务和网络。`;
  }

  async function requestJson(path, token, fetchImpl) {
    const fetcher = fetchImpl || global.fetch;
    if (typeof fetcher !== 'function') throw new Error('当前浏览器不支持网络请求。');
    const headers = {};
    if (asText(token)) headers['X-RPG-Token'] = asText(token);
    const response = await fetcher(path, { method: 'GET', credentials: 'same-origin', headers });
    let data = {};
    try { data = await response.json(); } catch (_) { data = {}; }
    if (!response.ok) {
      const error = new Error(asText(data && data.error) || `HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function postJson(path, token, body, fetchImpl) {
    const fetcher = fetchImpl || global.fetch;
    if (typeof fetcher !== 'function') throw new Error('当前浏览器不支持网络请求。');
    const headers = { 'Content-Type': 'application/json' };
    if (asText(token)) headers['X-RPG-Token'] = asText(token);
    const response = await fetcher(path, {
      method: 'POST',
      credentials: 'same-origin',
      headers,
      body: JSON.stringify(body || {}),
    });
    let data = {};
    try { data = await response.json(); } catch (_) { data = {}; }
    if (!response.ok) {
      const error = new Error(asText(data && data.error) || `HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function requestBlob(path, token, fetchImpl, signal) {
    const fetcher = fetchImpl || global.fetch;
    if (typeof fetcher !== 'function') throw new Error('当前浏览器不支持网络请求。');
    const headers = {};
    if (asText(token)) headers['X-RPG-Token'] = asText(token);
    const response = await fetcher(path, { method: 'GET', credentials: 'same-origin', headers, ...(signal ? { signal } : {}) });
    if (!response.ok) {
      const error = new Error(`HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return response.blob();
  }

  const testApi = {
    OPERATIONS,
    STATUSES,
    artifactPath,
    buildListQuery,
    clampInteger,
    errorStatus,
    libraryErrorMessage,
    nextSeed,
    payloadFromDetail,
    attachPendingDerivationToPayload,
    derivationOperationForRestore,
    requestBlob,
    requestJson,
    pendingDerivationContextForDetail,
    restorePayloadForForm,
    safeGenerationId,
    safeLibraryImagePath,
    safeOutputFilename,
    safeOutputSubfolder,
    groupLabel,
    groupsOf,
    thumbnailPath,
    pageOffset,
  };

  global.EasyPanelCreativeLibrary = testApi;
  if (typeof module !== 'undefined' && module.exports) module.exports = testApi;

  if (!global.document) return;

  const state = {
    token: '',
    offset: 0,
    total: 0,
    hasMore: false,
    items: [],
    detail: null,
    lineage: null,
    loading: false,
    requestNumber: 0,
    galleryNumber: 0,
    imageUrls: new Map(),
    thumbnailTargets: new Map(),
    thumbnailObserver: null,
    thumbnailControllers: new Set(),
    thumbnailPaths: new Map(),
    lastFocus: null,
    listScrollTop: 0,
    groups: [],
    filters: {
      operation: '', status: '', favorite: '', group: '', model: '', sort: 'created_at', order: 'desc',
    },
  };

  function byId(id) {
    return global.document.getElementById(id);
  }

  function setText(id, value) {
    const node = byId(id);
    if (node) node.textContent = asText(value);
    return node;
  }

  function createElement(tag, className, text) {
    const node = global.document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = asText(text);
    return node;
  }

  function operationLabel(value) {
    return {
      txt2img: '文生图', seed_variant: '换 Seed', img2img: '图生图', inpaint: '局部重绘',
      face_fix: '修脸', hand_fix: '修手', upscale: '放大', outfit_change: '换服装',
      scene_change: '换场景', style_change: '换风格', section_change: '分区替换', flux_edit: 'FLUX 修图', unknown: '未知操作',
    }[asText(value)] || '未知操作';
  }

  function statusLabel(value) {
    return {
      queued: '排队中', running: '生成中', completed: '已完成', error: '失败',
      cancelled: '已取消', unknown: '未知状态',
    }[asText(value)] || '状态未知';
  }

  function formatTime(value) {
    const number = Number(value);
    if (!Number.isFinite(number) || number <= 0) return '未知时间';
    try { return new Date(number).toLocaleString(); } catch (_) { return '未知时间'; }
  }

  function imageKeyForThumbnail(id) {
    return `thumb:${id}`;
  }

  function imageKeyForArtifact(id) {
    return `artifact:${id}`;
  }

  function canCreateObjectUrl() {
    return typeof global.URL !== 'undefined' && typeof global.URL.createObjectURL === 'function';
  }

  function stopThumbnails() {
    state.thumbnailObserver?.disconnect();
    state.thumbnailObserver = null;
    state.thumbnailControllers.forEach((controller) => controller.abort());
    state.thumbnailControllers.clear();
  }

  function clearImageUrls(keepThumbnails = false) {
    if (global.URL && typeof global.URL.revokeObjectURL === 'function') {
      state.imageUrls.forEach((url, key) => {
        if (keepThumbnails && key.startsWith('thumb:')) return;
        global.URL.revokeObjectURL(url);
        state.imageUrls.delete(key);
        state.thumbnailPaths.delete(key);
      });
    }
    if (!keepThumbnails) {
      state.imageUrls.clear();
      state.thumbnailPaths.clear();
    }
  }

  function showNotice(message, kind) {
    const node = byId('creativeLibraryNotice');
    if (!node) return;
    node.textContent = asText(message);
    node.className = `creative-library-notice${kind ? ` ${kind}` : ''}`;
  }

  function indexReportText(report) {
    if (!report || typeof report !== 'object') return '（没有拿到检查结果）';
    return [
      `✓ 作品记录：${Number(report.generations || 0)} 条（其中导入 ${Number(report.imported_generations || 0)} 条）`,
      `✓ 缺失图片：${Number(report.missing_artifacts || 0)} 条`,
      `⏳ 待落盘：${Number(report.pending_artifacts || 0)} 条（刚生成完、文件还在写盘）`,
      `⚠ 重复引用：${Number(report.duplicate_total || 0)} 组`,
      `🆕 未登记图片：${Number(report.orphan_total || 0)} 张`,
      report.truncated ? '（目录扫描已截断，只统计最近一批文件）' : '',
    ].filter(Boolean).join('\n');
  }

  function isPending(item) {
    return asText(item && item.file_state).toLowerCase() === 'pending'
      || Number(item && item.pending_artifacts) > 0;
  }

  function artifactStateText(artifact) {
    const metadata = artifact && typeof artifact.metadata === 'object' && artifact.metadata ? artifact.metadata : {};
    if (asText(metadata.file_state).toLowerCase() === 'pending') return '⏳ 文件保存中';
    if (artifact && artifact.exists === false) return '文件缺失';
    return '';
  }

  function showListView() {
    const list = byId('creativeLibraryListView');
    const detail = byId('creativeLibraryDetailView');
    if (list) list.hidden = false;
    if (detail) detail.hidden = true;
  }

  function showDetailView() {
    const list = byId('creativeLibraryListView');
    const detail = byId('creativeLibraryDetailView');
    if (list) list.hidden = true;
    if (detail) detail.hidden = false;
  }

  function appendMeta(parent, label, value) {
    const row = createElement('div', 'creative-library-meta-row');
    row.append(createElement('span', 'creative-library-meta-label', label));
    row.append(createElement('span', 'creative-library-meta-value', value || '—'));
    parent.append(row);
  }

  function appendLineageMarker(parent, item) {
    const markers = [];
    if (Number(item && item.parent_count) > 0) markers.push(`父 ${Number(item.parent_count)}`);
    if (Number(item && item.child_count) > 0) markers.push(`子 ${Number(item.child_count)}`);
    parent.append(createElement('span', 'creative-library-marker', markers.length ? markers.join(' / ') : '无父子记录'));
  }

  function appendThumbnail(parent, item) {
    state.thumbnailTargets.set(item.generation_id, parent);
    parent.replaceChildren();
    const source = state.imageUrls.get(imageKeyForThumbnail(item.generation_id));
    if (source) {
      const image = createElement('img');
      image.src = source;
      image.alt = `${asText(item.model) || '作品'} 缩略图`;
      image.loading = 'lazy';
      image.decoding = 'async';
      image.width = 78;
      image.height = 92;
      parent.append(image);
    } else {
      parent.append(createElement('span', 'creative-library-thumb-placeholder',
        isPending(item) ? '⏳ 保存中' : '作品'));
    }
  }

  function renderList() {
    const root = byId('creativeLibraryList');
    if (!root) return;
    root.replaceChildren();
    state.thumbnailTargets.clear();
    if (state.loading) {
      root.append(createElement('p', 'creative-library-loading', '正在读取作品库…'));
      return;
    }
    if (!state.items.length) {
      root.append(createElement('div', 'creative-library-empty', '暂无符合条件的作品记录。'));
      return;
    }
    state.items.forEach((item) => {
      const wrap = createElement('div', 'creative-library-item-wrap');
      const button = createElement('button', 'creative-library-item');
      button.type = 'button';
      button.dataset.generationId = safeGenerationId(item.generation_id);
      button.addEventListener('click', () => { void openDetail(button.dataset.generationId); });
      const thumb = createElement('span', 'creative-library-thumb');
      appendThumbnail(thumb, item);
      const copy = createElement('span', 'creative-library-item-copy');
      const heading = createElement('span', 'creative-library-item-heading');
      heading.append(createElement('strong', '', asText(item.model) || '自动模型'));
      heading.append(createElement('small', '', formatTime(item.created_at)));
      if (item.favorite) heading.append(createElement('span', 'creative-library-star-mark', '★ 入选'));
      if (isPending(item)) heading.append(createElement('span', 'creative-library-pending-mark', '⏳ 文件保存中'));
      const operation = createElement('span', 'creative-library-item-operation', `${operationLabel(item.operation)} · ${statusLabel(item.status)}`);
      const details = createElement('span', 'creative-library-item-details', `seed ${item.seed == null ? '?' : item.seed} · ${item.width || '?'}×${item.height || '?'}`);
      const markers = createElement('span', 'creative-library-item-markers');
      appendLineageMarker(markers, item);
      const itemGroups = groupsOf(item);
      if (itemGroups.length) {
        const chips = createElement('span', 'creative-library-group-chips');
        itemGroups.slice(0, 4).forEach((group) => {
          chips.append(createElement('span', 'creative-library-group-chip', groupLabel(group) || '未命名组'));
        });
        if (itemGroups.length > 4) chips.append(createElement('small', '', `+${itemGroups.length - 4}`));
        markers.append(chips);
      }
      copy.append(heading, operation, details, markers);
      button.append(thumb, copy);
      wrap.append(button);
      const star = createElement('button', 'creative-library-item-star', item.favorite ? '★' : '☆');
      star.type = 'button';
      star.title = item.favorite ? '取消入选标记' : '标记为入选（最佳版本）';
      star.setAttribute('aria-pressed', item.favorite ? 'true' : 'false');
      star.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        saveFlags(item.generation_id, { favorite: !item.favorite });
      });
      wrap.append(star);
      const remove = createElement('button', 'creative-library-item-delete', '删除');
      remove.type = 'button';
      remove.title = '删除记录与对应本地图片（需二次确认）';
      remove.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        deleteGeneration(item.generation_id);
      });
      wrap.append(remove);
      root.append(wrap);
    });
    if (state.thumbnailObserver) {
      state.thumbnailObserver.disconnect();
      state.thumbnailTargets.forEach((target, id) => {
        target.dataset.generationId = id;
        state.thumbnailObserver.observe(target);
      });
    }
  }

  function renderPagination() {
    const nav = byId('creativeLibraryPagination');
    const previous = byId('creativeLibraryPrevious');
    const next = byId('creativeLibraryNext');
    const pageInfo = byId('creativeLibraryPageInfo');
    const visible = state.total > 0 || state.offset > 0;
    if (nav) nav.hidden = !visible;
    if (previous) previous.disabled = state.offset <= 0 || state.loading;
    if (next) next.disabled = !state.hasMore || state.loading;
    const first = state.total ? state.offset + 1 : 0;
    const last = Math.min(state.total, state.offset + state.items.length);
    const pages = Math.max(1, Math.ceil(state.total / PAGE_SIZE));
    const page = Math.floor(state.offset / PAGE_SIZE) + 1;
    if (pageInfo) pageInfo.textContent = state.total ? `第 ${page} / ${pages} 页 · ${first}–${last} / ${state.total}` : '0 / 0';
    const input = byId('creativeLibraryPageNumber');
    if (input) {
      input.value = String(page);
      input.max = String(pages);
      input.disabled = state.loading || !state.total;
    }
    const jump = byId('creativeLibraryJumpButton');
    if (jump) jump.disabled = state.loading || !state.total;
  }

  function filterValues() {
    return {
      operation: byId('creativeLibraryOperation')?.value || '',
      status: byId('creativeLibraryStatus')?.value || '',
      favorite: byId('creativeLibraryFavorite')?.value || '',
      group: byId('creativeLibraryGroup')?.value || '',
      model: byId('creativeLibraryModel')?.value || '',
      sort: byId('creativeLibrarySort')?.value || 'created_at',
      order: byId('creativeLibraryOrder')?.value || 'desc',
    };
  }

  // 收藏组：只是用户自己的分类，不改动任何生成参数。
  function groupLabel(group) {
    return asText(group && group.name).slice(0, GROUP_NAME_LIMIT);
  }

  function groupsOf(item) {
    const list = item && Array.isArray(item.groups) ? item.groups : [];
    return list.filter((group) => group && /^[0-9a-f]{32}$/u.test(asText(group.group_id).toLowerCase()));
  }

  function renderGroupOptions(keepValue) {
    const select = byId('creativeLibraryGroup');
    if (!select) return;
    const wanted = keepValue !== undefined ? keepValue : select.value;
    select.replaceChildren();
    const all = createElement('option', '', '全部收藏组');
    all.value = '';
    select.append(all);
    const ungrouped = createElement('option', '', '未加入收藏组');
    ungrouped.value = 'ungrouped';
    select.append(ungrouped);
    state.groups.forEach((group) => {
      const option = createElement('option', '', `${groupLabel(group)}（${Number(group.item_count) || 0}）`);
      option.value = asText(group.group_id).toLowerCase();
      select.append(option);
    });
    select.value = [...select.options].some((option) => option.value === wanted) ? wanted : '';
  }

  function adoptGroups(data) {
    if (data && Array.isArray(data.groups)) {
      state.groups = data.groups
        .filter((group) => group && /^[0-9a-f]{32}$/u.test(asText(group.group_id).toLowerCase()))
        .slice(0, 200);
      renderGroupOptions();
    }
  }

  async function loadGroups() {
    try {
      const data = await requestJson('/api/rpg/library/groups', state.token);
      adoptGroups(data);
    } catch (_) {
      // 组列表读不到不影响作品库主体（筛选框保留“全部/未加入”两项）。
    }
  }

  function applyGroupsLocally(generationId, groups) {
    const merge = (item) => (item && item.generation_id === generationId ? { ...item, groups } : item);
    state.items = state.items.map(merge);
    if (state.detail && state.detail.generation_id === generationId) {
      state.detail = { ...state.detail, groups };
    }
  }

  function saveGroups(generationId, groupIds, options) {
    let id;
    try { id = safeGenerationId(generationId); } catch (error) { showNotice(error.message, 'error'); return; }
    const wanted = [...new Set((groupIds || []).map((value) => asText(value).toLowerCase())
      .filter((value) => /^[0-9a-f]{32}$/u.test(value)))].slice(0, MAX_GROUPS);
    const byId_ = new Map(state.groups.map((group) => [asText(group.group_id).toLowerCase(), group]));
    const optimistic = wanted.map((groupId) => ({ group_id: groupId, name: groupLabel(byId_.get(groupId)) }));
    applyGroupsLocally(id, optimistic);
    renderList();
    if (!options || options.rerender !== false) {
      if (state.detail) renderDetail();
    }
    (async () => {
      try {
        const data = await postJson('/api/rpg/library/favorite', state.token, { generation_id: id, groups: wanted });
        const updated = data && data.generation;
        if (updated && updated.generation_id) applyGroupsLocally(id, groupsOf(updated));
        adoptGroups(data);
        renderList();
        if (state.detail) renderDetail();
        showNotice(wanted.length ? `已保存该作品的收藏组（${wanted.length} 个）。` : '已移出全部收藏组。', 'success');
      } catch (error) {
        showNotice(libraryErrorMessage(error, '保存收藏组'), errorStatus(error) === 404 ? 'warning' : 'error');
      }
    })();
  }

  function manageGroup(action, payload, message) {
    (async () => {
      try {
        const data = await postJson('/api/rpg/library/groups', state.token, { action, ...payload });
        adoptGroups(data);
        if (message) showNotice(message, 'success');
        await loadList();
      } catch (error) {
        showNotice(libraryErrorMessage(error, '收藏组操作'), errorStatus(error) === 404 ? 'warning' : 'error');
      }
    })();
  }

  function createGroup(name, generationId) {
    const clean = asText(name).slice(0, GROUP_NAME_LIMIT);
    if (!clean) {
      showNotice('请先输入收藏组名称。', 'warning');
      return;
    }
    (async () => {
      try {
        const data = await postJson('/api/rpg/library/groups', state.token, { action: 'create', name: clean });
        adoptGroups(data);
        const created = data && data.result && data.result.group;
        const createdId = created ? asText(created.group_id).toLowerCase() : '';
        const duplicate = Boolean(data && data.result && data.result.created === false);
        showNotice(duplicate ? `收藏组「${clean}」已存在，已直接使用。` : `收藏组「${clean}」已创建。`, 'success');
        if (generationId && createdId && state.detail) {
          saveGroups(generationId, [...groupsOf(state.detail).map((item) => item.group_id), createdId]);
        } else {
          await loadList();
        }
      } catch (error) {
        showNotice(libraryErrorMessage(error, '新建收藏组'), errorStatus(error) === 404 ? 'warning' : 'error');
      }
    })();
  }

  function renameGroup(group, currentName) {
    const next = global.prompt('重命名收藏组', currentName || '');
    if (next === null) return;
    const clean = asText(next).slice(0, GROUP_NAME_LIMIT);
    if (!clean || clean === currentName) return;
    manageGroup('rename', { group_id: group, name: clean }, `收藏组已重命名为「${clean}」。`);
  }

  function deleteGroup(group, name) {
    if (!global.confirm(`确定删除收藏组「${name || ''}」吗？作品本身不会被删除，只会移出这个组。`)) return;
    if (currentGroupFilter() === asText(group).toLowerCase()) {
      const select = byId('creativeLibraryGroup');
      if (select) select.value = '';
      state.filters = { ...state.filters, group: '' };
      state.offset = 0;
    }
    manageGroup('delete', { group_id: group }, `收藏组「${name || ''}」已删除。`);
  }

  function currentGroupFilter() {
    return asText((state.filters && state.filters.group) || '').toLowerCase();
  }

  function favoriteFlags(item) {
    const source = item && typeof item === 'object' ? item : {};
    return {
      favorite: Boolean(source.favorite),
      rating: clampInteger(source.rating, 0, 0, 5),
      note: asText(source.note).slice(0, 2000),
    };
  }

  function isHiresBaseName(value) {
    const name = asText(value).replace(/\\/gu, '/').split('/').pop() || '';
    return name.includes('_base_');
  }

  // 列表缩略图（summary.primary_artifact_id）与详情大图必须是同一张：
  // 高清二采会同时产出首采图与成品，服务端已按“非首采的最后一张输出”选定代表图。
  function previewArtifactOf(detail) {
    const artifacts = detail && Array.isArray(detail.artifacts) ? detail.artifacts : [];
    const wanted = asText(detail && detail.preview && detail.preview.artifact_id).toLowerCase();
    if (wanted) {
      const matched = artifacts.find((item) => asText(item.artifact_id).toLowerCase() === wanted);
      if (matched) return matched;
    }
    const primary = asText(detail && detail.primary_artifact_id).toLowerCase();
    if (primary) {
      const matched = artifacts.find((item) => asText(item.artifact_id).toLowerCase() === primary);
      if (matched) return matched;
    }
    return artifacts.find((item) => item.exists !== false) || artifacts[0] || null;
  }

  function flagsPayload(patch) {
    const source = patch && typeof patch === 'object' ? patch : {};
    const body = {};
    if (Object.prototype.hasOwnProperty.call(source, 'favorite')) body.favorite = Boolean(source.favorite);
    if (Object.prototype.hasOwnProperty.call(source, 'rating')) body.rating = clampInteger(source.rating, 0, 0, 5);
    if (Object.prototype.hasOwnProperty.call(source, 'note')) body.note = asText(source.note).slice(0, 2000);
    return body;
  }

  function applyFlagsLocally(generationId, body) {
    const merge = (item) => (item && item.generation_id === generationId ? { ...item, ...body } : item);
    state.items = state.items.map(merge);
    if (state.detail && state.detail.generation_id === generationId) {
      state.detail = { ...state.detail, ...body };
    }
  }

  // 收藏 / 评分 / 备注只是人对作品的标记，不会改变任何生成参数，
  // 因此先把界面状态改好再同步到电脑端；失败时也只会影响这个标记本身。
  function saveFlags(generationId, patch, options) {
    let id;
    try { id = safeGenerationId(generationId); } catch (error) { showNotice(error.message, 'error'); return; }
    const body = flagsPayload(patch);
    if (!Object.keys(body).length) return;
    const rerender = !options || options.rerender !== false;
    applyFlagsLocally(id, body);
    renderList();
    if (rerender && state.detail) renderDetail();
    (async () => {
      try {
        const data = await postJson('/api/rpg/library/favorite', state.token, { generation_id: id, ...body });
        const updated = data && data.generation;
        adoptGroups(data);
        if (updated && updated.generation_id) applyFlagsLocally(id, favoriteFlags(updated));
        renderList();
        if (state.detail) renderDetail();
        if (Object.prototype.hasOwnProperty.call(body, 'favorite')) {
          showNotice(body.favorite ? '已标记为入选（最佳版本）。' : '已取消入选标记。', 'success');
        } else if (Object.prototype.hasOwnProperty.call(body, 'rating')) {
          showNotice('评分已保存。', 'success');
        } else {
          showNotice('备注已保存。', 'success');
        }
      } catch (error) {
        showNotice(libraryErrorMessage(error, '保存收藏标记'), errorStatus(error) === 404 ? 'warning' : 'error');
      }
    })();
  }

  function detailFromResponse(data) {
    return data && data.generation && typeof data.generation === 'object' && !Array.isArray(data.generation)
      ? data.generation : null;
  }

  function lineageFromResponse(data) {
    return data && data.lineage && typeof data.lineage === 'object' && !Array.isArray(data.lineage)
      ? data.lineage : null;
  }

  async function loadImage(path, key, requestNumber) {
    if (!canCreateObjectUrl()) return;
    const safePath = key.startsWith('thumb:') ? thumbnailPath(path) : safeLibraryImagePath(path);
    if (!safePath) return;
    if (state.imageUrls.has(key) && state.thumbnailPaths.get(key) === safePath) return;
    try {
      const blob = await requestBlob(safePath, state.token);
      if (requestNumber !== state.requestNumber) return;
      const source = global.URL.createObjectURL(blob);
      const previous = state.imageUrls.get(key);
      if (previous && global.URL.revokeObjectURL) global.URL.revokeObjectURL(previous);
      state.imageUrls.set(key, source);
      if (key.startsWith('thumb:')) state.thumbnailPaths.set(key, safePath);
    } catch (_) {
      // A missing output should leave a usable metadata-only card.
    }
  }

  function loadListThumbnails(items, requestNumber) {
    if (!canCreateObjectUrl()) return;
    stopThumbnails();
    const queue = [], queued = new Set();
    let active = 0;
    const pump = () => {
      while (requestNumber === state.requestNumber && active < THUMBNAIL_CONCURRENCY && queue.length) {
        const item = queue.shift();
        const key = imageKeyForThumbnail(item.generation_id);
        const path = thumbnailPath(item.thumbnail_url);
        if (!path) continue;
        const controller = typeof global.AbortController === 'function' ? new global.AbortController() : null;
        if (controller) state.thumbnailControllers.add(controller);
        active++;
        void requestBlob(path, state.token, undefined, controller?.signal).then((blob) => {
          if (requestNumber !== state.requestNumber || controller?.signal.aborted) return;
          const previous = state.imageUrls.get(key);
          if (previous) global.URL.revokeObjectURL(previous);
          state.imageUrls.delete(key);
          state.imageUrls.set(key, global.URL.createObjectURL(blob));
          state.thumbnailPaths.set(key, path);
          const target = state.thumbnailTargets.get(item.generation_id);
          if (target) appendThumbnail(target, item);
          const thumbs = [...state.imageUrls.keys()].filter((entry) => entry.startsWith('thumb:'));
          for (const stale of thumbs.slice(0, Math.max(0, thumbs.length - THUMBNAIL_CACHE_SIZE))) {
            global.URL.revokeObjectURL(state.imageUrls.get(stale));
            state.imageUrls.delete(stale);
            state.thumbnailPaths.delete(stale);
          }
        }).catch(() => {}).finally(() => {
          if (controller) state.thumbnailControllers.delete(controller);
          active--;
          pump();
        });
      }
    };
    const enqueue = (item) => {
      const key = imageKeyForThumbnail(item.generation_id);
      if (queued.has(key)) return;
      const path = thumbnailPath(item.thumbnail_url);
      if (!path) return;
      if (state.imageUrls.has(key) && state.thumbnailPaths.get(key) === path) {
        const cached = state.imageUrls.get(key);
        state.imageUrls.delete(key);
        state.imageUrls.set(key, cached);
        return;
      }
      queued.add(key);
      queue.push(item);
      pump();
    };
    if (typeof global.IntersectionObserver === 'function') {
      const byIdMap = new Map(items.map((item) => [item.generation_id, item]));
      state.thumbnailObserver = new global.IntersectionObserver((entries) => {
        if (requestNumber !== state.requestNumber) return;
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const item = byIdMap.get(entry.target.dataset.generationId);
          if (item) enqueue(item);
          state.thumbnailObserver?.unobserve(entry.target);
        }
      }, { root: byId('creativeLibraryListView'), rootMargin: '180px 0px' });
      for (const item of items) {
        const target = state.thumbnailTargets.get(item.generation_id);
        if (target) {
          target.dataset.generationId = item.generation_id;
          state.thumbnailObserver.observe(target);
        }
      }
    } else items.forEach(enqueue);
  }

  function responseItems(data) {
    if (!data || !Array.isArray(data.items)) return [];
    return data.items.filter((item) => {
      try { safeGenerationId(item && item.generation_id); return true; } catch (_) { return false; }
    });
  }

  async function loadList() {
    const requestNumber = ++state.requestNumber;
    stopThumbnails();
    state.loading = true;
    state.detail = null;
    state.lineage = null;
    showListView();
    showNotice('正在读取电脑端作品库…');
    renderList();
    renderPagination();
    clearImageUrls(true);
    try {
      const query = buildListQuery({ ...state.filters, limit: PAGE_SIZE, offset: state.offset });
      const data = await requestJson(`/api/rpg/library/generations?${query}`, state.token);
      if (requestNumber !== state.requestNumber) return;
      adoptGroups(data);
      state.items = responseItems(data);
      state.total = clampInteger(data && data.total, state.items.length, 0, MAX_OFFSET);
      if (!state.items.length && state.offset > 0 && state.total > 0) {
        const lastOffset = (Math.ceil(state.total / PAGE_SIZE) - 1) * PAGE_SIZE;
        if (lastOffset !== state.offset) {
          state.offset = lastOffset;
          return loadList();
        }
      }
      state.hasMore = Boolean(data && data.has_more);
      state.loading = false;
      showNotice(state.items.length ? `已读取 ${state.items.length} 条作品。` : '电脑端暂无符合条件的作品。', 'success');
      renderList();
      renderPagination();
      void loadListThumbnails(state.items, requestNumber);
    } catch (error) {
      if (requestNumber !== state.requestNumber) return;
      state.loading = false;
      state.items = [];
      state.total = 0;
      state.hasMore = false;
      showNotice(libraryErrorMessage(error, '读取作品库'), errorStatus(error) === 404 ? 'warning' : 'error');
      renderList();
      renderPagination();
    }
  }

  function libraryGalleryEntries(detail, selectedArtifact) {
    const entries = [];
    const currentId = detail.generation_id;
    const summaries = state.items.some((item) => item.generation_id === currentId)
      ? state.items : [{ generation_id: currentId, model: detail.model }, ...state.items];
    summaries.forEach((item) => {
      if (item.generation_id === currentId) {
        (detail.artifacts || []).filter((artifact) => artifact.exists !== false).forEach((artifact) => {
          const src = state.imageUrls.get(imageKeyForArtifact(artifact.artifact_id)) ||
            (artifact.artifact_id === selectedArtifact?.artifact_id && state.imageUrls.get(imageKeyForThumbnail(currentId)));
          if (src) entries.push({ generationId: currentId, artifact, src, name: artifact.filename || detail.model || '作品图片' });
        });
      } else {
        const src = state.imageUrls.get(imageKeyForThumbnail(item.generation_id));
        if (src) entries.push({ generationId: item.generation_id, src, name: item.model || '作品图片' });
      }
    });
    const index = Math.max(0, entries.findIndex((entry) => entry.artifact?.artifact_id === selectedArtifact?.artifact_id));
    return { entries, index };
  }

  function openLibraryGallery(event, artifact) {
    const detail = state.detail;
    if (!detail || typeof global.openPanelImageGallery !== 'function') return true;
    const { entries, index } = libraryGalleryEntries(detail, artifact);
    if (!entries.length) return true;
    const images = entries.map((entry) => ({ src: entry.src, name: entry.name, label: entry.name }));
    const requestNumber = state.requestNumber;
    const galleryNumber = ++state.galleryNumber;
    let currentPosition = index;
    const onChange = async (position) => {
      currentPosition = position;
      const entry = entries[position];
      if (!entry || entry.artifact || entry.loading) return;
      entry.loading = true;
      try {
        const data = await requestJson(`/api/rpg/library/generations/${safeGenerationId(entry.generationId)}`, state.token);
        const other = detailFromResponse(data);
        const preview = previewArtifactOf(other);
        const path = preview && artifactPath(preview);
        if (!path) return;
        const blob = await requestBlob(path, state.token);
        if (requestNumber !== state.requestNumber || galleryNumber !== state.galleryNumber || !byId('panelImageViewer')?.open) return;
        const src = global.URL.createObjectURL(blob);
        const key = imageKeyForArtifact(preview.artifact_id);
        const previous = state.imageUrls.get(key);
        if (previous) global.URL.revokeObjectURL(previous);
        state.imageUrls.set(key, src);
        entry.artifact = preview;
        entry.src = src;
        entry.name = preview.filename || entry.name;
        global.updatePanelImageGallery?.(position, { src, name: entry.name, label: entry.name });
      } catch (_) {
        // Keep the thumbnail available if the full image cannot be loaded.
      } finally { entry.loading = false; }
    };
    const opened = global.openPanelImageGallery(event, images, index, onChange);
    if (opened === false) byId('panelImageViewer')?.addEventListener('close', () => {
      const current = entries[currentPosition];
      if (byId('creativeLibraryDialog')?.open && current && current.generationId !== state.detail?.generation_id) {
        void openDetail(current.generationId);
      }
    }, { once: true });
    return opened;
  }

  function appendSafeImageLink(parent, source, label, className, artifact) {
    if (!source) return null;
    const link = createElement('a', className || 'creative-library-image-link', label);
    link.href = source;
    link.target = '_blank';
    link.rel = 'noreferrer';
    link.addEventListener('click', (event) => {
      if (state.detail && artifact && openLibraryGallery(event, artifact) === false) return;
      const viewer = global.openLinkedImageViewer;
      if (typeof viewer === 'function') {
        const result = viewer(event, link);
        if (result === false) return;
      }
    });
    parent.append(link);
    return link;
  }

  function appendOutputSection(parent, detail) {
    const section = createElement('section', 'creative-library-detail-section');
    section.append(createElement('h3', '', '输出文件'));
    const outputs = Array.isArray(detail.artifacts) ? detail.artifacts : [];
    if (!outputs.length) {
      section.append(createElement('p', 'creative-library-muted', '暂无可用输出；缺失文件只显示记录，不会被提供，也不会改写源记录。'));
      parent.append(section);
      return;
    }
    const list = createElement('div', 'creative-library-output-list');
    outputs.forEach((artifact) => {
      const row = createElement('div', 'creative-library-output-row');
      const source = state.imageUrls.get(imageKeyForArtifact(artifact.artifact_id));
      const base = isHiresBaseName(artifact.filename) ? '（首采对照，非成品）' : '';
      const stateText = artifactStateText(artifact);
      const filename = `${asText(artifact.filename) || '未命名图片'}${base}${stateText ? `（${stateText}）` : ''}`;
      const name = createElement('span', 'creative-library-output-name', filename);
      row.append(name);
      if (source) appendSafeImageLink(row, source, '打开预览', 'creative-library-image-link snapshot-output', artifact);
      const download = createElement('button', 'secondary', '下载');
      download.type = 'button';
      download.disabled = !source || artifact.exists === false;
      download.addEventListener('click', () => { void downloadArtifact(artifact); });
      row.append(download);
      list.append(row);
    });
    section.append(list);
    parent.append(section);
  }

  function appendLineageSection(parent, detail, lineage) {
    const section = createElement('section', 'creative-library-detail-section');
    section.append(createElement('h3', '', '父 / 子谱系'));
    const summary = `父作品 ${Number(detail.parent_count) || 0} · 子作品 ${Number(detail.child_count) || 0}`;
    section.append(createElement('p', 'creative-library-muted', summary));
    const nodes = [];
    if (lineage && Array.isArray(lineage.ancestors)) {
      lineage.ancestors.forEach((item) => nodes.push(['父', item]));
    }
    if (lineage && Array.isArray(lineage.descendants)) {
      lineage.descendants.forEach((item) => nodes.push(['子', item]));
    }
    if (!nodes.length) {
      section.append(createElement('p', 'creative-library-muted', lineage ? '暂无已索引的父子作品。' : '当前服务端未提供谱系信息。'));
    } else {
      const list = createElement('div', 'creative-library-lineage-list');
      nodes.forEach(([kind, item]) => {
        const id = asText(item && item.generation_id);
        const label = `${kind} · ${id.slice(0, 12)}${id ? '…' : ''} · ${operationLabel(item && item.operation)} · ${asText(item && item.model) || '自动模型'}`;
        list.append(createElement('span', '', label));
      });
      section.append(list);
    }
    parent.append(section);
  }

  function appendLoraSection(parent, detail) {
    const section = createElement('section', 'creative-library-detail-section');
    section.append(createElement('h3', '', 'LoRA'));
    const loras = Array.isArray(detail.loras) ? detail.loras : [];
    if (!loras.length) section.append(createElement('p', 'creative-library-muted', '本次记录没有 LoRA。'));
    else {
      const list = createElement('div', 'creative-library-lora-list');
      loras.forEach((lora) => {
        const weight = lora.weight == null ? '' : ` × ${lora.weight}`;
        const role = asText(lora.role) && asText(lora.role) !== 'other' ? ` · ${lora.role}` : '';
        list.append(createElement('span', '', `${asText(lora.name) || '未命名 LoRA'}${weight}${role}`));
      });
      section.append(list);
    }
    parent.append(section);
  }

  function promptValue(detail) {
    const replay = detail && detail.replay && typeof detail.replay.payload === 'object' ? detail.replay.payload : {};
    const input = detail && detail.input && typeof detail.input === 'object' ? detail.input : {};
    const value = replay.prompt || replay.positive || input.prompt || input.positive;
    if (value) return value;
    const sections = replay.promptSections || input.promptSections;
    if (!sections || typeof sections !== 'object' || Array.isArray(sections)) return '（没有记录提示词）';
    return Object.values(sections).filter((item) => asText(item)).map((item) => asText(item)).join(', ') || '（没有记录提示词）';
  }

  function appendPromptSection(parent, detail) {
    const section = createElement('section', 'creative-library-detail-section');
    section.append(createElement('h3', '', '提示词预览'));
    section.append(createElement('pre', 'creative-library-prompt', promptValue(detail)));
    section.append(createElement('p', 'creative-library-muted', '只读预览；恢复操作只填入当前表单。'));
    parent.append(section);
  }

  function appendGroupSection(parent, detail) {
    const section = createElement('section', 'creative-library-detail-section creative-library-group-section');
    section.append(createElement('h3', '', '收藏组'));
    section.append(createElement('p', 'small creative-library-muted',
      '用自己命名的收藏组给作品分类（例如「成图候选」「需要修手」「参考姿势」）；一张图可以同时加入多个组，勾选后立即同步到电脑端与手机端，不会改变任何生成参数。'));
    const assigned = new Set(groupsOf(detail).map((group) => asText(group.group_id).toLowerCase()));
    const list = createElement('div', 'creative-library-group-list');
    if (!state.groups.length) {
      list.append(createElement('p', 'small', '还没有收藏组：在下面输入名称新建第一个。'));
    }
    state.groups.forEach((group) => {
      const groupId = asText(group.group_id).toLowerCase();
      const row = createElement('label', 'creative-library-group-row');
      const box = createElement('input');
      box.type = 'checkbox';
      box.checked = assigned.has(groupId);
      box.addEventListener('change', () => {
        const next = new Set(assigned);
        if (box.checked) next.add(groupId);
        else next.delete(groupId);
        saveGroups(detail.generation_id, [...next]);
      });
      const name = createElement('span', '', `${groupLabel(group) || '未命名组'}（${Number(group.item_count) || 0}）`);
      const rename = createElement('button', 'secondary creative-library-group-action', '✎');
      rename.type = 'button';
      rename.title = '重命名这个收藏组';
      rename.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        renameGroup(groupId, groupLabel(group));
      });
      const remove = createElement('button', 'danger creative-library-group-action', '✕');
      remove.type = 'button';
      remove.title = '删除这个收藏组（作品本身不会被删除）';
      remove.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        deleteGroup(groupId, groupLabel(group));
      });
      row.append(box, name, rename, remove);
      list.append(row);
    });
    section.append(list);
    const creator = createElement('div', 'creative-library-group-create');
    const input = createElement('input');
    input.type = 'text';
    input.maxLength = GROUP_NAME_LIMIT;
    input.placeholder = '新建收藏组名称，例如 成图候选';
    const add = createElement('button', 'secondary', '＋ 新建并加入');
    add.type = 'button';
    const submit = () => {
      const name = asText(input.value).slice(0, GROUP_NAME_LIMIT);
      if (!name) {
        showNotice('请先输入收藏组名称。', 'warning');
        return;
      }
      input.value = '';
      createGroup(name, detail.generation_id);
    };
    add.addEventListener('click', submit);
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        submit();
      }
    });
    creator.append(input, add);
    section.append(creator);
    parent.append(section);
  }

  function renderDetail() {
    const root = byId('creativeLibraryDetail');
    const detail = state.detail;
    if (!root || !detail) return;
    root.replaceChildren();
    const summary = createElement('div', 'creative-library-detail-summary');
    const preview = createElement('div', 'creative-library-detail-preview');
    const previewArtifact = previewArtifactOf(detail);
    const previewSource = previewArtifact && state.imageUrls.get(imageKeyForArtifact(previewArtifact.artifact_id));
    const thumbSource = state.imageUrls.get(imageKeyForThumbnail(detail.generation_id));
    const source = previewSource || thumbSource;
    if (source) {
      const link = appendSafeImageLink(preview, source, '打开大图', 'creative-library-preview-link snapshot-output', previewArtifact);
      const image = createElement('img');
      image.src = source;
      image.alt = `${asText(detail.model) || '作品'} 预览`;
      if (link) link.replaceChildren(image);
    } else preview.append(createElement('span', 'creative-library-thumb-placeholder',
      isPending(detail) ? '⏳ 文件保存中' : '暂无预览'));
    const copy = createElement('div', 'creative-library-detail-copy');
    copy.append(createElement('h3', '', asText(detail.model) || '自动模型'));
    appendMeta(copy, '操作 / 状态', `${operationLabel(detail.operation)} · ${statusLabel(detail.status)}`);
    appendMeta(copy, '时间', formatTime(detail.created_at));
    appendMeta(copy, 'Seed', detail.seed == null ? '?' : detail.seed);
    appendMeta(copy, '尺寸 / 质量', `${detail.width || '?'}×${detail.height || '?'} · ${asText(detail.quality) || '自定义'}`);
    appendMeta(copy, '作品 ID', detail.generation_id);
    const flags = favoriteFlags(detail);
    const favoriteRow = createElement('div', 'creative-library-flags');
    const favoriteButton = createElement(
      'button',
      flags.favorite ? 'primary creative-library-star' : 'secondary creative-library-star',
      flags.favorite ? '★ 已入选' : '☆ 设为入选',
    );
    favoriteButton.type = 'button';
    favoriteButton.setAttribute('aria-pressed', flags.favorite ? 'true' : 'false');
    favoriteButton.title = '入选标记只记录“这是当前最佳版本”，不会改变生成参数。';
    favoriteButton.addEventListener('click', () => saveFlags(detail.generation_id, { favorite: !flags.favorite }));
    const ratingLabel = createElement('label', 'creative-library-rating', '评分');
    const ratingSelect = createElement('select');
    [0, 1, 2, 3, 4, 5].forEach((value) => {
      const option = createElement('option', '', value ? '★'.repeat(value) : '未评分');
      option.value = String(value);
      if (flags.rating === value) option.selected = true;
      ratingSelect.append(option);
    });
    ratingSelect.addEventListener('change', () => saveFlags(detail.generation_id, { rating: Number(ratingSelect.value) }));
    ratingLabel.append(ratingSelect);
    const noteLabel = createElement('label', 'creative-library-note', '备注');
    const noteInput = createElement('input');
    noteInput.type = 'text';
    noteInput.maxLength = 200;
    noteInput.value = flags.note;
    noteInput.placeholder = '例如：构图最好 / 手部需要重绘';
    // 备注输入时不重建详情面板，避免光标丢失。
    noteInput.addEventListener('change', () => {
      saveFlags(detail.generation_id, { note: noteInput.value }, { rerender: false });
    });
    noteLabel.append(noteInput);
    favoriteRow.append(favoriteButton, ratingLabel, noteLabel);
    copy.append(favoriteRow);
    summary.append(preview, copy);
    root.append(summary);

    const actions = createElement('div', 'creative-library-actions');
    const reproduce = createElement('button', 'primary', '复现到当前表单');
    reproduce.type = 'button';
    reproduce.addEventListener('click', () => restoreToForm('reproduce'));
    const seedVariant = createElement('button', 'secondary', '换 Seed 到当前表单');
    seedVariant.type = 'button';
    seedVariant.addEventListener('click', () => restoreToForm('seed-variant'));
    const continueEdit = createElement('button', 'secondary', '继续编辑');
    continueEdit.type = 'button';
    continueEdit.addEventListener('click', () => restoreToForm('continue-edit'));
    const remove = createElement('button', 'danger', '删除此作品');
    remove.type = 'button';
    remove.title = '删除记录并删除电脑端对应的本地图片文件（需二次确认）';
    remove.addEventListener('click', () => { deleteGeneration(detail.generation_id); });
    const addToProject = createElement('button', 'secondary', '加入项目');
    addToProject.type = 'button';
    addToProject.title = '把这张图归入某个作品项目（角色图集 / 场景等）的分区';
    addToProject.addEventListener('click', () => {
      if (typeof global.openProjectPicker === 'function') global.openProjectPicker(detail.generation_id);
      else showNotice('项目功能尚未载入。', 'error');
    });
    const addToVisual = createElement('button', 'secondary', '加入可视化图库');
    addToVisual.type = 'button';
    addToVisual.disabled = !previewArtifact || previewArtifact.exists === false || !artifactPath(previewArtifact);
    addToVisual.addEventListener('click', () => {
      if (global.EasyPanelVisualTagEditor?.openFromGeneration) {
        global.EasyPanelVisualTagEditor.openFromGeneration(detail, previewArtifact);
      } else showNotice('图库添加功能尚未载入，请刷新页面。', 'error');
    });
    actions.append(reproduce, seedVariant, continueEdit, addToProject, addToVisual, remove);
    root.append(actions);
    root.append(createElement('p', 'creative-library-safe-note', '这些操作只恢复参数，不会自动提交任务；请确认后手动点击“生成图片”。'));
    appendGroupSection(root, detail);
    appendLineageSection(root, detail, state.lineage);
    appendLoraSection(root, detail);
    appendOutputSection(root, detail);
    appendPromptSection(root, detail);
  }

  async function loadDetailImages(detail, requestNumber) {
    const artifacts = Array.isArray(detail.artifacts) ? detail.artifacts : [];
    const jobs = [];
    const thumbnailPath = detail.thumbnail_url;
    if (thumbnailPath) jobs.push(loadImage(thumbnailPath, imageKeyForThumbnail(detail.generation_id), requestNumber));
    artifacts.forEach((artifact) => {
      if (artifact.exists === false) return;
      jobs.push(loadImage(artifactPath(artifact), imageKeyForArtifact(artifact.artifact_id), requestNumber));
    });
    await Promise.all(jobs);
    if (requestNumber === state.requestNumber) renderDetail();
  }

  async function openDetail(id) {
    let generationId;
    try { generationId = safeGenerationId(id); } catch (error) {
      showNotice(error.message, 'error');
      return;
    }
    const listView = byId('creativeLibraryListView');
    if (listView && !listView.hidden) state.listScrollTop = listView.scrollTop;
    const requestNumber = ++state.requestNumber;
    stopThumbnails();
    state.loading = true;
    state.detail = null;
    state.lineage = null;
    showDetailView();
    showNotice('正在读取作品详情…');
    setText('creativeLibraryDetailStatus', '读取中…');
    const root = byId('creativeLibraryDetail');
    if (root) root.replaceChildren(createElement('p', 'creative-library-loading', '正在读取作品详情…'));
    try {
      const data = await requestJson(`/api/rpg/library/generations/${generationId}`, state.token);
      if (requestNumber !== state.requestNumber) return;
      const detail = detailFromResponse(data);
      if (!detail) throw new Error('电脑端返回的作品详情格式无效。');
      state.detail = detail;
      state.loading = false;
      setText('creativeLibraryDetailStatus', `${operationLabel(detail.operation)} · ${statusLabel(detail.status)}`);
      showNotice('详情已加载；恢复后请确认参数，再手动生成。', 'success');
      renderDetail();
      try {
        const lineageData = await requestJson(`/api/rpg/library/generations/${generationId}/lineage`, state.token);
        if (requestNumber === state.requestNumber) state.lineage = lineageFromResponse(lineageData);
      } catch (lineageError) {
        if (requestNumber === state.requestNumber && errorStatus(lineageError) !== 401 && errorStatus(lineageError) !== 403) {
          state.lineage = null;
        }
      }
      if (requestNumber === state.requestNumber) renderDetail();
      await loadDetailImages(detail, requestNumber);
    } catch (error) {
      if (requestNumber !== state.requestNumber) return;
      state.loading = false;
      state.detail = null;
      state.lineage = null;
      setText('creativeLibraryDetailStatus', '读取失败');
      showNotice(libraryErrorMessage(error, '读取作品详情'), errorStatus(error) === 404 ? 'warning' : 'error');
      if (root) root.replaceChildren(createElement('p', 'creative-library-muted', '无法显示该作品详情；可以返回列表继续使用现有面板。'));
    }
  }

  function deleteGeneration(generationId) {
    let id;
    try { id = safeGenerationId(generationId); } catch (error) { showNotice(error.message, 'error'); return; }
    if (!global.confirm('确定删除该作品记录吗？删除会同时移除电脑端对应的本地图片文件，此操作无法撤销。')) return;
    (async () => {
      try {
        const result = await postJson('/api/rpg/library/delete', state.token, { generation_id: id });
        if (state.detail && state.detail.generation_id === id) {
          state.detail = null;
          state.lineage = null;
          showListView();
        }
        const removed = Number(result && result.removed_files && result.removed_files.length) || 0;
        const missing = Number(result && result.missing_files && result.missing_files.length) || 0;
        const hint = result && result.deleted === false
          ? '该记录已被其他会话清理；本地缺失文件数 ' + missing + ' 个。'
          : `已删除记录${removed ? `，并删除 ${removed} 个本地图片文件` : ''}${missing ? `（另有 ${missing} 个文件已缺失）` : ''}。`;
        showNotice(`删除完成；${hint}`, 'success');
        state.offset = Math.max(0, Math.min(state.offset, Math.max(0, state.total - 1)));
        void loadList();
      } catch (error) {
        showNotice(libraryErrorMessage(error, '删除作品'), errorStatus(error) === 404 ? 'warning' : 'error');
      }
    })();
  }

  function downloadArtifact(artifact) {
    const source = state.imageUrls.get(imageKeyForArtifact(artifact && artifact.artifact_id));
    if (!source || !artifact || artifact.exists === false) return;
    const filename = safeOutputFilename(artifact.filename) || 'easy-panel-library.png';
    const link = createElement('a');
    link.href = source;
    link.download = filename;
    link.rel = 'noreferrer';
    global.document.body.append(link);
    link.click();
    link.remove();
    showNotice(`已开始下载：${filename}`, 'success');
  }

  function restoreToForm(mode) {
    if (!state.detail) return;
    const restore = global.restorePayloadToPanel;
    if (typeof restore !== 'function') {
      showNotice('当前页面缺少表单恢复能力，请刷新电脑端页面后重试。', 'error');
      return;
    }
    try {
      const payload = restorePayloadForForm(state.detail, mode === 'seed-variant' ? 'seed-variant' : 'reproduce');
      const derivation = pendingDerivationContextForDetail(state.detail, mode);
      if (!derivation) throw new Error('作品缺少安全的作品编号，无法建立派生关联。');
      restore(payload);
      if (typeof global.setPendingDerivationContext === 'function') {
        global.setPendingDerivationContext(derivation);
      }
      const status = byId('status');
      const relationHint = `将从作品 ${derivation.parentGenerationId.slice(0, 10)}… 派生（${operationLabel(derivation.operation)}）；未自动选择输出图，可取消关联。`;
      if (status) status.textContent = mode === 'seed-variant'
        ? `作品参数和新 Seed 已恢复到面板；${relationHint} 请确认后手动点击“生成图片”。`
        : `作品参数已恢复到面板；${relationHint} 请确认后手动点击“生成图片”。`;
      closeDialog();
      if (mode === 'continue-edit') {
        if (typeof global.jumpToPanelSection === 'function') global.jumpToPanelSection('promptComposer');
        global.setTimeout(() => {
          const target = byId('compiledPositive') || byId('promptSubject');
          if (target && typeof target.focus === 'function') target.focus();
        }, 0);
      }
    } catch (error) {
      showNotice(libraryErrorMessage(error, '恢复作品参数'), 'error');
    }
  }

  function closeDialog() {
    const dialog = byId('creativeLibraryDialog');
    if (dialog && dialog.open && typeof dialog.close === 'function') dialog.close();
    else if (dialog) dialog.removeAttribute('open');
  }

  function cleanupAfterClose() {
    state.requestNumber += 1;
    stopThumbnails();
    state.loading = false;
    state.detail = null;
    state.lineage = null;
    state.token = '';
    clearImageUrls();
    state.lastFocus?.focus?.();
    state.lastFocus = null;
  }

  function openDialog() {
    const dialog = byId('creativeLibraryDialog');
    if (!dialog) return;
    state.lastFocus = global.document.activeElement;
    state.offset = 0;
    renderGroupOptions();
    state.filters = filterValues();
    showListView();
    if (!dialog.open) {
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
    }
    void loadList();
    void loadGroups();
  }

  function applyFilters(event) {
    event.preventDefault();
    state.filters = filterValues();
    state.offset = 0;
    void loadList();
  }

  function goPrevious() {
    if (state.loading || state.offset <= 0) return;
    state.offset = Math.max(0, state.offset - PAGE_SIZE);
    void loadList();
  }

  function goNext() {
    if (state.loading || !state.hasMore) return;
    state.offset += PAGE_SIZE;
    void loadList();
  }

  function jumpToPage(event) {
    event.preventDefault();
    if (state.loading) return;
    const offset = pageOffset(byId('creativeLibraryPageNumber')?.value, state.total);
    if (offset === null) {
      showNotice(`请输入 1–${Math.max(1, Math.ceil(state.total / PAGE_SIZE))} 的整数页码。`, 'warning');
      return;
    }
    if (offset === state.offset) return;
    state.offset = offset;
    state.listScrollTop = 0;
    const list = byId('creativeLibraryListView');
    if (list) list.scrollTop = 0;
    void loadList();
  }

  function backToList() {
    const generationId = state.detail?.generation_id;
    state.requestNumber += 1;
    state.loading = false;
    state.detail = null;
    state.lineage = null;
    showListView();
    showNotice(state.items.length ? '已返回作品列表。' : '作品列表为空。', state.items.length ? 'success' : '');
    renderList();
    renderPagination();
    loadListThumbnails(state.items, state.requestNumber);
    const listView = byId('creativeLibraryListView');
    if (listView) {
      listView.scrollTop = state.listScrollTop;
      global.requestAnimationFrame?.(() => {
        listView.scrollTop = state.listScrollTop;
        const card = [...listView.querySelectorAll('[data-generation-id]')]
          .find((item) => item.dataset.generationId === generationId);
        if (!card) return;
        const rootRect = listView.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        if (cardRect.top < rootRect.top || cardRect.bottom > rootRect.bottom) {
          listView.scrollTop += cardRect.top - rootRect.top - listView.clientHeight / 3;
        }
      });
    }
  }

  function init() {
    if (!byId('creativeLibraryDialog')) return;
    byId('creativeLibraryOpen')?.addEventListener('click', openDialog);
    async function purgeFailedLibrary() {
    const statuses = ['error', 'cancelled'];
    try {
      const preview = await postJson('/api/rpg/library/purge', state.token, { statuses, dryRun: true });
      const count = Number(preview.deleted || 0);
      if (!count) {
        showNotice('没有生成失败或被取消的作品需要清理。');
        return;
      }
      const files = Number(preview.removed_files || 0);
      const confirmed = global.confirm(
        `将清理 ${count} 条失败 / 已取消的作品记录，并删除 ${files} 个对应图片文件。\n`
        + '收藏、收藏组与作品项目里引用的作品不会被删除。确定继续吗？');
      if (!confirmed) return;
      const result = await postJson('/api/rpg/library/purge', state.token, { statuses });
      const protectedNote = Number(result.protected_files || 0)
        ? `，${result.protected_files} 个文件因被收藏作品引用而保留` : '';
      showNotice(`已清理 ${result.deleted} 条作品，删除文件 ${result.removed_files} 个`
        + `，另有 ${result.missing_files || 0} 个文件本就缺失${protectedNote}。`);
      state.offset = 0;
      void loadList();
    } catch (error) {
      showNotice('清理失败：' + asText(error && error.message), 'error');
    }
  }

  async function repairLibrary() {
    try {
      const report = await postJson('/api/rpg/library/repair', state.token, { action: 'report' });
      const confirmed = global.confirm(
        `当前索引：\n${indexReportText(report)}\n\n现在执行修复？\n`
        + '将：登记未入索引的成品图、清理记录已不存在文件的条目、合并重复引用的同一张图。不会删除仍存在的图片。');
      if (!confirmed) return;
      const result = await postJson('/api/rpg/library/repair', state.token, { action: 'repair' });
      const imported = Number((result.imported || {}).imported || 0);
      const pruned = Number((result.pruned || {}).pruned_generations || 0);
      const marked = Number((result.duplicates || {}).marked || 0);
      const skipped = Number((result.imported || {}).skipped || 0);
      const pending = Number((result.after || {}).pending_artifacts || 0);
      const summary = [
        `修复完成：新登记 ${imported} 条、清理丢失记录 ${pruned} 条、标记同名重复 ${marked} 条${skipped ? `、跳过已删除文件 ${skipped} 张` : ''}。`,
        pending ? `仍有 ${pending} 条文件在写盘（⏳ 保存中）：不会被当成丢失，稍后刷新即可。` : '',
        '修复后：',
        indexReportText(result.after),
      ].filter(Boolean).join('\n');
      state.offset = 0;
      // loadList 会写“已读取 N 条作品”，所以刷新完成后再把修复结果写回通知栏。
      Promise.resolve(loadList()).then(() => showNotice(summary)).catch(() => showNotice(summary));
    } catch (error) {
      showNotice('修复失败：' + asText(error && error.message), 'error');
    }
  }

  byId('creativeLibraryClose')?.addEventListener('click', closeDialog);
    byId('creativeLibraryRefresh')?.addEventListener('click', () => { state.offset = 0; void loadList(); });
    byId('creativeLibraryPurgeFailed')?.addEventListener('click', () => { void purgeFailedLibrary(); });
    byId('creativeLibraryRepair')?.addEventListener('click', () => { void repairLibrary(); });
    byId('creativeLibraryFilters')?.addEventListener('submit', applyFilters);
    byId('creativeLibraryPrevious')?.addEventListener('click', goPrevious);
    byId('creativeLibraryNext')?.addEventListener('click', goNext);
    byId('creativeLibraryJump')?.addEventListener('submit', jumpToPage);
    byId('creativeLibraryBack')?.addEventListener('click', backToList);
    byId('creativeLibraryDialog')?.addEventListener('close', cleanupAfterClose);
    global.document.addEventListener('easy-panel:open-generation', (event) => {
      const generationId = event && event.detail ? asText(event.detail.generationId) : '';
      if (!generationId) return;
      state.offset = 0;
      void loadList().then(() => openDetail(generationId));
    });
    global.openCreativeLibrary = openDialog;
    global.closeCreativeLibrary = closeDialog;
  }

  if (global.document.readyState === 'loading') global.document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
}(typeof window !== 'undefined' ? window : globalThis));
