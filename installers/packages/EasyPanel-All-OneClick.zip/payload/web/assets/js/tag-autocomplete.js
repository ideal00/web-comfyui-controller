/* One tag search path for prompt textareas, Chip add, and advanced search. */
(function (global) {
  'use strict';
  const FIELD_KEYS = {
    promptSubject:'subject', promptAppearance:'appearance', promptExpression:'expression',
    promptClothing:'clothing', promptPose:'pose', promptComposition:'composition',
    promptScene:'scene', promptLighting:'lighting', promptStyle:'style',
    prompt:'manual', negative:'negative', promptNaturalLanguage:'naturalLanguage'
  };
  const MATCH = /(^|[,;\n]\s*)([^,;\n]{1,})$/;
  const cache = new Map();
  const previewCache = new Map();
  let chipPicker = null;
  const fieldCompletions = new Map();
  let advancedSequence = 0;
  let advancedIndex = -1;
  let relatedSequence = 0;
  let previewSequence = 0;
  let previewTimer = null;
  let suppressTouchMouseUntil = 0;

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function normalized(value) { return String(value || '').trim().toLowerCase().replace(/_/g,' ').replace(/\s+/g,' '); }
  function searchable(value) { const term = String(value || '').trim(); return term.length >= 2 || /[\u3400-\u9fff]/.test(term); }
  function fieldForKey(key) { const id = Object.keys(FIELD_KEYS).find(candidate => FIELD_KEYS[candidate] === key); return id ? document.getElementById(id) : null; }
  function baseTag(value) {
    let tag = String(value || '').trim();
    const source = global.EasyPanelPromptVariations?.translationSource;
    tag = source ? source(tag) : tag.replace(/^\((.+):[\d.]+\)$/,'$1');
    return normalized(tag.replace(/^@/, ''));
  }
  function currentTerms(field) { return new Set(String(field?.value || '').split(/[,;\n]+/).map(baseTag).filter(Boolean)); }
  function formatTag(item) {
    const canonical = String(item?.tag || '').trim().replace(/ /g,'_');
    const colored = global.EasyPanelColorModifier?.compose(canonical) || canonical;
    return global.EasyPanelDialect?.formatTag(colored, {kind:item?.category === '画师' || item?.kind === 'artist' ? 'artist' : undefined}) || colored;
  }
  function colorChoiceMarkup() {
    const modifier = global.EasyPanelColorModifier;
    if (!modifier?.MODIFIERS) return '';
    const current = modifier.current();
    const options = [{key:'',label:'原色'}, ...modifier.MODIFIERS.map(item => ({key:item.key,label:item.label}))];
    return `<select class="easy-tag-color" data-autocomplete-color aria-label="颜色修饰" title="选择后，颜色标签插入时使用此修饰">${options.map(item => `<option value="${escapeHtml(item.key)}"${item.key === current ? ' selected' : ''}>${escapeHtml(item.label)}</option>`).join('')}</select>`;
  }
  function queryAtCursor(field) {
    const before = String(field?.value || '').slice(0, field?.selectionStart ?? 0);
    const after = String(field?.value || '').slice(field?.selectionEnd ?? 0);
    const match = before.match(MATCH);
    return match && /^\s*(?:[,;\n]|$)/.test(after) ? match[2].trim() : '';
  }
  function tagAtCursor(field) {
    const text = String(field?.value || ''), at = field?.selectionStart ?? 0;
    const left = Math.max(text.lastIndexOf(',', at - 1), text.lastIndexOf(';', at - 1), text.lastIndexOf('\n', at - 1)) + 1;
    const rightCandidates = [text.indexOf(',', at), text.indexOf(';', at), text.indexOf('\n', at)].filter(index => index >= 0);
    const right = rightCandidates.length ? Math.min(...rightCandidates) : text.length;
    return text.slice(left, right).trim().replace(/^\((.+):[\d.]+\)$/,'$1');
  }
  async function search(query) {
    const term = String(query || '').trim();
    if (!searchable(term)) return [];
    const key = term.toLowerCase();
    if (!cache.has(key)) {
      const read = async (url) => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        try { const response = await fetch(url, {signal:controller.signal}); if (!response.ok) return null; return await response.json(); }
        catch (_) { return null; }
        finally { clearTimeout(timeout); }
      };
      const request = Promise.all([
        read('/api/visual-tags?' + new URLSearchParams({q:term,limit:'200'})),
        read('/api/tags?' + new URLSearchParams({q:term,limit:'120'}))
      ]).then(([visual, dictionary]) => {
        // A temporary connection failure must not become an empty permanent cache hit.
        if ((!visual || !dictionary) && cache.get(key) === request) cache.delete(key);
        return mergeResults(visual?.results || [], dictionary?.tags || [], visual?.matched);
      });
      cache.set(key, request);
      if (cache.size > 80) cache.delete(cache.keys().next().value);
    }
    return cache.get(key);
  }
  function mergeResults(local, dictionary, localMatched) {
    const seen = new Map();
    const featured = [];
    const localByTag = new Map((Array.isArray(local) ? local : []).filter(entry => entry.tag).map(entry => [normalized(entry.tag), entry]));
    let weakFeatured = 0;
    for (const entry of (Array.isArray(local) ? local : [])) {
      if (featured.length >= 60) break;
      if (!entry.tag || seen.has(normalized(entry.tag))) continue;
      if (Number(entry.score || 100) < 15 && ++weakFeatured > 8) continue;
      const item = {tag:entry.tag,translation:entry.name_zh || '',category:entry.category || '',
        kind:entry.kind,description:entry.description || '',imageId:entry.image_status === 'ready' ? entry.id : '',source:'local',localMatched:Number(localMatched ?? local.length)};
      featured.push(item); seen.set(normalized(item.tag), item);
    }
    const rest = [];
    (Array.isArray(dictionary) ? dictionary : []).forEach(entry => {
      if (!entry.tag) return;
      const key = normalized(entry.tag), featuredItem = seen.get(key);
      if (featuredItem) { featuredItem.count = entry.count; if (!featuredItem.translation) featuredItem.translation = entry.translation || ''; return; }
      if (rest.some(item => normalized(item.tag) === key)) return;
      const localEntry = localByTag.get(key);
      rest.push({...entry,source:localEntry ? 'local' : 'index',
        imageId:localEntry?.image_status === 'ready' ? localEntry.id : '',
        description:localEntry?.description || ''});
    });
    return [...featured, ...rest];
  }
  function resultMarkup(item) {
    if (item.source === 'preset') {
      const image = global.EasyPanelPresetExamples?.url(item.exampleImage);
      return `<span class="easy-preset-result">${image ? `<img class="easy-preset-thumb" src="${escapeHtml(image)}" alt="${escapeHtml(item.name)}的例图" loading="lazy">` : '<span class="easy-preset-placeholder">无例图</span>'}<span class="easy-preset-copy"><span class="easy-tag-name">${escapeHtml(item.name)}</span><small class="easy-tag-meta">${item.origin === 'visual' ? '图库 · ' + escapeHtml(item.libraryCategory) : '本区预设 · ' + escapeHtml(item.category)}${item.combo ? ' · 组合只取本区' : ''}</small><span class="easy-preset-text">${escapeHtml(item.text.slice(0,120))}</span></span></span>`;
    }
    const count = Number(item.count || item.post_count || 0).toLocaleString();
    const label = item.translation || item.category || item.kind || '';
    return `<span class="easy-tag-name">${escapeHtml(item.tag)}</span><small class="easy-tag-meta">${item.source === 'local' ? '本地图鉴 · ' : ''}${escapeHtml(label)}${count !== '0' ? ' · ' + count : ''}</small><span class="easy-tag-image" data-autocomplete-image="${escapeHtml(item.tag)}" title="在可视化图库查看" aria-label="查看 ${escapeHtml(item.tag)} 的图片">🖼</span>`;
  }
  function openVisual(item, completion) {
    completion?.hide();
    const tag = typeof item === 'string' ? item : item.tag;
    const source = item?.source === 'local' ? 'local' : 'cloud';
    if (global.EasyPanelVisualTags?.openTag) global.EasyPanelVisualTags.openTag(tag, source);
    else { const input = document.getElementById('tagSearch'); if (input) input.value = tag; global.EasyPanelVisualTags?.open(); }
  }
  function connectImageButtons(completion, field) {
    const action = target => {
      if (target.closest?.('[data-autocomplete-close]')) {
        completion.hide();
        return true;
      }
      const related = target.closest?.('[data-autocomplete-related]');
      if (related) {
        const selected = completion.dropdown.getActiveItem() || completion.dropdown.items[0];
        if (selected) showRelated(field, completion, selected.searchResult.data.tag);
        return true;
      }
      const all = target.closest?.('[data-autocomplete-all]');
      if (all) {
        const query = queryAtCursor(field);
        if (query) openVisual({tag:query,source:'local'}, completion);
        return true;
      }
      const button = target.closest?.('[data-autocomplete-image]');
      if (!button) return false;
      const entry = completion.dropdown.items.find(item => item.searchResult.data.tag === button.dataset.autocompleteImage);
      if (entry) openVisual(entry.searchResult.data, completion);
      return true;
    };
    const listener = event => {
      if (Date.now() < suppressTouchMouseUntil) return;
      if (action(event.target)) { event.preventDefault(); event.stopPropagation(); }
    };
    completion.dropdown.el.addEventListener('mousedown', listener, true);
    completion.dropdown.el.addEventListener('click', listener, true);
    completion.dropdown.el.addEventListener('change', event => {
      if (!event.target.matches?.('[data-autocomplete-color]')) return;
      global.EasyPanelColorModifier?.set(event.target.value);
      field.focus();
    });
    return action;
  }
  function hidePreview() {
    previewSequence++;
    if (previewTimer !== null) { clearTimeout(previewTimer); previewTimer = null; }
    document.getElementById('easyTagPreview')?.remove();
  }
  async function previewFor(item) {
    if (item.source === 'preset') { const url = global.EasyPanelPresetExamples?.url(item.exampleImage); return url ? {url,source:'预设例图 · '+item.name} : null; }
    if (item.imageId) return {url:'/api/visual-tags/image?' + new URLSearchParams({id:item.imageId,size:'thumb',px:'320'}),source:'本地可视化图库'};
    const key = normalized(item.tag);
    if (!previewCache.has(key)) {
      const request = (async () => {
        try {
          const response = await fetch('/api/visual-tags?' + new URLSearchParams({q:item.tag,limit:'8'}));
          if (response.ok) {
            const data = await response.json();
            const exact = (data.results || []).find(entry => normalized(entry.tag) === key && entry.image_status === 'ready');
            if (exact) {
              item.imageId = exact.id; item.source = 'local';
              return {url:'/api/visual-tags/image?' + new URLSearchParams({id:exact.id,size:'thumb',px:'320'}),source:'本地可视化图库'};
            }
          }
          const cloud = await fetch('/api/danbooru/posts?' + new URLSearchParams({tags:item.tag.replace(/ /g,'_'),limit:'1',rating:'general'}));
          if (cloud.ok) {
            const data = await cloud.json(), post = (data.results || [])[0];
            if (post?.post_id) return {url:'/api/danbooru/image?' + new URLSearchParams({post:String(post.post_id),kind:'preview'}),source:'Danbooru 示例图'};
          }
        } catch (_) { /* A missing image must not interrupt tag entry. */ }
        return null;
      })();
      previewCache.set(key, request);
      if (previewCache.size > 80) previewCache.delete(previewCache.keys().next().value);
    }
    return previewCache.get(key);
  }
  function showPreview(item, completion) {
    const key = item.source === 'preset' ? 'preset:'+item.id : normalized(item.tag);
    let box = document.getElementById('easyTagPreview');
    if (box?.dataset.tag === key) return;
    hidePreview();
    box = document.createElement('aside'); box.id = 'easyTagPreview'; box.className = 'easy-tag-preview'; box.dataset.tag = key;
    positionPreview(box, completion);
    const title = document.createElement('strong'); title.textContent = item.tag;
    const info = document.createElement('small'); info.textContent = `${item.translation || ''}${item.category ? ' · ' + item.category : ''}`;
    const body = document.createElement('div'); body.className = 'easy-tag-preview-body'; body.textContent = '正在查找参考图…';
    box.append(title, info, body); document.body.append(box);
    const sequence = previewSequence;
    const load = () => previewFor(item).then(result => {
      if (sequence !== previewSequence || !box.isConnected) return;
      body.replaceChildren();
      if (!result) { body.textContent = item.source === 'preset' ? '这个预设未绑定例图' : '本地图库和云端暂无参考图'; return; }
      const img = document.createElement('img'); img.src = result.url; img.alt = `${item.tag} 参考图`;
      img.onerror = () => { body.textContent = '参考图暂不可用'; };
      const source = document.createElement('small'); source.textContent = result.source;
      body.append(img, source);
      if (item.description) { const note = document.createElement('p'); note.textContent = item.description; box.append(note); }
    });
    if (item.source === 'preset' || item.imageId) load(); else previewTimer = setTimeout(load, 60);
  }
  function positionPreview(box, completion) {
    if (matchMedia('(pointer:coarse)').matches || document.documentElement.classList.contains('easy-panel-mobile')) {
      const headerBottom = document.querySelector('.studio-header')?.getBoundingClientRect().bottom || 0;
      box.style.left = Math.max(8, innerWidth - 182) + 'px';
      box.style.top = Math.max(8, Math.min(headerBottom + 6, innerHeight - 190)) + 'px';
      return;
    }
    const rect = completion.dropdown.el.getBoundingClientRect(), width = Math.min(300, innerWidth - 16);
    const left = rect.right + width + 8 <= innerWidth ? rect.right + 8 : rect.left - width - 8;
    box.style.left = Math.max(8, Math.min(left, innerWidth - width - 8)) + 'px';
    box.style.top = Math.max(8, Math.min(rect.top, innerHeight - 300)) + 'px';
  }
  function connectPositioning(field, completion, editor) {
    const dropdown = completion.dropdown, viewport = field.closest('.studio-content-viewport');
    const visualViewport = global.visualViewport;
    function position() {
      if (!dropdown.shown) return;
      const fieldRect = field.getBoundingClientRect();
      const viewRect = viewport?.getBoundingClientRect();
      const screenTop = visualViewport?.offsetTop || 0;
      const screenBottom = screenTop + (visualViewport?.height || innerHeight);
      const visibleTop = Math.max(screenTop + 8, viewRect?.top || 8);
      const visibleBottom = Math.min(screenBottom - 8, viewRect?.bottom || innerHeight - 8);
      if (fieldRect.bottom <= visibleTop || fieldRect.top >= visibleBottom) { completion.hide(); return; }
      const picker = field.closest('.easy-chip-picker');
      const pickerRect = picker?.getBoundingClientRect();
      const isChipPicker = Boolean(picker);
      const caret = isChipPicker ? {top:pickerRect.bottom + scrollY,left:fieldRect.left + scrollX} : editor.getCursorOffset();
      const caretTop = caret.top - scrollY;
      if (caretTop < visibleTop || caretTop > visibleBottom || (!isChipPicker && (caretTop < fieldRect.top || caretTop > fieldRect.bottom + 24))) {
        completion.hide(); return;
      }
      const dock = document.getElementById('studioActionDock')?.getBoundingClientRect();
      const bottom = dock && dock.top > visibleTop ? Math.min(visibleBottom, dock.top) : visibleBottom;
      const availableBelow = bottom - caretTop - 6;
      const anchorTop = isChipPicker ? pickerRect.top : caretTop;
      const availableAbove = anchorTop - visibleTop - 6;
      const desiredHeight = Math.min(390, innerHeight * .65, dropdown.el.scrollHeight);
      const above = availableBelow < Math.min(desiredHeight, 180) && availableAbove > availableBelow;
      const room = Math.max(80, above ? availableAbove : availableBelow);
      dropdown.el.style.position = 'fixed';
      dropdown.el.style.right = 'auto'; dropdown.el.style.bottom = 'auto';
      dropdown.el.style.maxHeight = Math.min(desiredHeight, room) + 'px';
      const width = dropdown.el.getBoundingClientRect().width;
      const caretLeft = (caret.left ?? caret.right ?? fieldRect.left) - scrollX;
      dropdown.el.style.left = Math.max(8, Math.min(caretLeft, innerWidth - width - 8)) + 'px';
      dropdown.el.style.top = (above ? Math.max(visibleTop, anchorTop - Math.min(desiredHeight, room) - 6) : caretTop + 6) + 'px';
      const preview = document.getElementById('easyTagPreview');
      if (preview) positionPreview(preview, completion);
    }
    dropdown.on('rendered', position);
    const onScroll = event => { if (event.target !== dropdown.el) position(); };
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', position);
    visualViewport?.addEventListener('resize', position);
    visualViewport?.addEventListener('scroll', position);
    field.addEventListener('click', position);
    field.addEventListener('keyup', position);
    return () => {
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', position);
      visualViewport?.removeEventListener('resize', position);
      visualViewport?.removeEventListener('scroll', position);
      field.removeEventListener('click', position);
      field.removeEventListener('keyup', position);
    };
  }
  function activateWithoutScroll(item) {
    if (!item.active) {
      item.dropdown.getActiveItem()?.deactivate();
      item.dropdown.activeItem = item;
      item.active = true;
      item.el.className = item.activeClassName;
    }
    return item;
  }
  function keepActiveVisible(dropdown, item) {
    const viewport = dropdown.el.getBoundingClientRect(), row = item.el.getBoundingClientRect();
    const header = dropdown.el.querySelector('.textcomplete-header')?.getBoundingClientRect().height || 0;
    const footer = dropdown.el.querySelector('.textcomplete-footer')?.getBoundingClientRect().height || 0;
    if (row.top < viewport.top + header) dropdown.el.scrollTop += row.top - viewport.top - header;
    else if (row.bottom > viewport.bottom - footer) dropdown.el.scrollTop += row.bottom - viewport.bottom + footer;
  }
  function connectPreview(completion, touchAction) {
    const dropdown = completion.dropdown;
    let touch = null;
    let holdTimer = null;
    function cancelHold() {
      if (holdTimer !== null) { clearTimeout(holdTimer); holdTimer = null; }
    }
    function cancelTouch() { cancelHold(); touch = null; }
    function itemAt(target) {
      const row = target?.closest?.('.textcomplete-item');
      return dropdown.items.find(item => item.el === row);
    }
    function previewAt(target) {
      const item = itemAt(target);
      if (item) { item.activate(); showPreview(item.searchResult.data, completion); }
      return item;
    }
    completion.dropdown.el.addEventListener('mousemove', event => {
      if (touch || Date.now() < suppressTouchMouseUntil) return;
      previewAt(event.target);
    });
    dropdown.el.addEventListener('touchstart', event => {
      cancelTouch();
      suppressTouchMouseUntil = Date.now() + 700;
      if (event.touches.length !== 1 || event.target.closest?.('[data-autocomplete-color]')) return;
      const point = event.touches[0];
      const item = itemAt(event.target);
      touch = {x:point.clientX,y:point.clientY,target:event.target,item,moved:false,previewed:false};
      if (!item || event.target.closest?.('[data-autocomplete-image]')) return;
      const gesture = touch;
      holdTimer = setTimeout(() => {
        holdTimer = null;
        if (touch !== gesture || touch.moved || !dropdown.shown || !dropdown.items.includes(item)) return;
        touch.previewed = true;
        item.activate(); showPreview(item.searchResult.data, completion);
      }, 450);
    }, {passive:true});
    dropdown.el.addEventListener('touchmove', event => {
      if (event.touches.length !== 1) { cancelTouch(); return; }
      if (!touch) return;
      const point = event.touches[0];
      if (Math.hypot(point.clientX - touch.x, point.clientY - touch.y) > 8) {
        touch.moved = true; cancelHold(); hidePreview();
      }
    }, {passive:true});
    dropdown.el.addEventListener('touchend', event => {
      if (!touch) return;
      const gesture = touch;
      const point = event.changedTouches[0];
      const moved = gesture.moved || !point || Math.hypot(point.clientX - gesture.x, point.clientY - gesture.y) > 8;
      cancelTouch();
      suppressTouchMouseUntil = Date.now() + 700;
      if (moved) return;
      event.preventDefault();
      if (gesture.previewed || !dropdown.shown) return;
      if (touchAction(gesture.target)) return;
      // Keep the row touched at the start: keyboard reflow can change hit testing.
      const item = gesture.item;
      if (!item || !dropdown.items.includes(item)) return;
      hidePreview();
      item.activate();
      dropdown.select(item);
    }, {passive:false});
    dropdown.el.addEventListener('touchcancel', cancelTouch);
    dropdown.el.addEventListener('contextmenu', event => { if (touch?.previewed) event.preventDefault(); });
    dropdown.el.addEventListener('mousedown', event => {
      if (Date.now() < suppressTouchMouseUntil) { event.preventDefault(); event.stopPropagation(); }
    }, true);
    dropdown.el.addEventListener('click', event => {
      if (Date.now() < suppressTouchMouseUntil) { event.preventDefault(); event.stopPropagation(); }
    }, true);
    completion.dropdown.el.addEventListener('mouseleave', hidePreview);
    completion.dropdown.on('hidden', () => { cancelTouch(); hidePreview(); });
    completion.dropdown.on('rendered', () => {
      cancelTouch();
      completion.dropdown.items.forEach(item => {
        item.el.removeEventListener('mouseover', item.onMouseover);
        item.el.removeEventListener('touchstart', item.onClick);
        item.activate = () => activateWithoutScroll(item);
      });
      completion.dropdown.el.scrollTop = 0;
      hidePreview();
    });
  }
  function createCompletion(field, onChipInsert) {
    const Constructor = global.Textcomplete;
    if (!Constructor?.editors?.Textarea) return null;
    const editor = new Constructor.editors.Textarea(field);
    const completion = new Constructor(editor, {
      dropdown:{maxCount:180,className:'textcomplete-dropdown easy-tag-dropdown',
        header(items) {
          const local = items.find(item => item.source === 'local');
          const presets = items.filter(item => item.source === 'preset').length;
          const count = (presets ? `本区预设 ${presets} · ` : '') + (local ? `本地${Number(local.localMatched || 0).toLocaleString()} · ` : '');
          return `<span class="easy-tag-header-count">${count}${items.length}项</span><span class="easy-tag-header-tools">${colorChoiceMarkup()}<button type="button" data-autocomplete-related="true" title="查看所选标签的相关词" aria-label="查看所选标签的相关词">🔗</button>${local ? '<button type="button" data-autocomplete-all="local" title="在本地图鉴查看全部匹配" aria-label="在本地图鉴查看全部匹配">▦</button>' : ''}<button type="button" data-autocomplete-close="true" title="关闭候选词" aria-label="关闭候选词">×</button></span>`;
        }}
    });
    let lookup = 0;
    completion.cancelLookup = () => { lookup++; completion.hide(); };
    const pickerStatus = field.closest('.easy-chip-picker')?.querySelector('[data-picker-status]');
    const setStatus = text => { if (pickerStatus) pickerStatus.textContent = text; };
    completion.register([{
      id:'easy-panel-tags', match:MATCH, index:2,
      search(term, callback) {
        const query = String(term || '').trim(), request = ++lookup;
        const presetSearch = onChipInsert ? null : global.EasyPanelPresetSearch;
        const range = presetSearch?.queryRange(field);
        let matches = presetSearch ? presetSearch.candidates(field.id,query,30).map(item => ({...item,range})) : [];
        if (field.readOnly || field.disabled || field.dataset.composing === '1' || !searchable(query) || !/^\s*(?:[,;\n]|$)/.test(field.value.slice(field.selectionEnd))) {
          setStatus(field.dataset.composing === '1' ? '确认中文输入后显示候选。' : '输入中文标签或至少两个英文字母。');
          callback([]); return;
        }
        // Textcomplete's callback completes one lookup and unlocks its pending query.
        // Calling it twice or skipping it on stale input corrupts that queue.
        if (field.id === 'promptNaturalLanguage') { callback(matches); return; }
        setStatus('正在搜索候选…');
        const before = field.value, caret = field.selectionEnd;
        Promise.all([search(query),presetSearch?.ready?.().catch(()=>{})]).then(([items]) => {
          if (lookup !== request || field.value !== before || field.selectionEnd !== caret || field.dataset.composing === '1') { callback([]); return; }
          if (presetSearch) matches = presetSearch.candidates(field.id,query,30).map(item => ({...item,range}));
          const used = onChipInsert ? currentTerms(fieldForKey(onChipInsert)) : currentTerms(field);
          const selected = completion.dropdown.getActiveItem()?.searchResult.data;
          const scrollTop = completion.dropdown.el.scrollTop;
          const candidates = matches.concat(items.slice(0, 180 - matches.length).map(item => ({...item, existing:used.has(baseTag(item.tag))})));
          setStatus(candidates.length ? `找到 ${candidates.length} 个候选` : '没有找到匹配标签；可换个关键词重试。');
          callback(candidates);
          if (selected) {
            const active = completion.dropdown.items.find(item => selected.source === 'preset'
              ? item.searchResult.data.source === 'preset' && item.searchResult.data.id === selected.id
              : item.searchResult.data.source !== 'preset' && normalized(item.searchResult.data.tag) === normalized(selected.tag));
            if (active) { completion.dropdown.el.scrollTop = scrollTop; active.activate(); showPreview(active.searchResult.data, completion); }
          }
        }, () => {
          const current = lookup === request && field.value === before && field.selectionEnd === caret;
          if (current) setStatus('候选搜索暂不可用，请重新输入重试。');
          callback(current ? matches : []);
        });
      },
      template(item) { return `<span class="easy-tag-result${item.existing ? ' existing' : ''}">${resultMarkup(item)}</span>`; },
      replace(item) {
        const trailing = /^\s*[,;\n]/.test(field.value.slice(field.selectionEnd)) ? '' : ', ';
        return '$1' + formatTag(item).replace(/\$/g,'$$$$') + trailing;
      }
    }]);
    completion.on('select', event => {
      const item = event.detail.searchResult.data;
      if (item.source === 'preset') { event.preventDefault(); global.EasyPanelPresetSearch?.apply(item,field.id,'complete',item.range); completion.hide(); return; }
      if (item.existing) { event.preventDefault(); completion.hide(); return; }
      if (onChipInsert) {
        event.preventDefault();
        global.EasyPanelPromptVariations?.addTag(onChipInsert, formatTag(item));
        closeChipPicker();
      }
    });
    const touchAction = connectImageButtons(completion, field);
    connectPreview(completion, touchAction);
    completion.disposePositioning = connectPositioning(field, completion, editor);
    field.addEventListener('keydown', event => {
      if (event.key === 'Escape') lookup++;
      if ((event.key === 'ArrowDown' || event.key === 'ArrowUp') && completion.dropdown.shown) {
        const active = completion.dropdown.getActiveItem();
        if (active) { keepActiveVisible(completion.dropdown, active); showPreview(active.searchResult.data, completion); }
      }
      if (event.key === 'Tab' && completion.dropdown.shown) {
        const active = completion.dropdown.getActiveItem() || completion.dropdown.items[0];
        if (active) { event.preventDefault(); completion.dropdown.select(active); }
      }
      if (!onChipInsert && (event.ctrlKey || event.metaKey) && !event.shiftKey && event.code === 'Space') { event.preventDefault(); completion.hide(); global.EasyPanelPresetSearch?.open(field.id); }
      if (!onChipInsert && event.ctrlKey && event.shiftKey && event.code === 'Space') { event.preventDefault(); showRelated(field, completion); }
    });
    field.addEventListener('compositionstart', () => { lookup++; field.dataset.composing = '1'; completion.hide(); });
    field.addEventListener('compositionend', () => { field.dataset.composing = '0'; completion.trigger(field.value.slice(0, field.selectionStart)); });
    if (!onChipInsert) fieldCompletions.set(field.id,completion);
    return completion;
  }
  function closeChipPicker() {
    if (!chipPicker) return;
    hidePreview();
    chipPicker.completion?.cancelLookup();
    chipPicker.completion?.disposePositioning();
    chipPicker.disposePositioning();
    chipPicker.completion?.destroy();
    chipPicker.node.remove(); chipPicker = null;
  }
  function openChipPicker(key, anchor) {
    closeChipPicker();
    const node = document.createElement('div'); node.className = 'easy-chip-picker';
    node.dataset.sectionKey = key;
    node.innerHTML = '<textarea rows="1" placeholder="输入英文或中文标签…" aria-label="搜索并添加标签"></textarea><button type="button" data-picker="raw" title="添加未收录的英文标签">添加原文</button><button type="button" data-picker="close" aria-label="关闭">×</button><span data-picker-status role="status" aria-live="polite">输入英文或中文标签后显示候选。</span>';
    document.body.append(node);
    const visualViewport = global.visualViewport;
    function positionPicker() {
      const rect = anchor.getBoundingClientRect();
      const screenTop = visualViewport?.offsetTop || 0;
      const screenBottom = screenTop + (visualViewport?.height || innerHeight);
      const dock = document.getElementById('studioActionDock')?.getBoundingClientRect();
      const bottom = dock && dock.top > screenTop ? Math.min(screenBottom, dock.top) : screenBottom;
      const width = node.getBoundingClientRect().width;
      node.style.left = Math.max(8, Math.min(rect.left, innerWidth - width - 8)) + 'px';
      node.style.top = Math.max(screenTop + 8, Math.min(rect.bottom + 5, bottom - node.offsetHeight - 8)) + 'px';
    }
    positionPicker();
    const input = node.querySelector('textarea');
    let completion = null;
    const onScroll = event => { if (!node.contains(event.target) && !completion?.dropdown.el.contains(event.target)) positionPicker(); };
    window.addEventListener('resize', positionPicker);
    window.addEventListener('scroll', onScroll, true);
    visualViewport?.addEventListener('resize', positionPicker);
    visualViewport?.addEventListener('scroll', positionPicker);
    completion = createCompletion(input, key);
    chipPicker = {node,completion,disposePositioning() {
      window.removeEventListener('resize', positionPicker);
      window.removeEventListener('scroll', onScroll, true);
      visualViewport?.removeEventListener('resize', positionPicker);
      visualViewport?.removeEventListener('scroll', positionPicker);
    }};
    node.querySelector('[data-picker="close"]').onclick = closeChipPicker;
    node.querySelector('[data-picker="raw"]').onclick = () => {
      const value = input.value.trim();
      if (!value || /[\u3400-\u9fff]/.test(value)) return;
      global.EasyPanelPromptVariations?.addTag(key, value); closeChipPicker();
    };
    input.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); closeChipPicker(); } });
    input.focus();
    positionPicker();
  }
  function collapseAdvancedSearch() {
    const block = document.querySelector('#promptComposer > .prompt-tag-search');
    if (!block || block.parentElement?.classList.contains('easy-advanced-tag-search')) return;
    const details = document.createElement('details'); details.className = 'easy-advanced-tag-search prompt-primary-search';
    const summary = document.createElement('summary'); summary.textContent = '🔍 高级标签搜索（Ctrl+K）';
    block.before(details); details.append(summary, block);
    block.classList.remove('prompt-primary-search');
  }
  async function renderAdvancedSearch() {
    const input = document.getElementById('tagSearch'), root = document.getElementById('tagResults');
    if (!input || !root) return;
    const query = input.value.trim(), sequence = ++advancedSequence;
    if (!query) { advancedIndex = -1; root.textContent = '输入英文或中文标签后选择结果。'; return; }
    advancedIndex = -1; root.textContent = '正在搜索…';
    const items = await search(query);
    if (sequence !== advancedSequence) return;
    root.replaceChildren();
    advancedIndex = -1;
    if (!items.length) { root.textContent = '没有找到匹配标签。'; return; }
    items.forEach(item => {
      const row = document.createElement('div'); row.className = 'easy-advanced-result';
      const insert = document.createElement('button'); insert.type = 'button';
      insert.dataset.tag = item.tag;
      const name = document.createElement('span'); name.className = 'easy-tag-name'; name.textContent = item.tag;
      const meta = document.createElement('small'); meta.className = 'easy-tag-meta'; meta.textContent = `${item.translation || item.category || ''} · ${Number(item.count || 0).toLocaleString()}`;
      insert.append(name, meta);
      insert.onclick = () => {
        const section = global.EasyPanelTagWorkflow?.target() || document.getElementById('tagTarget')?.value || 'manual';
        if (global.appendEnglish?.(formatTag(item), section)) {
          global.EasyPanelTagWorkflow?.record(item.tag, section);
          insert.classList.add('tag-search-added');
          insert.title = `已加入${global.sectionLabel?.(section) || section}；可继续选择`;
        }
      };
      const image = document.createElement('button'); image.type = 'button'; image.textContent = '🖼'; image.title = '查看图片与相关标签'; image.onclick = () => openVisual(item);
      row.append(insert,image); root.append(row);
    });
  }
  function chooseAdvanced(direction) {
    const rows = [...document.querySelectorAll('#tagResults .easy-advanced-result')];
    if (!rows.length) return false;
    advancedIndex = advancedIndex < 0 ? (direction > 0 ? 0 : rows.length - 1)
      : (advancedIndex + direction + rows.length) % rows.length;
    rows.forEach((row,index) => row.classList.toggle('keyboard-active', index === advancedIndex));
    rows[advancedIndex].scrollIntoView?.({block:'nearest'});
    return true;
  }
  async function showRelated(field, completion, tagOverride) {
    const tag = tagOverride || tagAtCursor(field); if (!tag) return;
    const sequence = ++relatedSequence;
    let box = document.getElementById('easyTagRelated');
    if (!box) { box = document.createElement('div'); box.id = 'easyTagRelated'; box.className = 'easy-tag-related'; document.body.append(box); }
    completion?.hide();
    const rect = field.getBoundingClientRect();
    box.style.left = Math.max(8, Math.min(rect.left, innerWidth - 390)) + 'px';
    box.style.top = Math.min(rect.bottom + 6, innerHeight - 260) + 'px';
    box.hidden = false; box.textContent = `正在查找「${tag}」的相关标签…`;
    const expected = tag;
    try {
      const response = await fetch('/api/danbooru/related?' + new URLSearchParams({tag:tag.replace(/ /g,'_'),limit:'12'}));
      const data = await response.json();
      if (box.hidden || sequence !== relatedSequence || (!tagOverride && expected !== tagAtCursor(field))) return;
      if (data.error) throw Error(data.error);
      box.replaceChildren();
      const head = document.createElement('div'); head.className = 'easy-related-head'; head.textContent = `「${tag}」的相关标签`;
      const close = document.createElement('button'); close.type = 'button'; close.textContent = '×'; close.onclick = () => { box.hidden = true; field.focus(); }; head.append(close); box.append(head);
      (data.results || []).forEach(item => {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = item.tag.replace(/_/g,' ');
        button.onclick = () => {
          const formatted = formatTag(item);
          const key = chipPicker?.node.contains(field) ? chipPicker.node.dataset.sectionKey : FIELD_KEYS[field.id];
          if (key && chipPicker?.node.contains(field)) { global.EasyPanelPromptVariations?.addTag(key, formatted); closeChipPicker(); }
          else if (key && global.appendEnglish) global.appendEnglish(formatted, key);
          box.hidden = true;
        };
        box.append(button);
      });
      if (!(data.results || []).length) box.append('暂无相关标签。');
    } catch (error) { box.textContent = `相关标签暂不可用：${error.message}`; }
  }
  function init() {
    collapseAdvancedSearch();
    document.getElementById('tagSearch')?.addEventListener('keydown', event => {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        if (chooseAdvanced(event.key === 'ArrowDown' ? 1 : -1)) event.preventDefault();
      } else if (event.key === 'Enter') {
        const rows = [...document.querySelectorAll('#tagResults .easy-advanced-result')];
        const button = rows[Math.max(0, advancedIndex)]?.querySelector('button[data-tag]');
        if (!button) return;
        event.preventDefault(); event.stopPropagation();
        if (event.shiftKey) global.EasyPanelTagWorkflow?.toggleFavorite(button.dataset.tag);
        else button.click();
      }
    });
    Object.keys(FIELD_KEYS).forEach(id => { const field = document.getElementById(id); if (field) createCompletion(field); });
    global.searchTags = renderAdvancedSearch;
    document.addEventListener('keydown', event => {
      if ((event.ctrlKey || event.metaKey) && !event.shiftKey && !event.altKey && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        const details = document.querySelector('.easy-advanced-tag-search'); if (details) details.open = true;
        document.getElementById('tagSearch')?.focus();
      }
    });
    document.addEventListener('pointerdown', event => {
      if (chipPicker && !chipPicker.node.contains(event.target) && !chipPicker.completion?.dropdown.el.contains(event.target)) closeChipPicker();
      const related = document.getElementById('easyTagRelated');
      if (related && !related.hidden && !related.contains(event.target)) related.hidden = true;
    });
  }
  global.EasyPanelTagAutocomplete = {hideField:id=>fieldCompletions.get(id)?.cancelLookup(),search, mergeResults, searchable, baseTag, currentTerms, formatTag, colorChoiceMarkup, queryAtCursor, tagAtCursor, activateWithoutScroll, keepActiveVisible, openChipPicker, closeChipPicker, init};
  if (typeof module !== 'undefined' && module.exports) module.exports = global.EasyPanelTagAutocomplete;
  if (typeof document === 'undefined') return;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(typeof window !== 'undefined' ? window : globalThis);
